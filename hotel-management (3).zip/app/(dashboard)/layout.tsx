// Add this to your dashboard layout to ensure consistent navigation
import { Sidebar } from "@/components/sidebar"
import { Header } from "@/components/header"
import type React from "react"
import {
  BarChart3,
  BedDouble,
  CalendarDays,
  CreditCard,
  FileText,
  Home,
  Settings,
  Users,
  UserCircle,
  FileBarChart,
  BookOpen,
  UserCheck,
  UserX,
} from "lucide-react"

interface NavItem {
  title: string
  href: string
  icon: React.ReactNode
  variant: "default" | "ghost"
}

const userRole = "admin" // This would come from your auth system

// Define navigation items based on user role
const getNavItems = (role: string): NavItem[] => {
  const baseItems = [
    {
      title: "Dashboard",
      href: "/dashboard",
      icon: <Home className="h-5 w-5" />,
      variant: "default" as const,
    },
    {
      title: "Bookings",
      href: "/dashboard/bookings",
      icon: <CalendarDays className="h-5 w-5" />,
      variant: "ghost" as const,
    },
    {
      title: "Rooms",
      href: "/dashboard/rooms",
      icon: <BedDouble className="h-5 w-5" />,
      variant: "ghost" as const,
    },
  ]

  // Role-specific items
  if (role === "admin" || role === "manager") {
    return [
      ...baseItems,
      {
        title: "Users",
        href: "/dashboard/users",
        icon: <Users className="h-5 w-5" />,
        variant: "ghost" as const,
      },
      {
        title: "Staff",
        href: "/dashboard/staff",
        icon: <UserCircle className="h-5 w-5" />,
        variant: "ghost" as const,
      },
      {
        title: "Payments",
        href: "/dashboard/payments",
        icon: <CreditCard className="h-5 w-5" />,
        variant: "ghost" as const,
      },
      {
        title: "Reports",
        href: "/dashboard/reports",
        icon: <FileText className="h-5 w-5" />,
        variant: "ghost" as const,
      },
      {
        title: "Analytics",
        href: "/dashboard/analytics",
        icon: <BarChart3 className="h-5 w-5" />,
        variant: "ghost" as const,
      },
      {
        title: "Settings",
        href: "/dashboard/settings",
        icon: <Settings className="h-5 w-5" />,
        variant: "ghost" as const,
      },
      {
        title: "Documentation",
        href: "/dashboard/documentation",
        icon: <BookOpen className="h-5 w-5" />,
        variant: "ghost" as const,
      },
    ]
  } else if (role === "receptionist") {
    return [
      ...baseItems,
      {
        title: "Check-in",
        href: "/dashboard/check-in",
        icon: <UserCheck className="h-5 w-5" />,
        variant: "ghost" as const,
      },
      {
        title: "Check-out",
        href: "/dashboard/check-out",
        icon: <UserX className="h-5 w-5" />,
        variant: "ghost" as const,
      },
      {
        title: "Room Status",
        href: "/dashboard/room-status",
        icon: <BedDouble className="h-5 w-5" />,
        variant: "ghost" as const,
      },
      {
        title: "Documentation",
        href: "/dashboard/documentation",
        icon: <BookOpen className="h-5 w-5" />,
        variant: "ghost" as const,
      },
    ]
  } else if (role === "accountant") {
    return [
      ...baseItems,
      {
        title: "Payments",
        href: "/dashboard/payments",
        icon: <CreditCard className="h-5 w-5" />,
        variant: "ghost" as const,
      },
      {
        title: "Invoices",
        href: "/dashboard/invoices",
        icon: <FileText className="h-5 w-5" />,
        variant: "ghost" as const,
      },
      {
        title: "Reports",
        href: "/dashboard/reports",
        icon: <FileBarChart className="h-5 w-5" />,
        variant: "ghost" as const,
      },
      {
        title: "Documentation",
        href: "/dashboard/documentation",
        icon: <BookOpen className="h-5 w-5" />,
        variant: "ghost" as const,
      },
    ]
  } else {
    // Guest or other roles
    return baseItems
  }
}

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 flex flex-col">
        <Header />
        <main className="flex-1 p-6">{children}</main>
      </div>
    </div>
  )
}

