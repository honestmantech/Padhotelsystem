"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ArrowDownToLine,
  ArrowUpFromLine,
  Check,
  Download,
  Eye,
  FileText,
  Filter,
  MoreHorizontal,
  Plus,
  Printer,
  RefreshCw,
  Search,
  Trash,
  X,
  Edit,
} from "lucide-react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import { format, subDays } from "date-fns"

// Sample payment data
const paymentsData = [
  {
    id: 1,
    bookingId: "B-1001",
    guest: "John Smith",
    amount: 299.97,
    method: "Credit Card",
    status: "completed",
    date: "2023-03-22 14:30:45",
    room: "101",
    type: "booking",
    reference: "TXN-45678",
    processor: "Visa",
  },
  {
    id: 2,
    bookingId: "B-1002",
    guest: "Sarah Johnson",
    amount: 599.96,
    method: "Mobile Money",
    status: "completed",
    date: "2023-03-21 10:15:22",
    room: "202",
    type: "booking",
    reference: "MTN-78945",
    processor: "MTN GH",
  },
  {
    id: 3,
    bookingId: "B-1003",
    guest: "Michael Brown",
    amount: 499.98,
    method: "Cash",
    status: "completed",
    date: "2023-03-20 16:45:10",
    room: "301",
    type: "booking",
    reference: "CASH-12345",
    processor: "N/A",
  },
  {
    id: 4,
    bookingId: "B-1004",
    guest: "Emily Davis",
    amount: 299.97,
    method: "Credit Card",
    status: "pending",
    date: "2023-03-19 09:30:15",
    room: "102",
    type: "booking",
    reference: "TXN-56789",
    processor: "Mastercard",
  },
  {
    id: 5,
    bookingId: "B-1005",
    guest: "Robert Wilson",
    amount: 999.96,
    method: "Bank Transfer",
    status: "failed",
    date: "2023-03-18 11:20:30",
    room: "302",
    type: "booking",
    reference: "BNK-34567",
    processor: "Bank Transfer",
  },
  {
    id: 6,
    bookingId: "B-1006",
    guest: "Jennifer Lee",
    amount: 299.98,
    method: "Mobile Money",
    status: "refunded",
    date: "2023-03-17 15:10:45",
    room: "201",
    type: "booking",
    reference: "MTN-65432",
    processor: "MTN GH",
  },
  {
    id: 7,
    bookingId: "B-1007",
    guest: "David Miller",
    amount: 1199.96,
    method: "Credit Card",
    status: "completed",
    date: "2023-03-16 13:25:50",
    room: "401",
    type: "booking",
    reference: "TXN-87654",
    processor: "Visa",
  },
  {
    id: 8,
    bookingId: "B-1008",
    guest: "Lisa Chen",
    amount: 1199.96,
    method: "Mobile Money",
    status: "pending",
    date: "2023-03-15 17:40:20",
    room: "402",
    type: "booking",
    reference: "MTN-23456",
    processor: "MTN GH",
  },
  {
    id: 9,
    bookingId: "EXP-001",
    guest: "N/A",
    amount: 1500.0,
    method: "Bank Transfer",
    status: "completed",
    date: "2023-03-14 09:15:30",
    room: "N/A",
    type: "expense",
    reference: "BNK-12345",
    processor: "Bank Transfer",
  },
  {
    id: 10,
    bookingId: "EXP-002",
    guest: "N/A",
    amount: 750.25,
    method: "Bank Transfer",
    status: "completed",
    date: "2023-03-13 14:20:15",
    room: "N/A",
    type: "expense",
    reference: "BNK-67890",
    processor: "Bank Transfer",
  },
]

// Payment methods data
const paymentMethodsData = [
  { id: 1, name: "Credit Card", enabled: true, processingFee: "2.5%", settlementTime: "2-3 business days" },
  { id: 2, name: "Mobile Money (MTN GH)", enabled: true, processingFee: "1.5%", settlementTime: "Instant" },
  { id: 3, name: "Cash", enabled: true, processingFee: "0%", settlementTime: "Instant" },
  { id: 4, name: "Bank Transfer", enabled: true, processingFee: "1.0%", settlementTime: "1-2 business days" },
  { id: 5, name: "PayPal", enabled: false, processingFee: "3.5%", settlementTime: "3-5 business days" },
]

// Payment method distribution data for chart
const paymentMethodChartData = [
  { name: "Credit Card", value: 45 },
  { name: "Mobile Money", value: 30 },
  { name: "Cash", value: 15 },
  { name: "Bank Transfer", value: 10 },
]

// Daily payment data for chart
const dailyPaymentData = [
  { name: "Mon", income: 2500, expense: 1200 },
  { name: "Tue", income: 3200, expense: 800 },
  { name: "Wed", income: 4100, expense: 1500 },
  { name: "Thu", income: 3800, expense: 1100 },
  { name: "Fri", income: 4500, expense: 900 },
  { name: "Sat", income: 5200, expense: 700 },
  { name: "Sun", income: 4800, expense: 600 },
]

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042"]

export default function PaymentsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [methodFilter, setMethodFilter] = useState("all")
  const [typeFilter, setTypeFilter] = useState("all")
  const [isAddPaymentOpen, setIsAddPaymentOpen] = useState(false)
  const [isAddMethodOpen, setIsAddMethodOpen] = useState(false)
  const [dateRange, setDateRange] = useState<{
    from: Date | undefined
    to: Date | undefined
  }>({
    from: subDays(new Date(), 7),
    to: new Date(),
  })
  const [isDateFilterOpen, setIsDateFilterOpen] = useState(false)

  // Filter payments based on search term and filters
  const filteredPayments = paymentsData.filter((payment) => {
    const matchesSearch =
      payment.guest.toLowerCase().includes(searchTerm.toLowerCase()) ||
      payment.bookingId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      payment.reference.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || payment.status === statusFilter
    const matchesMethod = methodFilter === "all" || payment.method.toLowerCase().includes(methodFilter.toLowerCase())
    const matchesType = typeFilter === "all" || payment.type === typeFilter

    return matchesSearch && matchesStatus && matchesMethod && matchesType
  })

  // Status badge color mapping
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Completed
          </Badge>
        )
      case "pending":
        return (
          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
            Pending
          </Badge>
        )
      case "failed":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            Failed
          </Badge>
        )
      case "refunded":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Refunded
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  // Calculate total amounts
  const totalIncome = paymentsData
    .filter((p) => p.type === "booking" && p.status === "completed")
    .reduce((sum, payment) => sum + payment.amount, 0)

  const totalExpense = paymentsData
    .filter((p) => p.type === "expense" && p.status === "completed")
    .reduce((sum, payment) => sum + payment.amount, 0)

  const pendingAmount = paymentsData
    .filter((p) => p.status === "pending")
    .reduce((sum, payment) => sum + payment.amount, 0)

  const refundedAmount = paymentsData
    .filter((p) => p.status === "refunded")
    .reduce((sum, payment) => sum + payment.amount, 0)

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Income</CardTitle>
            <ArrowDownToLine className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalIncome.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">
              From {paymentsData.filter((p) => p.type === "booking" && p.status === "completed").length} completed
              bookings
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
            <ArrowUpFromLine className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalExpense.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">
              From {paymentsData.filter((p) => p.type === "expense" && p.status === "completed").length} expense
              transactions
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Payments</CardTitle>
            <RefreshCw className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${pendingAmount.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">
              From {paymentsData.filter((p) => p.status === "pending").length} pending transactions
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Refunded Amount</CardTitle>
            <RefreshCw className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${refundedAmount.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">
              From {paymentsData.filter((p) => p.status === "refunded").length} refunded transactions
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="mb-6">
        <Card>
          <CardHeader className="pb-3">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <div>
                <CardTitle>Payment Trends</CardTitle>
                <CardDescription>Analysis of payment methods and success rates</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <FileText className="mr-2 h-4 w-4" /> Reconciliation Report
                </Button>
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" /> Export Data
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <div className="text-sm font-medium mb-3">Payment Method Distribution</div>
                <div className="h-[200px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={[
                          { name: "Credit Card", value: 45 },
                          { name: "Mobile Money", value: 30 },
                          { name: "Cash", value: 15 },
                          { name: "Bank Transfer", value: 10 },
                        ]}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {paymentMethodChartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => `${value}%`} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div>
                <div className="text-sm font-medium mb-3">Payment Success Rate</div>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Credit Card</span>
                      <span className="font-medium">98.2%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="bg-green-500 h-full rounded-full" style={{ width: "98.2%" }}></div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Mobile Money</span>
                      <span className="font-medium">96.5%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="bg-green-500 h-full rounded-full" style={{ width: "96.5%" }}></div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Bank Transfer</span>
                      <span className="font-medium">92.8%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="bg-green-500 h-full rounded-full" style={{ width: "92.8%" }}></div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Cash</span>
                      <span className="font-medium">100%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="bg-green-500 h-full rounded-full" style={{ width: "100%" }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search payments..."
            className="w-full pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Popover open={isDateFilterOpen} onOpenChange={setIsDateFilterOpen}>
            <PopoverTrigger asChild>
              <Button variant="outline" className="w-full sm:w-auto justify-start">
                <Filter className="mr-2 h-4 w-4" />
                {dateRange.from ? (
                  dateRange.to ? (
                    <>
                      {format(dateRange.from, "LLL dd, y")} - {format(dateRange.to, "LLL dd, y")}
                    </>
                  ) : (
                    format(dateRange.from, "LLL dd, y")
                  )
                ) : (
                  "Date Range"
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="end">
              <Calendar
                initialFocus
                mode="range"
                defaultMonth={dateRange.from}
                selected={dateRange}
                onSelect={(range) => {
                  setDateRange(range as { from: Date | undefined; to: Date | undefined })
                  if (range?.to) {
                    setIsDateFilterOpen(false)
                  }
                }}
                numberOfMonths={2}
              />
            </PopoverContent>
          </Popover>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-[150px]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
              <SelectItem value="refunded">Refunded</SelectItem>
            </SelectContent>
          </Select>

          <Select value={methodFilter} onValueChange={setMethodFilter}>
            <SelectTrigger className="w-full sm:w-[150px]">
              <SelectValue placeholder="Filter by method" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Methods</SelectItem>
              <SelectItem value="credit">Credit Card</SelectItem>
              <SelectItem value="mobile">Mobile Money</SelectItem>
              <SelectItem value="cash">Cash</SelectItem>
              <SelectItem value="bank">Bank Transfer</SelectItem>
            </SelectContent>
          </Select>

          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-full sm:w-[150px]">
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="booking">Income</SelectItem>
              <SelectItem value="expense">Expense</SelectItem>
            </SelectContent>
          </Select>

          <Dialog open={isAddPaymentOpen} onOpenChange={setIsAddPaymentOpen}>
            <DialogTrigger asChild>
              <Button className="w-full sm:w-auto">
                <Plus className="mr-2 h-4 w-4" /> Add Payment
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[550px]">
              <DialogHeader>
                <DialogTitle>Record New Payment</DialogTitle>
                <DialogDescription>Record a new payment transaction in the system.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="payment-type" className="text-right">
                    Type
                  </Label>
                  <Select>
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select payment type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="booking">Income (Booking)</SelectItem>
                      <SelectItem value="expense">Expense</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="booking-id" className="text-right">
                    Booking ID
                  </Label>
                  <Input id="booking-id" placeholder="e.g. B-1001" className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="guest-name" className="text-right">
                    Guest Name
                  </Label>
                  <Input id="guest-name" placeholder="Guest name" className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="amount" className="text-right">
                    Amount
                  </Label>
                  <Input id="amount" type="number" step="0.01" placeholder="0.00" className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="payment-method" className="text-right">
                    Method
                  </Label>
                  <Select>
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select payment method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="credit">Credit Card</SelectItem>
                      <SelectItem value="mobile">Mobile Money (MTN GH)</SelectItem>
                      <SelectItem value="cash">Cash</SelectItem>
                      <SelectItem value="bank">Bank Transfer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="reference" className="text-right">
                    Reference
                  </Label>
                  <Input id="reference" placeholder="Transaction reference" className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="payment-status" className="text-right">
                    Status
                  </Label>
                  <Select>
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddPaymentOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" onClick={() => setIsAddPaymentOpen(false)}>
                  Save Payment
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="transactions" className="space-y-4">
        <TabsList>
          <TabsTrigger value="transactions">Transactions</TabsTrigger>
          <TabsTrigger value="methods">Payment Methods</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="transactions">
          <Card>
            <CardHeader>
              <CardTitle>Payment Transactions</CardTitle>
              <CardDescription>View and manage all payment transactions in the system.</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID/Reference</TableHead>
                    <TableHead>Guest/Description</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Method</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPayments.length > 0 ? (
                    filteredPayments.map((payment) => (
                      <TableRow key={payment.id}>
                        <TableCell>
                          <div className="font-medium">{payment.bookingId}</div>
                          <div className="text-xs text-muted-foreground">{payment.reference}</div>
                        </TableCell>
                        <TableCell>
                          <div>{payment.guest}</div>
                          <div className="text-xs text-muted-foreground">
                            {payment.type === "booking" ? `Room ${payment.room}` : "Expense"}
                          </div>
                        </TableCell>
                        <TableCell>{payment.date}</TableCell>
                        <TableCell className={payment.type === "expense" ? "text-red-600" : "text-green-600"}>
                          {payment.type === "expense" ? "-" : "+"}${payment.amount.toFixed(2)}
                        </TableCell>
                        <TableCell>
                          <div>{payment.method}</div>
                          <div className="text-xs text-muted-foreground">{payment.processor}</div>
                        </TableCell>
                        <TableCell>{getStatusBadge(payment.status)}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Open menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem>
                                <Eye className="mr-2 h-4 w-4" />
                                <span>View Details</span>
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Printer className="mr-2 h-4 w-4" />
                                <span>Print Receipt</span>
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <FileText className="mr-2 h-4 w-4" />
                                <span>Generate Invoice</span>
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              {payment.status === "pending" && (
                                <DropdownMenuItem>
                                  <Check className="mr-2 h-4 w-4 text-green-600" />
                                  <span>Mark as Completed</span>
                                </DropdownMenuItem>
                              )}
                              {payment.status === "completed" && payment.type === "booking" && (
                                <DropdownMenuItem>
                                  <RefreshCw className="mr-2 h-4 w-4 text-blue-600" />
                                  <span>Process Refund</span>
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="text-red-600">
                                <Trash className="mr-2 h-4 w-4" />
                                <span>Delete Transaction</span>
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={7} className="h-24 text-center">
                        No payments found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
            <CardFooter className="flex justify-between">
              <div className="text-sm text-muted-foreground">
                Showing {filteredPayments.length} of {paymentsData.length} transactions
              </div>
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" /> Export
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="methods">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Payment Methods</CardTitle>
                <CardDescription>Configure and manage available payment methods</CardDescription>
              </div>
              <Dialog open={isAddMethodOpen} onOpenChange={setIsAddMethodOpen}>
                <DialogTrigger asChild>
                  <Button size="sm">
                    <Plus className="mr-2 h-4 w-4" /> Add Method
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px]">
                  <DialogHeader>
                    <DialogTitle>Add Payment Method</DialogTitle>
                    <DialogDescription>Configure a new payment method for the system</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="method-name" className="text-right">
                        Method Name
                      </Label>
                      <Input id="method-name" placeholder="e.g. PayPal" className="col-span-3" />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="processing-fee" className="text-right">
                        Processing Fee
                      </Label>
                      <Input id="processing-fee" placeholder="e.g. 2.5%" className="col-span-3" />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="settlement-time" className="text-right">
                        Settlement Time
                      </Label>
                      <Input id="settlement-time" placeholder="e.g. 2-3 business days" className="col-span-3" />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="method-status" className="text-right">
                        Status
                      </Label>
                      <Select>
                        <SelectTrigger className="col-span-3">
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="enabled">Enabled</SelectItem>
                          <SelectItem value="disabled">Disabled</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsAddMethodOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" onClick={() => setIsAddMethodOpen(false)}>
                      Save Method
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Method Name</TableHead>
                    <TableHead>Processing Fee</TableHead>
                    <TableHead>Settlement Time</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paymentMethodsData.map((method) => (
                    <TableRow key={method.id}>
                      <TableCell className="font-medium">{method.name}</TableCell>
                      <TableCell>{method.processingFee}</TableCell>
                      <TableCell>{method.settlementTime}</TableCell>
                      <TableCell>
                        {method.enabled ? (
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            Enabled
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                            Disabled
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <span className="sr-only">Open menu</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem>
                              <Eye className="mr-2 h-4 w-4" />
                              <span>View Details</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" />
                              <span>Edit Method</span>
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            {method.enabled ? (
                              <DropdownMenuItem>
                                <X className="mr-2 h-4 w-4 text-red-600" />
                                <span>Disable Method</span>
                              </DropdownMenuItem>
                            ) : (
                              <DropdownMenuItem>
                                <Check className="mr-2 h-4 w-4 text-green-600" />
                                <span>Enable Method</span>
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
            <Card className="col-span-4">
              <CardHeader>
                <CardTitle>Daily Payment Overview</CardTitle>
                <CardDescription>Income vs Expenses for the past week</CardDescription>
              </CardHeader>
              <CardContent className="pl-2">
                <ResponsiveContainer width="100%" height={350}>
                  <BarChart data={dailyPaymentData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value) => `$${value}`} />
                    <Legend />
                    <Bar dataKey="income" name="Income" fill="#8884d8" />
                    <Bar dataKey="expense" name="Expense" fill="#82ca9d" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            <Card className="col-span-3">
              <CardHeader>
                <CardTitle>Payment Method Distribution</CardTitle>
                <CardDescription>Breakdown of payments by method</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={350}>
                  <PieChart>
                    <Pie
                      data={paymentMethodChartData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {paymentMethodChartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => `${value}%`} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Payment Analytics</CardTitle>
              <CardDescription>Key metrics and insights about payment transactions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                <div className="flex flex-col gap-1">
                  <h3 className="text-lg font-medium">Average Transaction</h3>
                  <p className="text-2xl font-bold">$567.32</p>
                  <p className="text-sm text-muted-foreground">+12.5% from last month</p>
                </div>
                <div className="flex flex-col gap-1">
                  <h3 className="text-lg font-medium">Success Rate</h3>
                  <p className="text-2xl font-bold">94.7%</p>
                  <p className="text-sm text-muted-foreground">+2.1% from last month</p>
                </div>
                <div className="flex flex-col gap-1">
                  <h3 className="text-lg font-medium">Processing Fees</h3>
                  <p className="text-2xl font-bold">$245.89</p>
                  <p className="text-sm text-muted-foreground">1.8% of total volume</p>
                </div>
                <div className="flex flex-col gap-1">
                  <h3 className="text-lg font-medium">Failed Transactions</h3>
                  <p className="text-2xl font-bold">3</p>
                  <p className="text-sm text-muted-foreground">-1 from last month</p>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                <Download className="mr-2 h-4 w-4" /> Download Full Report
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

