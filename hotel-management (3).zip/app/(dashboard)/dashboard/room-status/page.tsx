"use client"

import { Checkbox } from "@/components/ui/checkbox"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BedDouble, CheckCircle, ClipboardCheck, Clock, RefreshCw, Search, Trash, X } from "lucide-react"
import { Separator } from "@/components/ui/separator"
import { toast } from "@/components/ui/use-toast"
import { DocumentExport } from "@/components/document-export"

// Sample room status data
const roomsData = [
  {
    id: 1,
    number: "101",
    type: "Standard",
    floor: "1st",
    status: "occupied",
    guest: "John Smith",
    checkIn: "2023-03-19",
    checkOut: "2023-03-22",
    cleaningStatus: "pending",
    maintenanceStatus: "none",
    notes: "",
  },
  {
    id: 2,
    number: "102",
    type: "Standard",
    floor: "1st",
    status: "vacant",
    guest: "",
    checkIn: "",
    checkOut: "",
    cleaningStatus: "clean",
    maintenanceStatus: "none",
    notes: "",
  },
  {
    id: 3,
    number: "201",
    type: "Deluxe",
    floor: "2nd",
    status: "occupied",
    guest: "Sarah Johnson",
    checkIn: "2023-03-17",
    checkOut: "2023-03-22",
    cleaningStatus: "clean",
    maintenanceStatus: "none",
    notes: "Guest requested extra towels",
  },
  {
    id: 4,
    number: "202",
    type: "Deluxe",
    floor: "2nd",
    status: "vacant",
    guest: "",
    checkIn: "",
    checkOut: "",
    cleaningStatus: "pending",
    maintenanceStatus: "none",
    notes: "",
  },
  {
    id: 5,
    number: "301",
    type: "Suite",
    floor: "3rd",
    status: "occupied",
    guest: "Michael Brown",
    checkIn: "2023-03-18",
    checkOut: "2023-03-22",
    cleaningStatus: "clean",
    maintenanceStatus: "none",
    notes: "",
  },
  {
    id: 6,
    number: "302",
    type: "Suite",
    floor: "3rd",
    status: "vacant",
    guest: "",
    checkIn: "",
    checkOut: "",
    cleaningStatus: "clean",
    maintenanceStatus: "none",
    notes: "",
  },
  {
    id: 7,
    number: "401",
    type: "Executive",
    floor: "4th",
    status: "maintenance",
    guest: "",
    checkIn: "",
    checkOut: "",
    cleaningStatus: "clean",
    maintenanceStatus: "active",
    notes: "AC unit needs repair",
  },
  {
    id: 8,
    number: "402",
    type: "Executive",
    floor: "4th",
    status: "occupied",
    guest: "Emily Davis",
    checkIn: "2023-03-20",
    checkOut: "2023-03-25",
    cleaningStatus: "clean",
    maintenanceStatus: "none",
    notes: "",
  },
]

export default function RoomStatusPage() {
  const [rooms, setRooms] = useState(roomsData)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [typeFilter, setTypeFilter] = useState("all")
  const [cleaningFilter, setCleaningFilter] = useState("all")
  const [selectedRoom, setSelectedRoom] = useState<any>(null)
  const [isUpdateStatusOpen, setIsUpdateStatusOpen] = useState(false)
  const [isCleaningOpen, setIsCleaningOpen] = useState(false)
  const [isMaintenanceOpen, setIsMaintenanceOpen] = useState(false)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [newStatus, setNewStatus] = useState("")
  const [cleaningNotes, setCleaningNotes] = useState("")
  const [maintenanceIssue, setMaintenanceIssue] = useState("")
  const [maintenancePriority, setMaintenancePriority] = useState("medium")

  // Filter rooms based on search term and filters
  const filteredRooms = rooms.filter((room) => {
    const matchesSearch =
      room.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      room.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (room.guest && room.guest.toLowerCase().includes(searchTerm.toLowerCase()))

    const matchesStatus = statusFilter === "all" || room.status === statusFilter
    const matchesType = typeFilter === "all" || room.type === typeFilter
    const matchesCleaning = cleaningFilter === "all" || room.cleaningStatus === cleaningFilter

    return matchesSearch && matchesStatus && matchesType && matchesCleaning
  })

  // Handle updating room status
  const handleUpdateStatus = (room: any) => {
    setSelectedRoom(room)
    setNewStatus(room.status)
    setIsUpdateStatusOpen(true)
  }

  // Handle cleaning status
  const handleCleaning = (room: any) => {
    setSelectedRoom(room)
    setCleaningNotes("")
    setIsCleaningOpen(true)
  }

  // Handle maintenance issue
  const handleMaintenance = (room: any) => {
    setSelectedRoom(room)
    setMaintenanceIssue(room.maintenanceStatus === "active" ? room.notes : "")
    setMaintenancePriority("medium")
    setIsMaintenanceOpen(true)
  }

  // Update room status
  const updateRoomStatus = () => {
    if (!newStatus) {
      toast({
        title: "Status Required",
        description: "Please select a status for the room",
        variant: "destructive",
      })
      return
    }

    // Update the room in our state
    const updatedRooms = rooms.map((room) => {
      if (room.id === selectedRoom.id) {
        return {
          ...room,
          status: newStatus,
          // Clear guest info if setting to vacant or maintenance
          ...(newStatus === "vacant" || newStatus === "maintenance"
            ? {
                guest: "",
                checkIn: "",
                checkOut: "",
              }
            : {}),
        }
      }
      return room
    })

    // Update the state
    setRooms(updatedRooms)

    toast({
      title: "Status Updated",
      description: `Room ${selectedRoom.number} status updated to ${newStatus}`,
    })

    setIsUpdateStatusOpen(false)
  }

  // Mark room as cleaned
  const markRoomCleaned = () => {
    // Update the room in our state
    const updatedRooms = rooms.map((room) => {
      if (room.id === selectedRoom.id) {
        return {
          ...room,
          cleaningStatus: "clean",
          notes: cleaningNotes || room.notes,
        }
      }
      return room
    })

    // Update the state
    setRooms(updatedRooms)

    toast({
      title: "Room Cleaned",
      description: `Room ${selectedRoom.number} has been marked as clean`,
    })

    setIsCleaningOpen(false)
  }

  // Update maintenance status
  const updateMaintenanceStatus = () => {
    if (maintenanceIssue.trim() === "" && selectedRoom.maintenanceStatus !== "active") {
      toast({
        title: "Description Required",
        description: "Please provide a description of the maintenance issue",
        variant: "destructive",
      })
      return
    }

    // Update the room in our state
    const updatedRooms = rooms.map((room) => {
      if (room.id === selectedRoom.id) {
        const isResolving = selectedRoom.maintenanceStatus === "active"
        return {
          ...room,
          maintenanceStatus: isResolving ? "none" : "active",
          status: isResolving ? "vacant" : "maintenance",
          notes: isResolving ? "" : maintenanceIssue,
        }
      }
      return room
    })

    // Update the state
    setRooms(updatedRooms)

    const isResolving = selectedRoom.maintenanceStatus === "active"
    toast({
      title: isResolving ? "Maintenance Resolved" : "Maintenance Reported",
      description: isResolving
        ? `Maintenance issue in Room ${selectedRoom.number} has been resolved`
        : `Maintenance issue reported for Room ${selectedRoom.number}`,
    })

    setIsMaintenanceOpen(false)
  }

  // Simulate refreshing data
  const refreshData = () => {
    setIsRefreshing(true)

    // Simulate API call
    setTimeout(() => {
      setIsRefreshing(false)

      toast({
        title: "Data Refreshed",
        description: "Room status data has been updated",
      })
    }, 1500)
  }

  // Get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "vacant":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Vacant
          </Badge>
        )
      case "occupied":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Occupied
          </Badge>
        )
      case "maintenance":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            Maintenance
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  // Get cleaning status badge
  const getCleaningBadge = (status: string) => {
    switch (status) {
      case "clean":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            <CheckCircle className="mr-1 h-3 w-3" /> Clean
          </Badge>
        )
      case "pending":
        return (
          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
            <Clock className="mr-1 h-3 w-3" /> Pending
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search rooms..."
            className="w-full pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-[150px]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="vacant">Vacant</SelectItem>
              <SelectItem value="occupied">Occupied</SelectItem>
              <SelectItem value="maintenance">Maintenance</SelectItem>
            </SelectContent>
          </Select>

          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-full sm:w-[150px]">
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="Standard">Standard</SelectItem>
              <SelectItem value="Deluxe">Deluxe</SelectItem>
              <SelectItem value="Suite">Suite</SelectItem>
              <SelectItem value="Executive">Executive</SelectItem>
            </SelectContent>
          </Select>

          <Select value={cleaningFilter} onValueChange={setCleaningFilter}>
            <SelectTrigger className="w-full sm:w-[150px]">
              <SelectValue placeholder="Filter by cleaning" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Cleaning</SelectItem>
              <SelectItem value="clean">Clean</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="outline" size="icon" onClick={refreshData} disabled={isRefreshing}>
            <RefreshCw className={`h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
            <span className="sr-only">Refresh</span>
          </Button>
        </div>
      </div>

      <div className="mb-6">
        <Card>
          <CardHeader className="pb-3">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <div>
                <CardTitle>Room Status Overview</CardTitle>
                <CardDescription>Current status of all rooms in the hotel</CardDescription>
              </div>
              <DocumentExport
                documentId="room-status"
                documentName="Room Status Report"
                documentType="report"
                onExport={(format) => {
                  toast({
                    title: "Report Exported",
                    description: `Room status exported as ${format.toUpperCase()}`,
                  })
                }}
              />
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">{rooms.length}</div>
                <div className="text-sm text-blue-700 dark:text-blue-500">Total Rooms</div>
              </div>
              <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border border-green-200 dark:border-green-800">
                <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                  {rooms.filter((room) => room.status === "vacant").length}
                </div>
                <div className="text-sm text-green-700 dark:text-green-500">Vacant</div>
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                  {rooms.filter((room) => room.status === "occupied").length}
                </div>
                <div className="text-sm text-blue-700 dark:text-blue-500">Occupied</div>
              </div>
              <div className="bg-red-50 dark:bg-red-900/20 p-4 rounded-lg border border-red-200 dark:border-red-800">
                <div className="text-2xl font-bold text-red-600 dark:text-red-400">
                  {rooms.filter((room) => room.status === "maintenance").length}
                </div>
                <div className="text-sm text-red-700 dark:text-red-500">Maintenance</div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="text-sm font-medium">Cleaning Status</div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="border rounded-md p-4">
                  <div className="flex justify-between items-center mb-3">
                    <div className="font-medium">Rooms Clean</div>
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      {rooms.filter((room) => room.cleaningStatus === "clean").length} Rooms
                    </Badge>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Clean Rooms</span>
                      <span>
                        {rooms.filter((room) => room.cleaningStatus === "clean").length}/{rooms.length}
                      </span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="bg-green-500 h-full rounded-full"
                        style={{
                          width: `${(rooms.filter((room) => room.cleaningStatus === "clean").length / rooms.length) * 100}%`,
                        }}
                      ></div>
                    </div>
                  </div>
                </div>

                <div className="border rounded-md p-4">
                  <div className="flex justify-between items-center mb-3">
                    <div className="font-medium">Rooms Pending Cleaning</div>
                    <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                      {rooms.filter((room) => room.cleaningStatus === "pending").length} Rooms
                    </Badge>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Pending Cleaning</span>
                      <span>
                        {rooms.filter((room) => room.cleaningStatus === "pending").length}/{rooms.length}
                      </span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="bg-amber-500 h-full rounded-full"
                        style={{
                          width: `${(rooms.filter((room) => room.cleaningStatus === "pending").length / rooms.length) * 100}%`,
                        }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all">All Rooms</TabsTrigger>
          <TabsTrigger value="floor">By Floor</TabsTrigger>
          <TabsTrigger value="cleaning">Cleaning Queue</TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          <Card>
            <CardHeader>
              <CardTitle>Room Status Management</CardTitle>
              <CardDescription>View and manage the status of all rooms in the hotel.</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Room</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Floor</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Guest</TableHead>
                    <TableHead>Cleaning</TableHead>
                    <TableHead>Notes</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRooms.length > 0 ? (
                    filteredRooms.map((room) => (
                      <TableRow key={room.id}>
                        <TableCell className="font-medium">{room.number}</TableCell>
                        <TableCell>{room.type}</TableCell>
                        <TableCell>{room.floor}</TableCell>
                        <TableCell>{getStatusBadge(room.status)}</TableCell>
                        <TableCell>
                          {room.guest ? (
                            <div>
                              <div>{room.guest}</div>
                              <div className="text-xs text-muted-foreground">
                                {room.checkIn} to {room.checkOut}
                              </div>
                            </div>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell>{getCleaningBadge(room.cleaningStatus)}</TableCell>
                        <TableCell>
                          {room.notes ? (
                            <span className="truncate max-w-[150px] block">{room.notes}</span>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button variant="outline" size="sm" onClick={() => handleUpdateStatus(room)}>
                              <BedDouble className="h-4 w-4" />
                              <span className="sr-only">Update Status</span>
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleCleaning(room)}
                              disabled={room.cleaningStatus === "clean"}
                            >
                              <ClipboardCheck className="h-4 w-4" />
                              <span className="sr-only">Mark Clean</span>
                            </Button>
                            <Button
                              variant={room.maintenanceStatus === "active" ? "destructive" : "outline"}
                              size="sm"
                              onClick={() => handleMaintenance(room)}
                            >
                              {room.maintenanceStatus === "active" ? (
                                <X className="h-4 w-4" />
                              ) : (
                                <Trash className="h-4 w-4" />
                              )}
                              <span className="sr-only">
                                {room.maintenanceStatus === "active" ? "Resolve Issue" : "Report Issue"}
                              </span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={8} className="h-24 text-center">
                        No rooms found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="floor">
          <Card>
            <CardHeader>
              <CardTitle>Rooms by Floor</CardTitle>
              <CardDescription>View room status organized by floor.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {["1st", "2nd", "3rd", "4th"].map((floor) => (
                  <div key={floor} className="space-y-2">
                    <h3 className="text-lg font-medium">{floor} Floor</h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                      {rooms
                        .filter((room) => room.floor === floor)
                        .map((room) => (
                          <div
                            key={room.id}
                            className={`border rounded-md p-3 ${
                              room.status === "vacant"
                                ? "bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-800"
                                : room.status === "occupied"
                                  ? "bg-blue-50 border-blue-200 dark:bg-blue-900/20 dark:border-blue-800"
                                  : "bg-red-50 border-red-200 dark:bg-red-900/20 dark:border-red-800"
                            }`}
                          >
                            <div className="flex justify-between items-center mb-2">
                              <span className="font-medium">{room.number}</span>
                              {getStatusBadge(room.status)}
                            </div>
                            <div className="text-sm text-muted-foreground mb-1">{room.type}</div>
                            <div className="text-sm mb-2">
                              {room.guest ? (
                                <span className="truncate block">{room.guest}</span>
                              ) : (
                                <span className="text-muted-foreground">No guest</span>
                              )}
                            </div>
                            <div className="flex justify-between items-center">
                              {getCleaningBadge(room.cleaningStatus)}
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0"
                                onClick={() => handleUpdateStatus(room)}
                              >
                                <BedDouble className="h-4 w-4" />
                                <span className="sr-only">Update</span>
                              </Button>
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="cleaning">
          <Card>
            <CardHeader>
              <CardTitle>Cleaning Queue</CardTitle>
              <CardDescription>Rooms that need cleaning attention.</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Room</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Floor</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Last Guest</TableHead>
                    <TableHead>Cleaning Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rooms.filter((room) => room.cleaningStatus === "pending").length > 0 ? (
                    rooms
                      .filter((room) => room.cleaningStatus === "pending")
                      .map((room) => (
                        <TableRow key={room.id}>
                          <TableCell className="font-medium">{room.number}</TableCell>
                          <TableCell>{room.type}</TableCell>
                          <TableCell>{room.floor}</TableCell>
                          <TableCell>{getStatusBadge(room.status)}</TableCell>
                          <TableCell>
                            {room.guest ? <div>{room.guest}</div> : <span className="text-muted-foreground">-</span>}
                          </TableCell>
                          <TableCell>{getCleaningBadge(room.cleaningStatus)}</TableCell>
                          <TableCell className="text-right">
                            <Button variant="default" size="sm" onClick={() => handleCleaning(room)}>
                              <ClipboardCheck className="mr-2 h-4 w-4" />
                              Mark as Clean
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={7} className="h-24 text-center">
                        No rooms pending cleaning.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Update Status Dialog */}
      {selectedRoom && (
        <Dialog open={isUpdateStatusOpen} onOpenChange={setIsUpdateStatusOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Update Room Status</DialogTitle>
              <DialogDescription>Change the status of Room {selectedRoom.number}.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="room-status">Room Status</Label>
                <Select value={newStatus} onValueChange={setNewStatus}>
                  <SelectTrigger id="room-status">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="vacant">Vacant</SelectItem>
                    <SelectItem value="occupied">Occupied</SelectItem>
                    <SelectItem value="maintenance">Maintenance</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {newStatus === "occupied" && selectedRoom.status !== "occupied" && (
                <div className="space-y-4">
                  <Separator />
                  <div className="space-y-2">
                    <Label htmlFor="guest-name">Guest Name</Label>
                    <Input id="guest-name" placeholder="Enter guest name" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="check-in-date">Check-in Date</Label>
                      <Input id="check-in-date" type="date" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="check-out-date">Check-out Date</Label>
                      <Input id="check-out-date" type="date" />
                    </div>
                  </div>
                </div>
              )}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsUpdateStatusOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" onClick={updateRoomStatus}>
                Update Status
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Cleaning Dialog */}
      {selectedRoom && (
        <Dialog open={isCleaningOpen} onOpenChange={setIsCleaningOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Mark Room as Clean</DialogTitle>
              <DialogDescription>
                Confirm that Room {selectedRoom.number} has been cleaned and is ready for use.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="cleaning-notes">Cleaning Notes (Optional)</Label>
                <Input
                  id="cleaning-notes"
                  placeholder="Add any notes about the cleaning"
                  value={cleaningNotes}
                  onChange={(e) => setCleaningNotes(e.target.value)}
                />
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="cleaning-verified" />
                <Label htmlFor="cleaning-verified">
                  I verify that this room has been properly cleaned and inspected
                </Label>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCleaningOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" onClick={markRoomCleaned}>
                <CheckCircle className="mr-2 h-4 w-4" />
                Mark as Clean
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Maintenance Dialog */}
      {selectedRoom && (
        <Dialog open={isMaintenanceOpen} onOpenChange={setIsMaintenanceOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>
                {selectedRoom.maintenanceStatus === "active" ? "Resolve Maintenance Issue" : "Report Maintenance Issue"}
              </DialogTitle>
              <DialogDescription>
                {selectedRoom.maintenanceStatus === "active"
                  ? `Confirm that the maintenance issue in Room ${selectedRoom.number} has been resolved.`
                  : `Report a maintenance issue for Room ${selectedRoom.number}.`}
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              {selectedRoom.maintenanceStatus === "active" ? (
                <div className="space-y-2">
                  <Label>Current Issue</Label>
                  <div className="p-3 bg-muted rounded-md text-sm">{selectedRoom.notes}</div>
                </div>
              ) : (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="maintenance-issue">Issue Description</Label>
                    <Input
                      id="maintenance-issue"
                      placeholder="Describe the maintenance issue"
                      value={maintenanceIssue}
                      onChange={(e) => setMaintenanceIssue(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="maintenance-priority">Priority</Label>
                    <Select value={maintenancePriority} onValueChange={setMaintenancePriority}>
                      <SelectTrigger id="maintenance-priority">
                        <SelectValue placeholder="Select priority" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="urgent">Urgent</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </>
              )}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsMaintenanceOpen(false)}>
                Cancel
              </Button>
              <Button
                type="submit"
                onClick={updateMaintenanceStatus}
                variant={selectedRoom.maintenanceStatus === "active" ? "default" : "destructive"}
              >
                {selectedRoom.maintenanceStatus === "active" ? (
                  <>
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Mark as Resolved
                  </>
                ) : (
                  <>
                    <Trash className="mr-2 h-4 w-4" />
                    Report Issue
                  </>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}

