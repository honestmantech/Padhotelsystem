"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import { Book, FileQuestion, FileText, HelpCircle, Info, LifeBuoy, Search } from "lucide-react"

export default function DocumentationPage() {
  const [activeTab, setActiveTab] = useState<string>("user-guides")
  const [searchQuery, setSearchQuery] = useState<string>("")

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Documentation</h2>
          <p className="text-muted-foreground">
            Comprehensive guides and documentation for Paddy's View Hotel Management System
          </p>
        </div>
        <div className="relative w-full md:w-80">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search documentation..."
            className="w-full pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {/* Simple tab buttons with interactivity */}
      <div className="flex space-x-2 overflow-x-auto pb-2">
        <Button
          variant={activeTab === "user-guides" ? "default" : "outline"}
          onClick={() => setActiveTab("user-guides")}
          className="flex items-center"
        >
          <Book className="h-4 w-4 mr-2" />
          User Guides
        </Button>
        <Button
          variant={activeTab === "admin-guides" ? "default" : "outline"}
          onClick={() => setActiveTab("admin-guides")}
          className="flex items-center"
        >
          <FileText className="h-4 w-4 mr-2" />
          Admin Guides
        </Button>
        <Button
          variant={activeTab === "api-docs" ? "default" : "outline"}
          onClick={() => setActiveTab("api-docs")}
          className="flex items-center"
        >
          <FileQuestion className="h-4 w-4 mr-2" />
          API References
        </Button>
        <Button
          variant={activeTab === "support" ? "default" : "outline"}
          onClick={() => setActiveTab("support")}
          className="flex items-center"
        >
          <LifeBuoy className="h-4 w-4 mr-2" />
          Support
        </Button>
      </div>

      {/* Main content grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Sidebar */}
        <Card className="md:col-span-1 h-fit">
          <CardHeader className="pb-3">
            <CardTitle>Contents</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="max-h-[calc(100vh-300px)] overflow-y-auto pr-2">
              {activeTab === "user-guides" && (
                <div className="space-y-1">
                  <Button variant="ghost" className="w-full justify-start font-medium">
                    Getting Started
                  </Button>
                  <Button variant="ghost" className="w-full justify-start pl-6 text-muted-foreground">
                    Overview
                  </Button>
                  <Button variant="ghost" className="w-full justify-start pl-6 text-muted-foreground">
                    Logging In
                  </Button>
                </div>
              )}

              {activeTab === "admin-guides" && (
                <div className="space-y-1">
                  <Button variant="ghost" className="w-full justify-start font-medium">
                    System Setup
                  </Button>
                  <Button variant="ghost" className="w-full justify-start pl-6 text-muted-foreground">
                    Initial Configuration
                  </Button>
                </div>
              )}

              {activeTab === "api-docs" && (
                <div className="space-y-1">
                  <Button variant="ghost" className="w-full justify-start font-medium">
                    API Overview
                  </Button>
                  <Button variant="ghost" className="w-full justify-start pl-6 text-muted-foreground">
                    Authentication
                  </Button>
                </div>
              )}

              {activeTab === "support" && (
                <div className="space-y-1">
                  <Button variant="ghost" className="w-full justify-start font-medium">
                    Help Center
                  </Button>
                  <Button variant="ghost" className="w-full justify-start pl-6 text-muted-foreground">
                    Contact Support
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Main content */}
        <div className="md:col-span-3">
          {activeTab === "user-guides" && (
            <Card>
              <CardHeader>
                <CardTitle>Getting Started Guide</CardTitle>
                <CardDescription>Learn the basics of using the hotel management system</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start space-x-4 bg-muted/50 p-4 rounded-lg">
                  <Info className="h-5 w-5 text-blue-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium">Welcome to Paddy's View Hotel Management System</h4>
                    <p className="text-sm text-muted-foreground">
                      This comprehensive guide will help you understand how to use our hotel management system
                      effectively.
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">System Overview</h3>
                  <p>Paddy's View Hotel Management System is designed to streamline all aspects of hotel operations.</p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                    <div className="border rounded-lg p-4">
                      <div className="font-medium mb-2">Dashboard</div>
                      <p className="text-sm text-muted-foreground">
                        Central hub showing key metrics and quick access to common tasks
                      </p>
                    </div>
                    <div className="border rounded-lg p-4">
                      <div className="font-medium mb-2">Bookings</div>
                      <p className="text-sm text-muted-foreground">
                        Manage reservations, modify bookings, and handle cancellations
                      </p>
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="flex justify-end">
                  <Button>Next Section</Button>
                </div>
              </CardContent>
            </Card>
          )}

          {activeTab === "admin-guides" && (
            <Card>
              <CardHeader>
                <CardTitle>Administrator Guide</CardTitle>
                <CardDescription>System configuration and administrative tasks</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start space-x-4 bg-muted/50 p-4 rounded-lg">
                  <HelpCircle className="h-5 w-5 text-blue-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium">Administrator Overview</h4>
                    <p className="text-sm text-muted-foreground">
                      This guide covers all administrative functions of the hotel management system.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {activeTab === "api-docs" && (
            <Card>
              <CardHeader>
                <CardTitle>API Documentation</CardTitle>
                <CardDescription>Integrate with our system using the RESTful API</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start space-x-4 bg-muted/50 p-4 rounded-lg">
                  <Info className="h-5 w-5 text-blue-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium">API Overview</h4>
                    <p className="text-sm text-muted-foreground">
                      Our RESTful API allows you to integrate the hotel management system with other applications.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {activeTab === "support" && (
            <Card>
              <CardHeader>
                <CardTitle>Help & Support</CardTitle>
                <CardDescription>Get assistance with the hotel management system</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start space-x-4 bg-muted/50 p-4 rounded-lg">
                  <LifeBuoy className="h-5 w-5 text-blue-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium">Support Options</h4>
                    <p className="text-sm text-muted-foreground">
                      We offer multiple support channels to help you resolve any issues.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

