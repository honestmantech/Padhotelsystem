"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import {
  Check,
  CreditCard,
  Download,
  Edit,
  Eye,
  Filter,
  Mail,
  MoreHorizontal,
  Plus,
  Printer,
  Search,
  Send,
  Trash,
  X,
  FileText,
} from "lucide-react"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import { format, subDays } from "date-fns"
import { Separator } from "@/components/ui/separator"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
// First, import the DocumentExport component
import { DocumentExport } from "@/components/document-export"

// Sample invoice data
const invoicesData = [
  {
    id: "INV-1001",
    bookingId: "B-1001",
    guest: "John Smith",
    email: "john.smith@example.com",
    issueDate: "2023-03-22",
    dueDate: "2023-03-22",
    amount: 329.97,
    status: "paid",
    paymentMethod: "Credit Card",
    items: [
      { description: "Room 101 - Standard (3 nights)", quantity: 3, unitPrice: 99.99, total: 299.97 },
      { description: "Breakfast Package", quantity: 1, unitPrice: 30.0, total: 30.0 },
    ],
  },
  {
    id: "INV-1002",
    bookingId: "B-1002",
    guest: "Sarah Johnson",
    email: "sarah.johnson@example.com",
    issueDate: "2023-03-21",
    dueDate: "2023-03-21",
    amount: 659.96,
    status: "paid",
    paymentMethod: "Mobile Money",
    items: [
      { description: "Room 202 - Deluxe (4 nights)", quantity: 4, unitPrice: 149.99, total: 599.96 },
      { description: "Airport Transfer", quantity: 1, unitPrice: 60.0, total: 60.0 },
    ],
  },
  {
    id: "INV-1003",
    bookingId: "B-1003",
    guest: "Michael Brown",
    email: "michael.brown@example.com",
    issueDate: "2023-03-20",
    dueDate: "2023-03-24",
    amount: 499.98,
    status: "pending",
    paymentMethod: "Pending",
    items: [{ description: "Room 301 - Suite (2 nights)", quantity: 2, unitPrice: 249.99, total: 499.98 }],
  },
  {
    id: "INV-1004",
    bookingId: "B-1004",
    guest: "Emily Davis",
    email: "emily.davis@example.com",
    issueDate: "2023-03-19",
    dueDate: "2023-03-19",
    amount: 329.97,
    status: "paid",
    paymentMethod: "Credit Card",
    items: [
      { description: "Room 102 - Standard (3 nights)", quantity: 3, unitPrice: 99.99, total: 299.97 },
      { description: "Breakfast Package", quantity: 1, unitPrice: 30.0, total: 30.0 },
    ],
  },
  {
    id: "INV-1005",
    bookingId: "B-1005",
    guest: "Robert Wilson",
    email: "robert.wilson@example.com",
    issueDate: "2023-03-18",
    dueDate: "2023-03-26",
    amount: 1099.96,
    status: "overdue",
    paymentMethod: "Pending",
    items: [
      { description: "Room 302 - Suite (4 nights)", quantity: 4, unitPrice: 249.99, total: 999.96 },
      { description: "Spa Service", quantity: 1, unitPrice: 100.0, total: 100.0 },
    ],
  },
  {
    id: "INV-1006",
    bookingId: "B-1006",
    guest: "Jennifer Lee",
    email: "jennifer.lee@example.com",
    issueDate: "2023-03-17",
    dueDate: "2023-03-17",
    amount: 329.98,
    status: "refunded",
    paymentMethod: "Mobile Money",
    items: [
      { description: "Room 201 - Deluxe (2 nights)", quantity: 2, unitPrice: 149.99, total: 299.98 },
      { description: "Late Check-out Fee", quantity: 1, unitPrice: 30.0, total: 30.0 },
    ],
  },
  {
    id: "INV-1007",
    bookingId: "B-1007",
    guest: "David Miller",
    email: "david.miller@example.com",
    issueDate: "2023-03-16",
    dueDate: "2023-03-16",
    amount: 1319.96,
    status: "paid",
    paymentMethod: "Credit Card",
    items: [
      { description: "Room 401 - Executive (4 nights)", quantity: 4, unitPrice: 299.99, total: 1199.96 },
      { description: "Airport Transfer", quantity: 2, unitPrice: 60.0, total: 120.0 },
    ],
  },
  {
    id: "INV-1008",
    bookingId: "B-1008",
    guest: "Lisa Chen",
    email: "lisa.chen@example.com",
    issueDate: "2023-03-15",
    dueDate: "2023-03-22",
    amount: 1199.96,
    status: "pending",
    paymentMethod: "Pending",
    items: [{ description: "Room 402 - Executive (4 nights)", quantity: 4, unitPrice: 299.99, total: 1199.96 }],
  },
]

export default function InvoicesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [selectedInvoice, setSelectedInvoice] = useState<any>(null)
  const [isViewInvoiceOpen, setIsViewInvoiceOpen] = useState(false)
  const [isCreateInvoiceOpen, setIsCreateInvoiceOpen] = useState(false)
  const [dateRange, setDateRange] = useState<{
    from: Date | undefined
    to: Date | undefined
  }>({
    from: subDays(new Date(), 30),
    to: new Date(),
  })
  const [isDateFilterOpen, setIsDateFilterOpen] = useState(false)

  // Filter invoices based on search term and filters
  const filteredInvoices = invoicesData.filter((invoice) => {
    const matchesSearch =
      invoice.guest.toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.bookingId.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || invoice.status === statusFilter

    return matchesSearch && matchesStatus
  })

  // Status badge color mapping
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Paid
          </Badge>
        )
      case "pending":
        return (
          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
            Pending
          </Badge>
        )
      case "overdue":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            Overdue
          </Badge>
        )
      case "refunded":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Refunded
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  // View invoice details
  const handleViewInvoice = (invoice: any) => {
    setSelectedInvoice(invoice)
    setIsViewInvoiceOpen(true)
  }

  // Calculate totals
  const totalPaid = invoicesData
    .filter((invoice) => invoice.status === "paid")
    .reduce((sum, invoice) => sum + invoice.amount, 0)

  const totalPending = invoicesData
    .filter((invoice) => invoice.status === "pending")
    .reduce((sum, invoice) => sum + invoice.amount, 0)

  const totalOverdue = invoicesData
    .filter((invoice) => invoice.status === "overdue")
    .reduce((sum, invoice) => sum + invoice.amount, 0)

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Paid</CardTitle>
            <Check className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalPaid.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">
              From {invoicesData.filter((invoice) => invoice.status === "paid").length} paid invoices
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Payments</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalPending.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">
              From {invoicesData.filter((invoice) => invoice.status === "pending").length} pending invoices
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overdue Payments</CardTitle>
            <X className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalOverdue.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">
              From {invoicesData.filter((invoice) => invoice.status === "overdue").length} overdue invoices
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="mb-6">
        <Card>
          <CardHeader className="pb-3">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <div>
                <CardTitle>Invoice Aging Analysis</CardTitle>
                <CardDescription>Track outstanding invoices by age</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <Mail className="mr-2 h-4 w-4" /> Send Reminders
                </Button>
                <Button variant="outline" size="sm">
                  <FileText className="mr-2 h-4 w-4" /> Aging Report
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <div className="text-sm font-medium mb-3">Outstanding Invoices by Age</div>
                <div className="h-[200px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={[
                        { name: "Current", value: 12500 },
                        { name: "1-30 days", value: 8500 },
                        { name: "31-60 days", value: 4200 },
                        { name: "61-90 days", value: 2100 },
                        { name: ">90 days", value: 1500 },
                      ]}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip formatter={(value) => `$${value}`} />
                      <Bar dataKey="value" name="Amount" fill="#8884d8" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div>
                <div className="text-sm font-medium mb-3">Invoice Status Distribution</div>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Paid</span>
                      <span className="font-medium">
                        ${totalPaid.toFixed(2)} (
                        {Math.round((totalPaid / (totalPaid + totalPending + totalOverdue)) * 100)}%)
                      </span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="bg-green-500 h-full rounded-full"
                        style={{
                          width: `${Math.round((totalPaid / (totalPaid + totalPending + totalOverdue)) * 100)}%`,
                        }}
                      ></div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Pending</span>
                      <span className="font-medium">
                        ${totalPending.toFixed(2)} (
                        {Math.round((totalPending / (totalPaid + totalPending + totalOverdue)) * 100)}%)
                      </span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="bg-amber-500 h-full rounded-full"
                        style={{
                          width: `${Math.round((totalPending / (totalPaid + totalPending + totalOverdue)) * 100)}%`,
                        }}
                      ></div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Overdue</span>
                      <span className="font-medium">
                        ${totalOverdue.toFixed(2)} (
                        {Math.round((totalOverdue / (totalPaid + totalPending + totalOverdue)) * 100)}%)
                      </span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="bg-red-500 h-full rounded-full"
                        style={{
                          width: `${Math.round((totalOverdue / (totalPaid + totalPending + totalOverdue)) * 100)}%`,
                        }}
                      ></div>
                    </div>
                  </div>

                  <div className="pt-2">
                    <div className="text-sm font-medium mb-2">Collection Efficiency</div>
                    <div className="flex items-center gap-2">
                      <div className="text-2xl font-bold text-green-600 dark:text-green-400">92.5%</div>
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        +2.3% vs Last Month
                      </Badge>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search invoices..."
            className="w-full pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Popover open={isDateFilterOpen} onOpenChange={setIsDateFilterOpen}>
            <PopoverTrigger asChild>
              <Button variant="outline" className="w-full sm:w-auto justify-start">
                <Filter className="mr-2 h-4 w-4" />
                {dateRange.from ? (
                  dateRange.to ? (
                    <>
                      {format(dateRange.from, "LLL dd, y")} - {format(dateRange.to, "LLL dd, y")}
                    </>
                  ) : (
                    format(dateRange.from, "LLL dd, y")
                  )
                ) : (
                  "Date Range"
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="end">
              <Calendar
                initialFocus
                mode="range"
                defaultMonth={dateRange.from}
                selected={dateRange}
                onSelect={(range) => {
                  setDateRange(range as { from: Date | undefined; to: Date | undefined })
                  if (range?.to) {
                    setIsDateFilterOpen(false)
                  }
                }}
                numberOfMonths={2}
              />
            </PopoverContent>
          </Popover>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-[150px]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="paid">Paid</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="overdue">Overdue</SelectItem>
              <SelectItem value="refunded">Refunded</SelectItem>
            </SelectContent>
          </Select>

          <Dialog open={isCreateInvoiceOpen} onOpenChange={setIsCreateInvoiceOpen}>
            <DialogTrigger asChild>
              <Button className="w-full sm:w-auto">
                <Plus className="mr-2 h-4 w-4" /> Create Invoice
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Create New Invoice</DialogTitle>
                <DialogDescription>Create a new invoice for a guest or booking.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="invoice-type">Invoice Type</Label>
                    <Select>
                      <SelectTrigger id="invoice-type">
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="booking">Booking Invoice</SelectItem>
                        <SelectItem value="service">Service Invoice</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="booking-id">Booking ID</Label>
                    <Select>
                      <SelectTrigger id="booking-id">
                        <SelectValue placeholder="Select booking" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="B-1001">B-1001 - John Smith</SelectItem>
                        <SelectItem value="B-1002">B-1002 - Sarah Johnson</SelectItem>
                        <SelectItem value="B-1003">B-1003 - Michael Brown</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="guest-name">Guest Name</Label>
                    <Input id="guest-name" placeholder="Guest name" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="guest-email">Email</Label>
                    <Input id="guest-email" type="email" placeholder="Guest email" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="issue-date">Issue Date</Label>
                    <Input id="issue-date" type="date" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="due-date">Due Date</Label>
                    <Input id="due-date" type="date" />
                  </div>
                </div>

                <Separator />

                <div>
                  <h3 className="text-sm font-medium mb-2">Invoice Items</h3>
                  <div className="space-y-4">
                    <div className="grid grid-cols-12 gap-2">
                      <div className="col-span-6">
                        <Label htmlFor="item-description-1">Description</Label>
                        <Input id="item-description-1" placeholder="Item description" />
                      </div>
                      <div className="col-span-2">
                        <Label htmlFor="item-quantity-1">Qty</Label>
                        <Input id="item-quantity-1" type="number" min="1" defaultValue="1" />
                      </div>
                      <div className="col-span-2">
                        <Label htmlFor="item-price-1">Price</Label>
                        <Input id="item-price-1" type="number" step="0.01" placeholder="0.00" />
                      </div>
                      <div className="col-span-2">
                        <Label htmlFor="item-total-1">Total</Label>
                        <Input id="item-total-1" type="number" step="0.01" placeholder="0.00" disabled />
                      </div>
                    </div>

                    <Button variant="outline" size="sm" className="w-full">
                      <Plus className="mr-2 h-4 w-4" /> Add Item
                    </Button>
                  </div>
                </div>

                <div className="flex justify-between items-center pt-4">
                  <span className="font-medium">Subtotal:</span>
                  <span>$0.00</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-medium">Tax (10%):</span>
                  <span>$0.00</span>
                </div>
                <div className="flex justify-between items-center text-lg font-bold">
                  <span>Total:</span>
                  <span>$0.00</span>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="invoice-notes">Notes</Label>
                  <Input id="invoice-notes" placeholder="Additional notes for this invoice" />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsCreateInvoiceOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" onClick={() => setIsCreateInvoiceOpen(false)}>
                  Create Invoice
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Invoices</CardTitle>
          <CardDescription>Manage all invoices in the system. View, send, or process payments.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Invoice</TableHead>
                <TableHead>Guest</TableHead>
                <TableHead>Issue Date</TableHead>
                <TableHead>Due Date</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredInvoices.length > 0 ? (
                filteredInvoices.map((invoice) => (
                  <TableRow key={invoice.id}>
                    <TableCell>
                      <div className="font-medium">{invoice.id}</div>
                      <div className="text-xs text-muted-foreground">{invoice.bookingId}</div>
                    </TableCell>
                    <TableCell>
                      <div>{invoice.guest}</div>
                      <div className="text-xs text-muted-foreground">{invoice.email}</div>
                    </TableCell>
                    <TableCell>{invoice.issueDate}</TableCell>
                    <TableCell>{invoice.dueDate}</TableCell>
                    <TableCell>${invoice.amount.toFixed(2)}</TableCell>
                    <TableCell>{getStatusBadge(invoice.status)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <span className="sr-only">Open menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuItem onClick={() => handleViewInvoice(invoice)}>
                            <Eye className="mr-2 h-4 w-4" />
                            <span>View Invoice</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Download className="mr-2 h-4 w-4" />
                            <span>Download PDF</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Printer className="mr-2 h-4 w-4" />
                            <span>Print Invoice</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Send className="mr-2 h-4 w-4" />
                            <span>Email to Guest</span>
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          {invoice.status === "pending" && (
                            <DropdownMenuItem>
                              <CreditCard className="mr-2 h-4 w-4 text-green-600" />
                              <span>Record Payment</span>
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuItem>
                            <Edit className="mr-2 h-4 w-4" />
                            <span>Edit Invoice</span>
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-red-600">
                            <Trash className="mr-2 h-4 w-4" />
                            <span>Delete Invoice</span>
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={7} className="h-24 text-center">
                    No invoices found.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
        <CardFooter className="flex justify-between">
          <div className="text-sm text-muted-foreground">
            Showing {filteredInvoices.length} of {invoicesData.length} invoices
          </div>
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" /> Export
          </Button>
        </CardFooter>
      </Card>

      {/* View Invoice Dialog */}
      {selectedInvoice && (
        <Dialog open={isViewInvoiceOpen} onOpenChange={setIsViewInvoiceOpen}>
          <DialogContent className="sm:max-w-[700px]">
            <DialogHeader>
              <DialogTitle>Invoice {selectedInvoice.id}</DialogTitle>
              <DialogDescription>Invoice details for {selectedInvoice.guest}.</DialogDescription>
            </DialogHeader>
            <div className="space-y-6">
              <div className="flex justify-between">
                <div>
                  <h3 className="text-lg font-bold">Paddy's View Hotel</h3>
                  <p className="text-sm text-muted-foreground">123 Hotel Street, Accra, Ghana</p>
                  <p className="text-sm text-muted-foreground">info@paddysviewhotel.com</p>
                  <p className="text-sm text-muted-foreground">+233 20 123 4567</p>
                </div>
                <div className="text-right">
                  <h3 className="text-lg font-bold">Invoice</h3>
                  <p className="text-sm">{selectedInvoice.id}</p>
                  <p className="text-sm">Issue Date: {selectedInvoice.issueDate}</p>
                  <p className="text-sm">Due Date: {selectedInvoice.dueDate}</p>
                </div>
              </div>

              <Separator />

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium mb-1">Bill To:</h4>
                  <p className="text-sm font-bold">{selectedInvoice.guest}</p>
                  <p className="text-sm">{selectedInvoice.email}</p>
                  <p className="text-sm">Booking ID: {selectedInvoice.bookingId}</p>
                </div>
                <div className="text-right">
                  <h4 className="text-sm font-medium mb-1">Status:</h4>
                  <div>{getStatusBadge(selectedInvoice.status)}</div>
                  {selectedInvoice.status === "paid" && (
                    <p className="text-sm mt-1">Paid via {selectedInvoice.paymentMethod}</p>
                  )}
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium mb-2">Invoice Items:</h4>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Description</TableHead>
                      <TableHead className="text-right">Qty</TableHead>
                      <TableHead className="text-right">Unit Price</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedInvoice.items.map((item: any, index: number) => (
                      <TableRow key={index}>
                        <TableCell>{item.description}</TableCell>
                        <TableCell className="text-right">{item.quantity}</TableCell>
                        <TableCell className="text-right">${item.unitPrice.toFixed(2)}</TableCell>
                        <TableCell className="text-right">${item.total.toFixed(2)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div className="flex flex-col items-end space-y-2">
                <div className="flex w-[200px] justify-between">
                  <span className="font-medium">Subtotal:</span>
                  <span>${selectedInvoice.amount.toFixed(2)}</span>
                </div>
                <div className="flex w-[200px] justify-between">
                  <span className="font-medium">Tax (0%):</span>
                  <span>$0.00</span>
                </div>
                <div className="flex w-[200px] justify-between text-lg font-bold">
                  <span>Total:</span>
                  <span>${selectedInvoice.amount.toFixed(2)}</span>
                </div>
              </div>

              <Separator />

              <div className="text-sm text-muted-foreground">
                <p className="font-medium">Payment Terms:</p>
                <p>Payment is due immediately upon receipt of this invoice.</p>
                <p className="mt-2">Thank you for choosing Paddy's View Hotel!</p>
              </div>
            </div>
            <DialogFooter className="flex-col space-y-4">
              <DocumentExport
                title="Export Invoice"
                description={`Export invoice ${selectedInvoice.id} for ${selectedInvoice.guest}`}
                documentType="invoice"
                allowedFormats={["pdf", "docx"]}
                onExport={(format, options) => {
                  console.log("Exporting invoice:", { format, options, invoice: selectedInvoice })
                  // Here you would implement the actual export functionality
                  setIsViewInvoiceOpen(false)
                }}
              >
                <div className="text-sm text-muted-foreground">
                  This will generate a professional invoice document that can be downloaded, printed, or emailed to the
                  guest.
                </div>
              </DocumentExport>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}

