"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Bed, Check, Edit, MoreHorizontal, Plus, Search, Trash, X } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Sample room data
const roomsData = [
  {
    id: 1,
    number: "101",
    type: "Standard",
    capacity: 2,
    price: 99.99,
    status: "available",
    amenities: ["Wi-Fi", "TV", "AC"],
    floor: "1st",
  },
  {
    id: 2,
    number: "102",
    type: "Standard",
    capacity: 2,
    price: 99.99,
    status: "occupied",
    amenities: ["Wi-Fi", "TV", "AC"],
    floor: "1st",
  },
  {
    id: 3,
    number: "201",
    type: "Deluxe",
    capacity: 3,
    price: 149.99,
    status: "maintenance",
    amenities: ["Wi-Fi", "TV", "AC", "Mini Bar"],
    floor: "2nd",
  },
  {
    id: 4,
    number: "202",
    type: "Deluxe",
    capacity: 3,
    price: 149.99,
    status: "available",
    amenities: ["Wi-Fi", "TV", "AC", "Mini Bar"],
    floor: "2nd",
  },
  {
    id: 5,
    number: "301",
    type: "Suite",
    capacity: 4,
    price: 249.99,
    status: "available",
    amenities: ["Wi-Fi", "TV", "AC", "Mini Bar", "Jacuzzi"],
    floor: "3rd",
  },
  {
    id: 6,
    number: "302",
    type: "Suite",
    capacity: 4,
    price: 249.99,
    status: "occupied",
    amenities: ["Wi-Fi", "TV", "AC", "Mini Bar", "Jacuzzi"],
    floor: "3rd",
  },
  {
    id: 7,
    number: "401",
    type: "Executive",
    capacity: 2,
    price: 299.99,
    status: "available",
    amenities: ["Wi-Fi", "TV", "AC", "Mini Bar", "Jacuzzi", "Balcony"],
    floor: "4th",
  },
  {
    id: 8,
    number: "402",
    type: "Executive",
    capacity: 2,
    price: 299.99,
    status: "occupied",
    amenities: ["Wi-Fi", "TV", "AC", "Mini Bar", "Jacuzzi", "Balcony"],
    floor: "4th",
  },
]

// Room types data
const roomTypes = [
  { id: 1, name: "Standard", basePrice: 99.99, description: "Basic room with essential amenities" },
  { id: 2, name: "Deluxe", basePrice: 149.99, description: "Comfortable room with additional amenities" },
  { id: 3, name: "Suite", basePrice: 249.99, description: "Spacious suite with premium amenities" },
  { id: 4, name: "Executive", basePrice: 299.99, description: "Luxury room with all premium amenities and services" },
]

export default function RoomsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [typeFilter, setTypeFilter] = useState("all")
  const [isAddRoomOpen, setIsAddRoomOpen] = useState(false)
  const [isAddRoomTypeOpen, setIsAddRoomTypeOpen] = useState(false)

  // Filter rooms based on search term and filters
  const filteredRooms = roomsData.filter((room) => {
    const matchesSearch =
      room.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      room.type.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || room.status === statusFilter
    const matchesType = typeFilter === "all" || room.type === typeFilter

    return matchesSearch && matchesStatus && matchesType
  })

  // Status badge color mapping
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "available":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Available
          </Badge>
        )
      case "occupied":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Occupied
          </Badge>
        )
      case "maintenance":
        return (
          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
            Maintenance
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search rooms..."
            className="w-full pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-[150px]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="available">Available</SelectItem>
              <SelectItem value="occupied">Occupied</SelectItem>
              <SelectItem value="maintenance">Maintenance</SelectItem>
            </SelectContent>
          </Select>

          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-full sm:w-[150px]">
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              {roomTypes.map((type) => (
                <SelectItem key={type.id} value={type.name}>
                  {type.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Dialog open={isAddRoomOpen} onOpenChange={setIsAddRoomOpen}>
            <DialogTrigger asChild>
              <Button className="w-full sm:w-auto">
                <Plus className="mr-2 h-4 w-4" /> Add Room
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Add New Room</DialogTitle>
                <DialogDescription>Create a new room in the system. Click save when you're done.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="room-number" className="text-right">
                    Room Number
                  </Label>
                  <Input id="room-number" placeholder="e.g. 101" className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="room-type" className="text-right">
                    Room Type
                  </Label>
                  <Select>
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select room type" />
                    </SelectTrigger>
                    <SelectContent>
                      {roomTypes.map((type) => (
                        <SelectItem key={type.id} value={type.name}>
                          {type.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="room-capacity" className="text-right">
                    Capacity
                  </Label>
                  <Input id="room-capacity" type="number" placeholder="e.g. 2" className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="room-price" className="text-right">
                    Price
                  </Label>
                  <Input id="room-price" type="number" step="0.01" placeholder="e.g. 99.99" className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="room-floor" className="text-right">
                    Floor
                  </Label>
                  <Input id="room-floor" placeholder="e.g. 1st" className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="room-status" className="text-right">
                    Status
                  </Label>
                  <Select>
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="available">Available</SelectItem>
                      <SelectItem value="occupied">Occupied</SelectItem>
                      <SelectItem value="maintenance">Maintenance</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddRoomOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" onClick={() => setIsAddRoomOpen(false)}>
                  Save Room
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="mb-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle>Room Status Overview</CardTitle>
            <CardDescription>Quick view of room availability and occupancy</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
              <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border border-green-200 dark:border-green-800">
                <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                  {roomsData.filter((room) => room.status === "available").length}
                </div>
                <div className="text-sm text-green-700 dark:text-green-500">Available Rooms</div>
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                  {roomsData.filter((room) => room.status === "occupied").length}
                </div>
                <div className="text-sm text-blue-700 dark:text-blue-500">Occupied Rooms</div>
              </div>
              <div className="bg-amber-50 dark:bg-amber-900/20 p-4 rounded-lg border border-amber-200 dark:border-amber-800">
                <div className="text-2xl font-bold text-amber-600 dark:text-amber-400">
                  {roomsData.filter((room) => room.status === "maintenance").length}
                </div>
                <div className="text-sm text-amber-700 dark:text-amber-500">Maintenance</div>
              </div>
              <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-lg border border-purple-200 dark:border-purple-800">
                <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">{roomsData.length}</div>
                <div className="text-sm text-purple-700 dark:text-purple-500">Total Rooms</div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {roomTypes.map((type) => (
                <div key={type.id} className="flex items-center justify-between p-3 border rounded-md">
                  <div>
                    <div className="font-medium">{type.name}</div>
                    <div className="text-sm text-muted-foreground">${type.basePrice.toFixed(2)}/night</div>
                  </div>
                  <div className="text-sm">
                    <span className="font-medium">
                      {roomsData.filter((room) => room.type === type.name && room.status === "available").length}
                    </span>
                    /{roomsData.filter((room) => room.type === type.name).length} available
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="rooms" className="space-y-4">
        <TabsList>
          <TabsTrigger value="rooms">Rooms</TabsTrigger>
          <TabsTrigger value="types">Room Types</TabsTrigger>
        </TabsList>

        <TabsContent value="rooms">
          <Card>
            <CardHeader>
              <CardTitle>Room Management</CardTitle>
              <CardDescription>Manage all rooms in the hotel. Add, edit, or change room status.</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Room</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Capacity</TableHead>
                    <TableHead>Price</TableHead>
                    <TableHead>Floor</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRooms.length > 0 ? (
                    filteredRooms.map((room) => (
                      <TableRow key={room.id}>
                        <TableCell className="font-medium">{room.number}</TableCell>
                        <TableCell>{room.type}</TableCell>
                        <TableCell>{room.capacity} persons</TableCell>
                        <TableCell>${room.price.toFixed(2)}</TableCell>
                        <TableCell>{room.floor}</TableCell>
                        <TableCell>{getStatusBadge(room.status)}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Open menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem>
                                <Edit className="mr-2 h-4 w-4" />
                                <span>Edit Room</span>
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>
                                <Check className="mr-2 h-4 w-4 text-green-600" />
                                <span>Set Available</span>
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Bed className="mr-2 h-4 w-4 text-blue-600" />
                                <span>Set Occupied</span>
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <X className="mr-2 h-4 w-4 text-amber-600" />
                                <span>Set Maintenance</span>
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="text-red-600">
                                <Trash className="mr-2 h-4 w-4" />
                                <span>Delete Room</span>
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={7} className="h-24 text-center">
                        No rooms found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
            <CardFooter className="flex justify-between">
              <div className="text-sm text-muted-foreground">
                Showing {filteredRooms.length} of {roomsData.length} rooms
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="types">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Room Types</CardTitle>
                <CardDescription>Manage room types and their base pricing</CardDescription>
              </div>
              <Dialog open={isAddRoomTypeOpen} onOpenChange={setIsAddRoomTypeOpen}>
                <DialogTrigger asChild>
                  <Button size="sm">
                    <Plus className="mr-2 h-4 w-4" /> Add Room Type
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px]">
                  <DialogHeader>
                    <DialogTitle>Add New Room Type</DialogTitle>
                    <DialogDescription>Create a new room type with base pricing</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="type-name" className="text-right">
                        Type Name
                      </Label>
                      <Input id="type-name" placeholder="e.g. Deluxe" className="col-span-3" />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="base-price" className="text-right">
                        Base Price
                      </Label>
                      <Input
                        id="base-price"
                        type="number"
                        step="0.01"
                        placeholder="e.g. 149.99"
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="type-description" className="text-right">
                        Description
                      </Label>
                      <Input
                        id="type-description"
                        placeholder="Brief description of the room type"
                        className="col-span-3"
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsAddRoomTypeOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" onClick={() => setIsAddRoomTypeOpen(false)}>
                      Save Room Type
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Type Name</TableHead>
                    <TableHead>Base Price</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {roomTypes.map((type) => (
                    <TableRow key={type.id}>
                      <TableCell className="font-medium">{type.name}</TableCell>
                      <TableCell>${type.basePrice.toFixed(2)}</TableCell>
                      <TableCell>{type.description}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <span className="sr-only">Open menu</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" />
                              <span>Edit Type</span>
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-red-600">
                              <Trash className="mr-2 h-4 w-4" />
                              <span>Delete Type</span>
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

