import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  ArrowDownIcon,
  ArrowUpIcon,
  CalendarCheck,
  CreditCard,
  DollarSign,
  Users,
  UserCheck,
  BedDouble,
  Receipt,
} from "lucide-react"

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$45,231.89</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500 inline-flex items-center">
                <ArrowUpIcon className="mr-1 h-3 w-3" />
                +20.1%
              </span>{" "}
              from last month
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Bookings</CardTitle>
            <CalendarCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">+2350</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500 inline-flex items-center">
                <ArrowUpIcon className="mr-1 h-3 w-3" />
                +180
              </span>{" "}
              from last month
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Room Occupancy</CardTitle>
            <BedDouble className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">78%</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500 inline-flex items-center">
                <ArrowUpIcon className="mr-1 h-3 w-3" />
                +5%
              </span>{" "}
              from last month
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Guests</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">132</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-red-500 inline-flex items-center">
                <ArrowDownIcon className="mr-1 h-3 w-3" />
                -2
              </span>{" "}
              from yesterday
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="mb-6">
        <h3 className="text-lg font-medium mb-3">Quick Actions</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Button variant="outline" className="h-20 flex flex-col items-center justify-center gap-1" asChild>
            <a href="/dashboard/bookings">
              <CalendarCheck className="h-6 w-6 mb-1" />
              <span>New Booking</span>
            </a>
          </Button>
          <Button variant="outline" className="h-20 flex flex-col items-center justify-center gap-1" asChild>
            <a href="/dashboard/check-in">
              <UserCheck className="h-6 w-6 mb-1" />
              <span>Check-in Guest</span>
            </a>
          </Button>
          <Button variant="outline" className="h-20 flex flex-col items-center justify-center gap-1" asChild>
            <a href="/dashboard/rooms">
              <BedDouble className="h-6 w-6 mb-1" />
              <span>Room Status</span>
            </a>
          </Button>
          <Button variant="outline" className="h-20 flex flex-col items-center justify-center gap-1" asChild>
            <a href="/dashboard/payments">
              <Receipt className="h-6 w-6 mb-1" />
              <span>New Payment</span>
            </a>
          </Button>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center space-x-4">
          <Button variant="outline" className="w-full">
            Overview
          </Button>
          <Button variant="outline" className="w-full">
            Analytics
          </Button>
          <Button variant="outline" className="w-full">
            Reports
          </Button>
        </div>

        <div className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
            <Card className="col-span-4">
              <CardHeader>
                <CardTitle>Booking Overview</CardTitle>
                <CardDescription>Monthly booking trends for the current year</CardDescription>
              </CardHeader>
              <CardContent className="pl-2">
                <div className="h-[350px] flex items-center justify-center bg-muted/20 rounded-md">
                  <p className="text-muted-foreground">Booking chart visualization</p>
                </div>
              </CardContent>
            </Card>
            <Card className="col-span-3">
              <CardHeader>
                <CardTitle>Room Type Distribution</CardTitle>
                <CardDescription>Current bookings by room type</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[350px] flex items-center justify-center bg-muted/20 rounded-md">
                  <p className="text-muted-foreground">Room type distribution chart</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Recent Bookings</CardTitle>
                <CardDescription>Latest 5 bookings in the system</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="flex items-center">
                      <div className="mr-4 rounded-full bg-primary/10 p-2">
                        <CalendarCheck className="h-4 w-4 text-primary" />
                      </div>
                      <div className="flex-1 space-y-1">
                        <p className="text-sm font-medium leading-none">
                          Room {101 + i} - {["Standard", "Deluxe", "Suite", "Executive", "Standard"][i]}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {["John Smith", "Sarah Johnson", "Michael Brown", "Emily Davis", "Robert Wilson"][i]}
                        </p>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {["2 hours", "5 hours", "Yesterday", "2 days", "3 days"][i]} ago
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recent Payments</CardTitle>
                <CardDescription>Latest 5 payments received</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="flex items-center">
                      <div className="mr-4 rounded-full bg-primary/10 p-2">
                        <CreditCard className="h-4 w-4 text-primary" />
                      </div>
                      <div className="flex-1 space-y-1">
                        <p className="text-sm font-medium leading-none">${[350, 420, 180, 550, 290][i]}</p>
                        <p className="text-xs text-muted-foreground">Booking #{1234 + i}</p>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {["1 hour", "3 hours", "Yesterday", "2 days", "3 days"][i]} ago
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Upcoming Check-ins</CardTitle>
                <CardDescription>Guests arriving today</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="flex items-center">
                      <div className="mr-4 rounded-full bg-primary/10 p-2">
                        <Users className="h-4 w-4 text-primary" />
                      </div>
                      <div className="flex-1 space-y-1">
                        <p className="text-sm font-medium leading-none">
                          {["James Wilson", "Maria Garcia", "David Lee", "Lisa Chen", "Thomas Moore"][i]}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Room {201 + i} - {["2 nights", "3 nights", "1 night", "5 nights", "2 nights"][i]}
                        </p>
                      </div>
                      <div className="text-sm text-muted-foreground">{["1 PM", "2 PM", "3 PM", "4 PM", "5 PM"][i]}</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

