"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { CalendarIcon, Edit, Eye, MoreHorizontal, Plus, Search, X } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

// Sample booking data
const bookingsData = [
  {
    id: 1,
    bookingId: "B-1001",
    guest: "John Smith",
    email: "john.smith@example.com",
    phone: "+233 20 123 4567",
    roomType: "Standard",
    roomNumber: "101",
    checkIn: "2023-04-15",
    checkOut: "2023-04-18",
    status: "confirmed",
    adults: 2,
    children: 0,
    totalAmount: 299.97,
    paymentStatus: "paid",
    createdAt: "2023-03-20 14:30:45",
  },
  {
    id: 2,
    bookingId: "B-1002",
    guest: "Sarah Johnson",
    email: "sarah.johnson@example.com",
    phone: "+233 24 987 6543",
    roomType: "Deluxe",
    roomNumber: "202",
    checkIn: "2023-04-16",
    checkOut: "2023-04-21",
    status: "confirmed",
    adults: 2,
    children: 1,
    totalAmount: 599.96,
    paymentStatus: "paid",
    createdAt: "2023-03-21 09:15:22",
  },
  {
    id: 3,
    bookingId: "B-1003",
    guest: "Michael Brown",
    email: "michael.brown@example.com",
    phone: "+233 27 456 7890",
    roomType: "Suite",
    roomNumber: "301",
    checkIn: "2023-04-17",
    checkOut: "2023-04-20",
    status: "pending",
    adults: 2,
    children: 0,
    totalAmount: 499.98,
    paymentStatus: "pending",
    createdAt: "2023-03-21 16:45:10",
  },
  {
    id: 4,
    bookingId: "B-1004",
    guest: "Emily Davis",
    email: "emily.davis@example.com",
    phone: "+233 23 345 6789",
    roomType: "Standard",
    roomNumber: "102",
    checkIn: "2023-04-18",
    checkOut: "2023-04-24",
    status: "confirmed",
    adults: 1,
    children: 0,
    totalAmount: 599.94,
    paymentStatus: "paid",
    createdAt: "2023-03-22 10:20:33",
  },
  {
    id: 5,
    bookingId: "B-1005",
    guest: "Robert Wilson",
    email: "robert.wilson@example.com",
    phone: "+233 26 789 0123",
    roomType: "Suite",
    roomNumber: "302",
    checkIn: "2023-04-20",
    checkOut: "2023-04-28",
    status: "confirmed",
    adults: 2,
    children: 2,
    totalAmount: 999.96,
    paymentStatus: "pending",
    createdAt: "2023-03-22 14:10:45",
  },
  {
    id: 6,
    bookingId: "B-1006",
    guest: "Jennifer Lee",
    email: "jennifer.lee@example.com",
    phone: "+233 20 234 5678",
    roomType: "Deluxe",
    roomNumber: "201",
    checkIn: "2023-04-22",
    checkOut: "2023-04-25",
    status: "cancelled",
    adults: 2,
    children: 1,
    totalAmount: 449.97,
    paymentStatus: "refunded",
    createdAt: "2023-03-23 09:30:15",
  },
]

export default function BookingsPage() {
  const [bookings, setBookings] = useState(bookingsData)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [dateFilter, setDateFilter] = useState<Date | undefined>(undefined)
  const [isAddBookingOpen, setIsAddBookingOpen] = useState(false)
  const [selectedBooking, setSelectedBooking] = useState<any>(null)
  const [isViewBookingOpen, setIsViewBookingOpen] = useState(false)
  const [isEditBookingOpen, setIsEditBookingOpen] = useState(false)
  const [isCancelBookingOpen, setIsCancelBookingOpen] = useState(false)

  // New booking form state
  const [newBooking, setNewBooking] = useState({
    guest: "",
    email: "",
    phone: "",
    roomType: "",
    checkIn: "",
    checkOut: "",
    adults: 1,
    children: 0,
  })

  // Filter bookings based on search term, status, and date
  const filteredBookings = bookings.filter((booking) => {
    const matchesSearch =
      booking.guest.toLowerCase().includes(searchTerm.toLowerCase()) ||
      booking.bookingId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      booking.email.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || booking.status === statusFilter

    const matchesDate = !dateFilter || booking.checkIn === format(dateFilter, "yyyy-MM-dd")

    return matchesSearch && matchesStatus && matchesDate
  })

  // Handle adding a new booking
  const handleAddBooking = () => {
    // Validate form
    if (!newBooking.guest || !newBooking.email || !newBooking.roomType || !newBooking.checkIn || !newBooking.checkOut) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    // Create new booking object
    const bookingId = `B-${1000 + bookings.length + 1}`
    const now = new Date()
    const createdAt = format(now, "yyyy-MM-dd HH:mm:ss")

    const addedBooking = {
      id: bookings.length + 1,
      bookingId,
      guest: newBooking.guest,
      email: newBooking.email,
      phone: newBooking.phone,
      roomType: newBooking.roomType,
      roomNumber: "", // This would be assigned based on availability
      checkIn: newBooking.checkIn,
      checkOut: newBooking.checkOut,
      status: "confirmed",
      adults: newBooking.adults,
      children: newBooking.children,
      totalAmount: 299.97, // This would be calculated based on room type and stay duration
      paymentStatus: "pending",
      createdAt,
    }

    // Add to bookings array
    setBookings([...bookings, addedBooking])

    // Reset form and close dialog
    setNewBooking({
      guest: "",
      email: "",
      phone: "",
      roomType: "",
      checkIn: "",
      checkOut: "",
      adults: 1,
      children: 0,
    })
    setIsAddBookingOpen(false)

    toast({
      title: "Booking Created",
      description: `Booking ${bookingId} has been created successfully`,
    })
  }

  // Handle cancelling a booking
  const handleCancelBooking = () => {
    if (!selectedBooking) return

    // Update booking status
    const updatedBookings = bookings.map((booking) => {
      if (booking.id === selectedBooking.id) {
        return { ...booking, status: "cancelled" }
      }
      return booking
    })

    setBookings(updatedBookings)
    setIsCancelBookingOpen(false)

    toast({
      title: "Booking Cancelled",
      description: `Booking ${selectedBooking.bookingId} has been cancelled`,
    })
  }

  // Status badge color mapping
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "confirmed":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Confirmed
          </Badge>
        )
      case "pending":
        return (
          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
            Pending
          </Badge>
        )
      case "cancelled":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            Cancelled
          </Badge>
        )
      case "checked-in":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Checked In
          </Badge>
        )
      case "checked-out":
        return (
          <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
            Checked Out
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  // Payment status badge color mapping
  const getPaymentBadge = (status: string) => {
    switch (status) {
      case "paid":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Paid
          </Badge>
        )
      case "pending":
        return (
          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
            Pending
          </Badge>
        )
      case "refunded":
        return (
          <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
            Refunded
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search bookings..."
            className="w-full pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-[150px]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="confirmed">Confirmed</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="cancelled">Cancelled</SelectItem>
              <SelectItem value="checked-in">Checked In</SelectItem>
              <SelectItem value="checked-out">Checked Out</SelectItem>
            </SelectContent>
          </Select>

          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="w-full sm:w-[180px] justify-start text-left font-normal">
                <CalendarIcon className="mr-2 h-4 w-4" />
                {dateFilter ? format(dateFilter, "PPP") : "Filter by date"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar mode="single" selected={dateFilter} onSelect={setDateFilter} initialFocus />
              {dateFilter && (
                <div className="p-3 border-t border-border">
                  <Button variant="ghost" size="sm" onClick={() => setDateFilter(undefined)}>
                    Clear Date Filter
                  </Button>
                </div>
              )}
            </PopoverContent>
          </Popover>

          <Dialog open={isAddBookingOpen} onOpenChange={setIsAddBookingOpen}>
            <DialogTrigger asChild>
              <Button className="w-full sm:w-auto">
                <Plus className="mr-2 h-4 w-4" /> Add Booking
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Add New Booking</DialogTitle>
                <DialogDescription>Create a new booking in the system. Fill in all required fields.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="guest-name">Guest Name</Label>
                    <Input
                      id="guest-name"
                      placeholder="Full name"
                      value={newBooking.guest}
                      onChange={(e) => setNewBooking({ ...newBooking, guest: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="guest-email">Email</Label>
                    <Input
                      id="guest-email"
                      type="email"
                      placeholder="Email address"
                      value={newBooking.email}
                      onChange={(e) => setNewBooking({ ...newBooking, email: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="guest-phone">Phone</Label>
                  <Input
                    id="guest-phone"
                    placeholder="Phone number"
                    value={newBooking.phone}
                    onChange={(e) => setNewBooking({ ...newBooking, phone: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="room-type">Room Type</Label>
                  <Select
                    value={newBooking.roomType}
                    onValueChange={(value) => setNewBooking({ ...newBooking, roomType: value })}
                  >
                    <SelectTrigger id="room-type">
                      <SelectValue placeholder="Select room type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Standard">Standard</SelectItem>
                      <SelectItem value="Deluxe">Deluxe</SelectItem>
                      <SelectItem value="Suite">Suite</SelectItem>
                      <SelectItem value="Executive">Executive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="check-in-date">Check-in Date</Label>
                    <Input
                      id="check-in-date"
                      type="date"
                      value={newBooking.checkIn}
                      onChange={(e) => setNewBooking({ ...newBooking, checkIn: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="check-out-date">Check-out Date</Label>
                    <Input
                      id="check-out-date"
                      type="date"
                      value={newBooking.checkOut}
                      onChange={(e) => setNewBooking({ ...newBooking, checkOut: e.target.value })}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="adults">Adults</Label>
                    <Input
                      id="adults"
                      type="number"
                      min="1"
                      value={newBooking.adults}
                      onChange={(e) => setNewBooking({ ...newBooking, adults: Number.parseInt(e.target.value) })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="children">Children</Label>
                    <Input
                      id="children"
                      type="number"
                      min="0"
                      value={newBooking.children}
                      onChange={(e) => setNewBooking({ ...newBooking, children: Number.parseInt(e.target.value) })}
                    />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddBookingOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" onClick={handleAddBooking}>
                  Create Booking
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="mb-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle>Booking Statistics</CardTitle>
            <CardDescription>Overview of booking status and trends</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">{bookings.length}</div>
                <div className="text-sm text-blue-700 dark:text-blue-500">Total Bookings</div>
              </div>
              <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border border-green-200 dark:border-green-800">
                <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                  {bookings.filter((booking) => booking.status === "confirmed").length}
                </div>
                <div className="text-sm text-green-700 dark:text-green-500">Confirmed</div>
              </div>
              <div className="bg-amber-50 dark:bg-amber-900/20 p-4 rounded-lg border border-amber-200 dark:border-amber-800">
                <div className="text-2xl font-bold text-amber-600 dark:text-amber-400">
                  {bookings.filter((booking) => booking.status === "pending").length}
                </div>
                <div className="text-sm text-amber-700 dark:text-amber-500">Pending</div>
              </div>
              <div className="bg-red-50 dark:bg-red-900/20 p-4 rounded-lg border border-red-200 dark:border-red-800">
                <div className="text-2xl font-bold text-red-600 dark:text-red-400">
                  {bookings.filter((booking) => booking.status === "cancelled").length}
                </div>
                <div className="text-sm text-red-700 dark:text-red-500">Cancelled</div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="text-sm font-medium">Upcoming Check-ins (Next 7 Days)</div>
              <div className="h-[200px] flex items-center justify-center bg-muted/20 rounded-md">
                <p className="text-muted-foreground">Booking chart visualization would go here</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all">All Bookings</TabsTrigger>
          <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
          <TabsTrigger value="past">Past</TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          <Card>
            <CardHeader>
              <CardTitle>Booking Management</CardTitle>
              <CardDescription>View and manage all bookings in the system.</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Booking ID</TableHead>
                    <TableHead>Guest</TableHead>
                    <TableHead>Room</TableHead>
                    <TableHead>Check-in</TableHead>
                    <TableHead>Check-out</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Payment</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredBookings.length > 0 ? (
                    filteredBookings.map((booking) => (
                      <TableRow key={booking.id}>
                        <TableCell className="font-medium">{booking.bookingId}</TableCell>
                        <TableCell>
                          <div>{booking.guest}</div>
                          <div className="text-xs text-muted-foreground">{booking.email}</div>
                        </TableCell>
                        <TableCell>
                          {booking.roomNumber ? (
                            <>
                              <div>{booking.roomNumber}</div>
                              <div className="text-xs text-muted-foreground">{booking.roomType}</div>
                            </>
                          ) : (
                            <div>{booking.roomType}</div>
                          )}
                        </TableCell>
                        <TableCell>{booking.checkIn}</TableCell>
                        <TableCell>{booking.checkOut}</TableCell>
                        <TableCell>{getStatusBadge(booking.status)}</TableCell>
                        <TableCell>{getPaymentBadge(booking.paymentStatus)}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Open menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem
                                onClick={() => {
                                  setSelectedBooking(booking)
                                  setIsViewBookingOpen(true)
                                }}
                              >
                                <Eye className="mr-2 h-4 w-4" />
                                <span>View Details</span>
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => {
                                  setSelectedBooking(booking)
                                  setIsEditBookingOpen(true)
                                }}
                              >
                                <Edit className="mr-2 h-4 w-4" />
                                <span>Edit Booking</span>
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              {booking.status !== "cancelled" && (
                                <DropdownMenuItem
                                  onClick={() => {
                                    setSelectedBooking(booking)
                                    setIsCancelBookingOpen(true)
                                  }}
                                  className="text-red-600"
                                >
                                  <X className="mr-2 h-4 w-4" />
                                  <span>Cancel Booking</span>
                                </DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={8} className="h-24 text-center">
                        No bookings found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
            <CardFooter className="flex justify-between">
              <div className="text-sm text-muted-foreground">
                Showing {filteredBookings.length} of {bookings.length} bookings
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="upcoming">
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Bookings</CardTitle>
              <CardDescription>Bookings with future check-in dates.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground text-center py-4">Upcoming bookings would be displayed here.</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="past">
          <Card>
            <CardHeader>
              <CardTitle>Past Bookings</CardTitle>
              <CardDescription>Bookings with past check-out dates.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground text-center py-4">Past bookings would be displayed here.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* View Booking Dialog */}
      {selectedBooking && (
        <Dialog open={isViewBookingOpen} onOpenChange={setIsViewBookingOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Booking Details</DialogTitle>
              <DialogDescription>Booking ID: {selectedBooking.bookingId}</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium mb-2">Guest Information</h3>
                  <div className="text-sm space-y-1">
                    <p>
                      <span className="font-medium">Name:</span> {selectedBooking.guest}
                    </p>
                    <p>
                      <span className="font-medium">Email:</span> {selectedBooking.email}
                    </p>
                    <p>
                      <span className="font-medium">Phone:</span> {selectedBooking.phone}
                    </p>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium mb-2">Booking Information</h3>
                  <div className="text-sm space-y-1">
                    <p>
                      <span className="font-medium">Created:</span> {selectedBooking.createdAt}
                    </p>
                    <p>
                      <span className="font-medium">Status:</span> {selectedBooking.status}
                    </p>
                    <p>
                      <span className="font-medium">Payment:</span> {selectedBooking.paymentStatus}
                      {selectedBooking.paymentStatus === "paid" && ` ($${selectedBooking.totalAmount.toFixed(2)})`}
                    </p>
                  </div>
                </div>
              </div>
              <div>
                <h3 className="text-sm font-medium mb-2">Stay Details</h3>
                <div className="text-sm space-y-1">
                  <p>
                    <span className="font-medium">Room:</span> {selectedBooking.roomNumber} ({selectedBooking.roomType})
                  </p>
                  <p>
                    <span className="font-medium">Check-in:</span> {selectedBooking.checkIn}
                  </p>
                  <p>
                    <span className="font-medium">Check-out:</span> {selectedBooking.checkOut}
                  </p>
                  <p>
                    <span className="font-medium">Guests:</span> {selectedBooking.adults} Adults
                    {selectedBooking.children > 0 && `, ${selectedBooking.children} Children`}
                  </p>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button onClick={() => setIsViewBookingOpen(false)}>Close</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Cancel Booking Dialog */}
      {selectedBooking && (
        <Dialog open={isCancelBookingOpen} onOpenChange={setIsCancelBookingOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Cancel Booking</DialogTitle>
              <DialogDescription>
                Are you sure you want to cancel this booking? This action cannot be undone.
              </DialogDescription>
            </DialogHeader>
            <div className="py-4">
              <div className="text-sm space-y-2">
                <p>
                  <span className="font-medium">Booking ID:</span> {selectedBooking.bookingId}
                </p>
                <p>
                  <span className="font-medium">Guest:</span> {selectedBooking.guest}
                </p>
                <p>
                  <span className="font-medium">Stay:</span> {selectedBooking.checkIn} to {selectedBooking.checkOut}
                </p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCancelBookingOpen(false)}>
                No, Keep Booking
              </Button>
              <Button variant="destructive" onClick={handleCancelBooking}>
                Yes, Cancel Booking
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}

