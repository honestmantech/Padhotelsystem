"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Ban,
  Calendar,
  Check,
  ClipboardList,
  Edit,
  Eye,
  FileText,
  Key,
  MoreHorizontal,
  Plus,
  Search,
  Star,
  Trash,
  Unlock,
  Upload,
  UserPlus,
  Users,
} from "lucide-react"
import { Separator } from "@/components/ui/separator"
import { Checkbox } from "@/components/ui/checkbox"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts"

// Sample staff data
const staffData = [
  {
    id: 1,
    name: "James Wilson",
    email: "james.wilson@paddysview.com",
    phone: "+233 20 123 4567",
    role: "Manager",
    department: "Administration",
    status: "active",
    joinDate: "2020-05-15",
    lastActive: "2023-03-22 09:15:30",
    avatar: "/placeholder.svg?height=40&width=40",
    address: "123 Main Street, Accra",
    emergencyContact: "+233 24 987 6543",
    salary: 3500,
    performance: 95,
    shifts: ["Morning", "Evening"],
    skills: ["Customer Service", "Leadership", "Conflict Resolution"],
    documents: [
      { name: "Employment Contract", status: "verified", expiryDate: null },
      { name: "ID Card", status: "verified", expiryDate: "2025-05-15" },
    ],
    trainings: [
      { name: "Hotel Management", completionDate: "2021-03-10", score: 92 },
      { name: "Customer Service Excellence", completionDate: "2022-01-15", score: 95 },
    ],
  },
  {
    id: 2,
    name: "Sarah Johnson",
    email: "sarah.johnson@paddysview.com",
    phone: "+233 24 987 6543",
    role: "Receptionist",
    department: "Front Desk",
    status: "active",
    joinDate: "2021-02-10",
    lastActive: "2023-03-22 08:30:45",
    avatar: "/placeholder.svg?height=40&width=40",
    address: "456 Park Avenue, Accra",
    emergencyContact: "+233 20 123 4567",
    salary: 1800,
    performance: 88,
    shifts: ["Morning", "Afternoon"],
    skills: ["Customer Service", "Computer Skills", "Communication"],
    documents: [
      { name: "Employment Contract", status: "verified", expiryDate: null },
      { name: "ID Card", status: "verified", expiryDate: "2024-02-10" },
    ],
    trainings: [
      { name: "Front Desk Operations", completionDate: "2021-03-15", score: 90 },
      { name: "Conflict Resolution", completionDate: "2022-02-20", score: 85 },
    ],
  },
  {
    id: 3,
    name: "Michael Brown",
    email: "michael.brown@paddysview.com",
    phone: "+233 27 456 7890",
    role: "Housekeeper",
    department: "Housekeeping",
    status: "active",
    joinDate: "2022-01-05",
    lastActive: "2023-03-21 17:45:10",
    avatar: "/placeholder.svg?height=40&width=40",
    address: "789 Beach Road, Accra",
    emergencyContact: "+233 23 345 6789",
    salary: 1200,
    performance: 92,
    shifts: ["Morning"],
    skills: ["Cleaning", "Organization", "Attention to Detail"],
    documents: [
      { name: "Employment Contract", status: "verified", expiryDate: null },
      { name: "Health Certificate", status: "verified", expiryDate: "2023-07-15" },
    ],
    trainings: [{ name: "Housekeeping Standards", completionDate: "2022-02-10", score: 95 }],
  },
  {
    id: 4,
    name: "Emily Davis",
    email: "emily.davis@paddysview.com",
    phone: "+233 23 345 6789",
    role: "Chef",
    department: "Food & Beverage",
    status: "active",
    joinDate: "2021-06-15",
    lastActive: "2023-03-22 10:20:15",
    avatar: "/placeholder.svg?height=40&width=40",
    address: "321 River Street, Accra",
    emergencyContact: "+233 27 456 7890",
    salary: 2500,
    performance: 90,
    shifts: ["Afternoon", "Evening"],
    skills: ["Cooking", "Menu Planning", "Food Safety"],
    documents: [
      { name: "Employment Contract", status: "verified", expiryDate: null },
      { name: "Food Handler's Certificate", status: "verified", expiryDate: "2023-06-15" },
      { name: "Culinary Degree", status: "verified", expiryDate: null },
    ],
    trainings: [
      { name: "Advanced Culinary Techniques", completionDate: "2021-08-20", score: 94 },
      { name: "Food Safety & Hygiene", completionDate: "2022-01-10", score: 98 },
    ],
  },
  {
    id: 5,
    name: "Robert Wilson",
    email: "robert.wilson@paddysview.com",
    phone: "+233 26 789 0123",
    role: "Security Officer",
    department: "Security",
    status: "inactive",
    joinDate: "2020-11-10",
    lastActive: "2023-02-28 22:30:45",
    avatar: "/placeholder.svg?height=40&width=40",
    address: "567 Hill Avenue, Accra",
    emergencyContact: "+233 20 234 5678",
    salary: 1500,
    performance: 75,
    shifts: ["Night"],
    skills: ["Security Protocols", "Surveillance", "Emergency Response"],
    documents: [
      { name: "Employment Contract", status: "verified", expiryDate: null },
      { name: "Security License", status: "expired", expiryDate: "2023-01-15" },
    ],
    trainings: [
      { name: "Hotel Security Procedures", completionDate: "2021-01-15", score: 88 },
      { name: "First Aid & CPR", completionDate: "2021-03-20", score: 90 },
    ],
  },
  {
    id: 6,
    name: "Jennifer Lee",
    email: "jennifer.lee@paddysview.com",
    phone: "+233 20 234 5678",
    role: "Accountant",
    department: "Finance",
    status: "active",
    joinDate: "2021-04-01",
    lastActive: "2023-03-22 11:15:30",
    avatar: "/placeholder.svg?height=40&width=40",
    address: "890 Lake Drive, Accra",
    emergencyContact: "+233 26 789 0123",
    salary: 2800,
    performance: 94,
    shifts: ["Morning"],
    skills: ["Financial Analysis", "Bookkeeping", "Budgeting"],
    documents: [
      { name: "Employment Contract", status: "verified", expiryDate: null },
      { name: "Accounting Certification", status: "verified", expiryDate: null },
    ],
    trainings: [
      { name: "Hotel Financial Management", completionDate: "2021-06-10", score: 96 },
      { name: "Tax Compliance", completionDate: "2022-02-15", score: 92 },
    ],
  },
  {
    id: 7,
    name: "David Miller",
    email: "david.miller@paddysview.com",
    phone: "+233 24 567 8901",
    role: "Maintenance Technician",
    department: "Maintenance",
    status: "active",
    joinDate: "2022-02-15",
    lastActive: "2023-03-21 16:45:20",
    avatar: "/placeholder.svg?height=40&width=40",
    address: "432 Forest Lane, Accra",
    emergencyContact: "+233 23 456 7890",
    salary: 1600,
    performance: 85,
    shifts: ["Morning", "Afternoon"],
    skills: ["Electrical Repairs", "Plumbing", "HVAC Maintenance"],
    documents: [
      { name: "Employment Contract", status: "verified", expiryDate: null },
      { name: "Technical Certification", status: "verified", expiryDate: "2024-02-15" },
    ],
    trainings: [{ name: "Building Maintenance", completionDate: "2022-03-10", score: 88 }],
  },
  {
    id: 8,
    name: "Lisa Chen",
    email: "lisa.chen@paddysview.com",
    phone: "+233 27 890 1234",
    role: "HR Specialist",
    department: "Human Resources",
    status: "active",
    joinDate: "2021-09-01",
    lastActive: "2023-03-22 09:30:15",
    avatar: "/placeholder.svg?height=40&width=40",
    address: "765 Mountain View, Accra",
    emergencyContact: "+233 24 567 8901",
    salary: 2200,
    performance: 91,
    shifts: ["Morning"],
    skills: ["Recruitment", "Employee Relations", "Training & Development"],
    documents: [
      { name: "Employment Contract", status: "verified", expiryDate: null },
      { name: "HR Certification", status: "verified", expiryDate: null },
    ],
    trainings: [
      { name: "HR Management", completionDate: "2021-10-15", score: 93 },
      { name: "Employment Law", completionDate: "2022-01-20", score: 90 },
    ],
  },
]

// Sample departments data
const departmentsData = [
  { id: 1, name: "Administration", staffCount: 2, manager: "James Wilson", budget: 85000 },
  { id: 2, name: "Front Desk", staffCount: 4, manager: "Sarah Johnson", budget: 65000 },
  { id: 3, name: "Housekeeping", staffCount: 8, manager: "Michael Brown", budget: 45000 },
  { id: 4, name: "Food & Beverage", staffCount: 6, manager: "Emily Davis", budget: 75000 },
  { id: 5, name: "Security", staffCount: 3, manager: "Robert Wilson", budget: 35000 },
  { id: 6, name: "Finance", staffCount: 2, manager: "Jennifer Lee", budget: 55000 },
  { id: 7, name: "Maintenance", staffCount: 3, manager: "David Miller", budget: 40000 },
  { id: 8, name: "Human Resources", staffCount: 2, manager: "Lisa Chen", budget: 50000 },
]

// Sample shifts data
const shiftsData = [
  { id: 1, name: "Morning", startTime: "06:00", endTime: "14:00", staffCount: 15 },
  { id: 2, name: "Afternoon", startTime: "14:00", endTime: "22:00", staffCount: 12 },
  { id: 3, name: "Evening", startTime: "18:00", endTime: "02:00", staffCount: 8 },
  { id: 4, name: "Night", startTime: "22:00", endTime: "06:00", staffCount: 5 },
]

// Sample performance data for charts
const performanceData = [
  { month: "Jan", average: 85 },
  { month: "Feb", average: 87 },
  { month: "Mar", average: 89 },
  { month: "Apr", average: 86 },
  { month: "May", average: 88 },
  { month: "Jun", average: 90 },
  { month: "Jul", average: 92 },
  { month: "Aug", average: 91 },
  { month: "Sep", average: 89 },
  { month: "Oct", average: 90 },
  { month: "Nov", average: 92 },
  { month: "Dec", average: 93 },
]

// Sample department performance data
const departmentPerformanceData = [
  { name: "Administration", performance: 92 },
  { name: "Front Desk", performance: 88 },
  { name: "Housekeeping", performance: 90 },
  { name: "Food & Beverage", performance: 85 },
  { name: "Security", performance: 82 },
  { name: "Finance", performance: 94 },
  { name: "Maintenance", performance: 86 },
  { name: "Human Resources", performance: 91 },
]

export default function StaffPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [departmentFilter, setDepartmentFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [isAddStaffOpen, setIsAddStaffOpen] = useState(false)
  const [isViewStaffOpen, setIsViewStaffOpen] = useState(false)
  const [isAddDepartmentOpen, setIsAddDepartmentOpen] = useState(false)
  const [isAddShiftOpen, setIsAddShiftOpen] = useState(false)
  const [selectedStaff, setSelectedStaff] = useState<any>(null)

  // Filter staff based on search term and filters
  const filteredStaff = staffData.filter((staff) => {
    const matchesSearch =
      staff.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      staff.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      staff.role.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesDepartment = departmentFilter === "all" || staff.department === departmentFilter
    const matchesStatus = statusFilter === "all" || staff.status === statusFilter

    return matchesSearch && matchesDepartment && matchesStatus
  })

  // Status badge color mapping
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Active
          </Badge>
        )
      case "inactive":
        return (
          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
            Inactive
          </Badge>
        )
      case "suspended":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            Suspended
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  // Document status badge color mapping
  const getDocumentStatusBadge = (status: string) => {
    switch (status) {
      case "verified":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Verified
          </Badge>
        )
      case "pending":
        return (
          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
            Pending
          </Badge>
        )
      case "expired":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            Expired
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  // Get user initials for avatar
  const getUserInitials = (name: string) => {
    return name
      .split(" ")
      .map((part) => part.charAt(0))
      .join("")
      .toUpperCase()
  }

  // View staff details
  const handleViewStaff = (staff: any) => {
    setSelectedStaff(staff)
    setIsViewStaffOpen(true)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search staff..."
            className="w-full pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
            <SelectTrigger className="w-full sm:w-[180px]">
              <SelectValue placeholder="Filter by department" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Departments</SelectItem>
              {departmentsData.map((dept) => (
                <SelectItem key={dept.id} value={dept.name}>
                  {dept.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-[150px]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="inactive">Inactive</SelectItem>
              <SelectItem value="suspended">Suspended</SelectItem>
            </SelectContent>
          </Select>

          <Dialog open={isAddStaffOpen} onOpenChange={setIsAddStaffOpen}>
            <DialogTrigger asChild>
              <Button className="w-full sm:w-auto">
                <UserPlus className="mr-2 h-4 w-4" /> Add Staff
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Add New Staff Member</DialogTitle>
                <DialogDescription>
                  Create a new staff member account. Fill in all required information.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="staff-name">Full Name</Label>
                    <Input id="staff-name" placeholder="Full name" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="staff-email">Email</Label>
                    <Input id="staff-email" type="email" placeholder="work email" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="staff-phone">Phone</Label>
                    <Input id="staff-phone" placeholder="Phone number" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="staff-role">Role</Label>
                    <Input id="staff-role" placeholder="Job title" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="staff-department">Department</Label>
                    <Select>
                      <SelectTrigger id="staff-department">
                        <SelectValue placeholder="Select department" />
                      </SelectTrigger>
                      <SelectContent>
                        {departmentsData.map((dept) => (
                          <SelectItem key={dept.id} value={dept.name}>
                            {dept.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="join-date">Join Date</Label>
                    <Input id="join-date" type="date" />
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label htmlFor="staff-address">Address</Label>
                  <Input id="staff-address" placeholder="Residential address" />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="emergency-contact">Emergency Contact</Label>
                    <Input id="emergency-contact" placeholder="Emergency contact number" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="staff-salary">Salary</Label>
                    <Input id="staff-salary" type="number" placeholder="Monthly salary" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Assigned Shifts</Label>
                  <div className="flex flex-wrap gap-2">
                    {shiftsData.map((shift) => (
                      <div key={shift.id} className="flex items-center space-x-2">
                        <Checkbox id={`shift-${shift.id}`} />
                        <Label htmlFor={`shift-${shift.id}`}>{shift.name}</Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Required Documents</Label>
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="doc-contract" checked />
                      <Label htmlFor="doc-contract">Employment Contract</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="doc-id" checked />
                      <Label htmlFor="doc-id">ID Card</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="doc-certificate" />
                      <Label htmlFor="doc-certificate">Professional Certificates</Label>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Upload Documents</Label>
                  <div className="border-2 border-dashed rounded-md p-6 text-center">
                    <Upload className="h-8 w-8 mx-auto text-muted-foreground" />
                    <p className="mt-2 text-sm text-muted-foreground">Drag and drop files here, or click to browse</p>
                    <Button variant="outline" size="sm" className="mt-2">
                      Browse Files
                    </Button>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddStaffOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" onClick={() => setIsAddStaffOpen(false)}>
                  Add Staff Member
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      // Enhance the staff page with attendance tracking and shift management // Add this after the search and filter
      controls but before the Tabs component
      <div className="mb-6">
        <Card>
          <CardHeader className="pb-3">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <div>
                <CardTitle>Today's Staff Overview</CardTitle>
                <CardDescription>Staff attendance and shift information</CardDescription>
              </div>
              <Button variant="outline" size="sm">
                <Calendar className="mr-2 h-4 w-4" /> View Schedule
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border border-green-200 dark:border-green-800">
                <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                  {staffData.filter((staff) => staff.status === "active").length}
                </div>
                <div className="text-sm text-green-700 dark:text-green-500">Active Staff</div>
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">15</div>
                <div className="text-sm text-blue-700 dark:text-blue-500">On Duty Today</div>
              </div>
              <div className="bg-amber-50 dark:bg-amber-900/20 p-4 rounded-lg border border-amber-200 dark:border-amber-800">
                <div className="text-2xl font-bold text-amber-600 dark:text-amber-400">3</div>
                <div className="text-sm text-amber-700 dark:text-amber-500">On Leave</div>
              </div>
              <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-lg border border-purple-200 dark:border-purple-800">
                <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">2</div>
                <div className="text-sm text-purple-700 dark:text-purple-500">New Hires</div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="text-sm font-medium">Current Shift</div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {shiftsData.slice(0, 3).map((shift) => (
                  <div key={shift.id} className="border rounded-md p-4">
                    <div className="flex justify-between items-center mb-2">
                      <div className="font-medium">{shift.name} Shift</div>
                      <Badge variant={shift.name === "Morning" ? "default" : "outline"}>
                        {shift.name === "Morning" ? "Current" : "Upcoming"}
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground mb-2">
                      {shift.startTime} - {shift.endTime}
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">{shift.staffCount} staff members</span>
                    </div>
                    <div className="mt-3">
                      <Button variant="outline" size="sm" className="w-full">
                        View Staff
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      <Tabs defaultValue="staff" className="space-y-4">
        <TabsList>
          <TabsTrigger value="staff">Staff</TabsTrigger>
          <TabsTrigger value="departments">Departments</TabsTrigger>
          <TabsTrigger value="shifts">Shifts</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>

        <TabsContent value="staff">
          <Card>
            <CardHeader>
              <CardTitle>Staff Management</CardTitle>
              <CardDescription>Manage all staff members. View, edit, or change staff status.</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Staff</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Join Date</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredStaff.length > 0 ? (
                    filteredStaff.map((staff) => (
                      <TableRow key={staff.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <Avatar>
                              <AvatarImage src={staff.avatar} alt={staff.name} />
                              <AvatarFallback>{getUserInitials(staff.name)}</AvatarFallback>
                            </Avatar>
                            <div className="font-medium">{staff.name}</div>
                          </div>
                        </TableCell>
                        <TableCell>{staff.role}</TableCell>
                        <TableCell>{staff.department}</TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="text-sm">{staff.email}</span>
                            <span className="text-xs text-muted-foreground">{staff.phone}</span>
                          </div>
                        </TableCell>
                        <TableCell>{getStatusBadge(staff.status)}</TableCell>
                        <TableCell>{staff.joinDate}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Open menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem onClick={() => handleViewStaff(staff)}>
                                <Eye className="mr-2 h-4 w-4" />
                                <span>View Profile</span>
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Edit className="mr-2 h-4 w-4" />
                                <span>Edit Staff</span>
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Calendar className="mr-2 h-4 w-4" />
                                <span>View Schedule</span>
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <FileText className="mr-2 h-4 w-4" />
                                <span>Documents</span>
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              {staff.status === "active" ? (
                                <DropdownMenuItem>
                                  <Ban className="mr-2 h-4 w-4 text-amber-600" />
                                  <span>Deactivate</span>
                                </DropdownMenuItem>
                              ) : staff.status === "inactive" ? (
                                <DropdownMenuItem>
                                  <Check className="mr-2 h-4 w-4 text-green-600" />
                                  <span>Activate</span>
                                </DropdownMenuItem>
                              ) : (
                                <DropdownMenuItem>
                                  <Unlock className="mr-2 h-4 w-4 text-green-600" />
                                  <span>Unsuspend</span>
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuItem>
                                <Key className="mr-2 h-4 w-4 text-blue-600" />
                                <span>Reset Password</span>
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="text-red-600">
                                <Trash className="mr-2 h-4 w-4" />
                                <span>Delete Staff</span>
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={7} className="h-24 text-center">
                        No staff members found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
            <CardFooter className="flex justify-between">
              <div className="text-sm text-muted-foreground">
                Showing {filteredStaff.length} of {staffData.length} staff members
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="departments">
          <div className="flex justify-end mb-4">
            <Dialog open={isAddDepartmentOpen} onOpenChange={setIsAddDepartmentOpen}>
              <DialogTrigger asChild>
                <Button size="sm">
                  <Plus className="mr-2 h-4 w-4" /> Add Department
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>Add New Department</DialogTitle>
                  <DialogDescription>Create a new department in the system.</DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="dept-name" className="text-right">
                      Department Name
                    </Label>
                    <Input id="dept-name" placeholder="e.g. Marketing" className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="dept-manager" className="text-right">
                      Manager
                    </Label>
                    <Select>
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select manager" />
                      </SelectTrigger>
                      <SelectContent>
                        {staffData.map((staff) => (
                          <SelectItem key={staff.id} value={staff.name}>
                            {staff.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="dept-budget" className="text-right">
                      Budget
                    </Label>
                    <Input id="dept-budget" type="number" placeholder="Annual budget" className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="dept-description" className="text-right">
                      Description
                    </Label>
                    <Input id="dept-description" placeholder="Department description" className="col-span-3" />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsAddDepartmentOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" onClick={() => setIsAddDepartmentOpen(false)}>
                    Save Department
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {departmentsData.map((dept) => (
              <Card key={dept.id}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <CardTitle>{dept.name}</CardTitle>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>
                          <Eye className="mr-2 h-4 w-4" />
                          <span>View Details</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Edit className="mr-2 h-4 w-4" />
                          <span>Edit Department</span>
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-red-600">
                          <Trash className="mr-2 h-4 w-4" />
                          <span>Delete Department</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                  <CardDescription>Manager: {dept.manager}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between py-2">
                    <div>
                      <p className="text-sm text-muted-foreground">Staff Count</p>
                      <p className="text-2xl font-bold">{dept.staffCount}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Annual Budget</p>
                      <p className="text-2xl font-bold">${dept.budget.toLocaleString()}</p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full">
                    <Eye className="mr-2 h-4 w-4" /> View Staff
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="shifts">
          <div className="flex justify-end mb-4">
            <Dialog open={isAddShiftOpen} onOpenChange={setIsAddShiftOpen}>
              <DialogTrigger asChild>
                <Button size="sm">
                  <Plus className="mr-2 h-4 w-4" /> Add Shift
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>Add New Shift</DialogTitle>
                  <DialogDescription>Create a new shift schedule in the system.</DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="shift-name" className="text-right">
                      Shift Name
                    </Label>
                    <Input id="shift-name" placeholder="e.g. Afternoon" className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="start-time" className="text-right">
                      Start Time
                    </Label>
                    <Input id="start-time" type="time" className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="end-time" className="text-right">
                      End Time
                    </Label>
                    <Input id="end-time" type="time" className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="shift-description" className="text-right">
                      Description
                    </Label>
                    <Input id="shift-description" placeholder="Shift description" className="col-span-3" />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsAddShiftOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" onClick={() => setIsAddShiftOpen(false)}>
                    Save Shift
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Shift Management</CardTitle>
              <CardDescription>Manage all shifts and staff scheduling.</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Shift Name</TableHead>
                    <TableHead>Start Time</TableHead>
                    <TableHead>End Time</TableHead>
                    <TableHead>Staff Count</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {shiftsData.map((shift) => (
                    <TableRow key={shift.id}>
                      <TableCell className="font-medium">{shift.name}</TableCell>
                      <TableCell>{shift.startTime}</TableCell>
                      <TableCell>{shift.endTime}</TableCell>
                      <TableCell>{shift.staffCount}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Eye className="mr-2 h-4 w-4" />
                              <span>View Staff</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <ClipboardList className="mr-2 h-4 w-4" />
                              <span>Schedule Staff</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" />
                              <span>Edit Shift</span>
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-red-600">
                              <Trash className="mr-2 h-4 w-4" />
                              <span>Delete Shift</span>
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <div className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Weekly Schedule</CardTitle>
                <CardDescription>Staff schedule for the current week.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-10">
                  <p className="text-muted-foreground">Weekly schedule calendar will be displayed here</p>
                  <Button variant="outline" className="mt-4">
                    <Calendar className="mr-2 h-4 w-4" /> View Full Schedule
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="performance">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Staff Performance Trend</CardTitle>
                <CardDescription>Average staff performance over the past year</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={performanceData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis domain={[70, 100]} />
                    <Tooltip formatter={(value) => `${value}%`} />
                    <Line type="monotone" dataKey="average" name="Performance" stroke="#8884d8" activeDot={{ r: 8 }} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Department Performance</CardTitle>
                <CardDescription>Performance by department</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={departmentPerformanceData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis domain={[70, 100]} />
                    <Tooltip formatter={(value) => `${value}%`} />
                    <Bar dataKey="performance" name="Performance" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Top Performers</CardTitle>
              <CardDescription>Staff with the highest performance ratings</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Staff</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Performance</TableHead>
                    <TableHead>Rating</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {staffData
                    .sort((a, b) => b.performance - a.performance)
                    .slice(0, 5)
                    .map((staff) => (
                      <TableRow key={staff.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <Avatar>
                              <AvatarImage src={staff.avatar} alt={staff.name} />
                              <AvatarFallback>{getUserInitials(staff.name)}</AvatarFallback>
                            </Avatar>
                            <div className="font-medium">{staff.name}</div>
                          </div>
                        </TableCell>
                        <TableCell>{staff.department}</TableCell>
                        <TableCell>{staff.role}</TableCell>
                        <TableCell>{staff.performance}%</TableCell>
                        <TableCell>
                          <div className="flex">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`h-4 w-4 ${i < Math.round(staff.performance / 20) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                              />
                            ))}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      {/* View Staff Dialog */}
      {selectedStaff && (
        <Dialog open={isViewStaffOpen} onOpenChange={setIsViewStaffOpen}>
          <DialogContent className="sm:max-w-[700px]">
            <DialogHeader>
              <DialogTitle>Staff Profile</DialogTitle>
              <DialogDescription>Detailed information for {selectedStaff.name}.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-6">
              <div className="flex flex-col sm:flex-row gap-6">
                <div className="flex flex-col items-center gap-2">
                  <Avatar className="h-24 w-24">
                    <AvatarImage src={selectedStaff.avatar} alt={selectedStaff.name} />
                    <AvatarFallback className="text-2xl">{getUserInitials(selectedStaff.name)}</AvatarFallback>
                  </Avatar>
                  <div className="text-center">
                    <h3 className="font-bold text-lg">{selectedStaff.name}</h3>
                    <p className="text-sm text-muted-foreground">{selectedStaff.role}</p>
                  </div>
                  <Badge
                    variant="outline"
                    className={`mt-1 ${selectedStaff.status === "active" ? "bg-green-50 text-green-700 border-green-200" : "bg-amber-50 text-amber-700 border-amber-200"}`}
                  >
                    {selectedStaff.status.charAt(0).toUpperCase() + selectedStaff.status.slice(1)}
                  </Badge>
                </div>

                <div className="flex-1 space-y-4">
                  <div>
                    <h4 className="text-sm font-medium mb-2">Contact Information</h4>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <p className="text-muted-foreground">Email:</p>
                        <p>{selectedStaff.email}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Phone:</p>
                        <p>{selectedStaff.phone}</p>
                      </div>
                      <div className="col-span-2">
                        <p className="text-muted-foreground">Address:</p>
                        <p>{selectedStaff.address}</p>
                      </div>
                      <div className="col-span-2">
                        <p className="text-muted-foreground">Emergency Contact:</p>
                        <p>{selectedStaff.emergencyContact}</p>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  <div>
                    <h4 className="text-sm font-medium mb-2">Employment Details</h4>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <p className="text-muted-foreground">Department:</p>
                        <p>{selectedStaff.department}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Join Date:</p>
                        <p>{selectedStaff.joinDate}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Salary:</p>
                        <p>${selectedStaff.salary.toLocaleString()}/month</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Performance:</p>
                        <p>{selectedStaff.performance}%</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h4 className="text-sm font-medium mb-2">Shifts & Schedule</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedStaff.shifts.map((shift, index) => (
                    <Badge key={index} variant="secondary">
                      {shift}
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium mb-2">Skills & Expertise</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedStaff.skills.map((skill, index) => (
                    <Badge key={index} variant="outline">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium mb-2">Documents</h4>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Document</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Expiry Date</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedStaff.documents.map((doc, index) => (
                      <TableRow key={index}>
                        <TableCell>{doc.name}</TableCell>
                        <TableCell>{getDocumentStatusBadge(doc.status)}</TableCell>
                        <TableCell>{doc.expiryDate || "N/A"}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                            <span className="sr-only">View Document</span>
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div>
                <h4 className="text-sm font-medium mb-2">Training & Development</h4>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Training</TableHead>
                      <TableHead>Completion Date</TableHead>
                      <TableHead>Score</TableHead>
                      <TableHead className="text-right">Certificate</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedStaff.trainings.map((training, index) => (
                      <TableRow key={index}>
                        <TableCell>{training.name}</TableCell>
                        <TableCell>{training.completionDate}</TableCell>
                        <TableCell>{training.score}%</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">
                            <FileText className="h-4 w-4" />
                            <span className="sr-only">View Certificate</span>
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsViewStaffOpen(false)}>
                Close
              </Button>
              <Button variant="outline">
                <Calendar className="mr-2 h-4 w-4" /> View Schedule
              </Button>
              <Button>
                <Edit className="mr-2 h-4 w-4" /> Edit Profile
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}

