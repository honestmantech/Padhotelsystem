import { Skeleton } from "@/components/ui/skeleton"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"

export default function ReportsLoading() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <Skeleton className="h-10 w-[200px]" />
        <div className="flex flex-col sm:flex-row gap-2">
          <Skeleton className="h-10 w-[200px]" />
          <Skeleton className="h-10 w-[150px]" />
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
            <div className="space-y-2">
              <Skeleton className="h-6 w-[150px]" />
              <Skeleton className="h-4 w-[250px]" />
            </div>
            <div className="flex gap-2">
              <Skeleton className="h-9 w-[120px]" />
              <Skeleton className="h-9 w-[150px]" />
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex gap-2 overflow-x-auto pb-2">
            <Skeleton className="h-10 w-[100px] flex-shrink-0" />
            <Skeleton className="h-10 w-[100px] flex-shrink-0" />
            <Skeleton className="h-10 w-[100px] flex-shrink-0" />
            <Skeleton className="h-10 w-[100px] flex-shrink-0" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <Skeleton className="h-4 w-[100px]" />
              </CardHeader>
              <CardContent className="space-y-2">
                <Skeleton className="h-8 w-[100px]" />
                <Skeleton className="h-3 w-[150px]" />
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <Skeleton className="h-4 w-[100px]" />
              </CardHeader>
              <CardContent className="space-y-2">
                <Skeleton className="h-8 w-[100px]" />
                <Skeleton className="h-3 w-[150px]" />
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <Skeleton className="h-4 w-[100px]" />
              </CardHeader>
              <CardContent className="space-y-2">
                <Skeleton className="h-8 w-[100px]" />
                <Skeleton className="h-3 w-[150px]" />
              </CardContent>
            </Card>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <Skeleton className="h-6 w-[150px]" />
              <div className="flex gap-2">
                <Skeleton className="h-9 w-[120px]" />
                <Skeleton className="h-9 w-[100px]" />
              </div>
            </div>
            <Skeleton className="h-[400px] w-full" />
          </div>

          <div className="space-y-4">
            <Skeleton className="h-6 w-[150px]" />
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Skeleton className="h-4 w-[200px]" />
          <Skeleton className="h-9 w-[120px]" />
        </CardFooter>
      </Card>
    </div>
  )
}

