"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format, subMonths } from "date-fns"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts"
import {
  BarChart2,
  CalendarIcon,
  LineChartIcon,
  Mail,
  PieChartIcon,
  Printer,
  RefreshCw,
  Table2,
  Users,
} from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

// First, import the DocumentExport component
import { DocumentExport } from "@/components/document-export"

// First, import the BulkExport component
import { BulkExport } from "@/components/bulk-export"

// Sample data for charts
const revenueData = [
  { name: "Jan", revenue: 12500, expenses: 8200, profit: 4300 },
  { name: "Feb", revenue: 14200, expenses: 8500, profit: 5700 },
  { name: "Mar", revenue: 15800, expenses: 9100, profit: 6700 },
  { name: "Apr", revenue: 16900, expenses: 9300, profit: 7600 },
  { name: "May", revenue: 18200, expenses: 9800, profit: 8400 },
  { name: "Jun", revenue: 19500, expenses: 10200, profit: 9300 },
  { name: "Jul", revenue: 21000, expenses: 10500, profit: 10500 },
  { name: "Aug", revenue: 22300, expenses: 10800, profit: 11500 },
  { name: "Sep", revenue: 20100, expenses: 10300, profit: 9800 },
  { name: "Oct", revenue: 19200, expenses: 10100, profit: 9100 },
  { name: "Nov", revenue: 18500, expenses: 9900, profit: 8600 },
  { name: "Dec", revenue: 23500, expenses: 11200, profit: 12300 },
]

const occupancyData = [
  { name: "Jan", rate: 65 },
  { name: "Feb", rate: 68 },
  { name: "Mar", rate: 72 },
  { name: "Apr", rate: 75 },
  { name: "May", rate: 78 },
  { name: "Jun", rate: 82 },
  { name: "Jul", rate: 88 },
  { name: "Aug", rate: 92 },
  { name: "Sep", rate: 85 },
  { name: "Oct", rate: 80 },
  { name: "Nov", rate: 76 },
  { name: "Dec", rate: 85 },
]

const revenueSourceData = [
  { name: "Room Bookings", value: 65 },
  { name: "Restaurant", value: 15 },
  { name: "Events", value: 10 },
  { name: "Spa & Wellness", value: 7 },
  { name: "Other", value: 3 },
]

const bookingChannelData = [
  { name: "Direct Website", value: 40 },
  { name: "Booking.com", value: 25 },
  { name: "Expedia", value: 15 },
  { name: "TripAdvisor", value: 10 },
  { name: "Phone/Walk-in", value: 10 },
]

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8"]

export default function ReportsPage() {
  const [dateRange, setDateRange] = useState<{
    from: Date | undefined
    to: Date | undefined
  }>({
    from: subMonths(new Date(), 1),
    to: new Date(),
  })
  const [isDateFilterOpen, setIsDateFilterOpen] = useState(false)
  const [reportType, setReportType] = useState("financial")
  const [reportFormat, setReportFormat] = useState("pdf")
  const [reportPeriod, setReportPeriod] = useState("monthly")

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h2 className="text-3xl font-bold tracking-tight">Reports</h2>
        <div className="flex flex-col sm:flex-row gap-2">
          <Popover open={isDateFilterOpen} onOpenChange={setIsDateFilterOpen}>
            <PopoverTrigger asChild>
              <Button variant="outline" className="w-full sm:w-auto justify-start">
                <CalendarIcon className="mr-2 h-4 w-4" />
                {dateRange.from ? (
                  dateRange.to ? (
                    <>
                      {format(dateRange.from, "LLL dd, y")} - {format(dateRange.to, "LLL dd, y")}
                    </>
                  ) : (
                    format(dateRange.from, "LLL dd, y")
                  )
                ) : (
                  "Select date range"
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="end">
              <Calendar
                initialFocus
                mode="range"
                defaultMonth={dateRange.from}
                selected={dateRange}
                onSelect={(range) => {
                  setDateRange(range as { from: Date | undefined; to: Date | undefined })
                  if (range?.to) {
                    setIsDateFilterOpen(false)
                  }
                }}
                numberOfMonths={2}
              />
            </PopoverContent>
          </Popover>

          <DocumentExport
            title="Export Report"
            description="Generate and download reports in various formats"
            documentType="report"
            allowedFormats={["pdf", "excel", "csv"]}
            onExport={(format, options) => {
              console.log("Exporting report:", { format, options, dateRange, reportType })
              // Here you would implement the actual export functionality
            }}
          />
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
            <div>
              <CardTitle>Report Dashboard</CardTitle>
              <CardDescription>Comprehensive analytics and reporting for hotel performance</CardDescription>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <RefreshCw className="mr-2 h-4 w-4" /> Refresh Data
              </Button>
              <Button variant="outline" size="sm">
                <Mail className="mr-2 h-4 w-4" /> Schedule Reports
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="financial" className="space-y-4">
            <TabsList className="grid grid-cols-2 md:grid-cols-4 gap-2">
              <TabsTrigger value="financial">
                <BarChart2 className="mr-2 h-4 w-4" /> Financial
              </TabsTrigger>
              <TabsTrigger value="occupancy">
                <Users className="mr-2 h-4 w-4" /> Occupancy
              </TabsTrigger>
              <TabsTrigger value="revenue">
                <PieChartIcon className="mr-2 h-4 w-4" /> Revenue Sources
              </TabsTrigger>
              <TabsTrigger value="booking">
                <LineChartIcon className="mr-2 h-4 w-4" /> Booking Channels
              </TabsTrigger>
            </TabsList>

            {/* Financial Reports Tab */}
            <TabsContent value="financial">
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">$209,200</div>
                      <p className="text-xs text-muted-foreground">
                        <span className="text-green-500 inline-flex items-center">+12.5%</span> vs previous period
                      </p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">$107,600</div>
                      <p className="text-xs text-muted-foreground">
                        <span className="text-red-500 inline-flex items-center">+5.2%</span> vs previous period
                      </p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Net Profit</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">$101,600</div>
                      <p className="text-xs text-muted-foreground">
                        <span className="text-green-500 inline-flex items-center">+18.2%</span> vs previous period
                      </p>
                    </CardContent>
                  </Card>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-medium">Revenue vs Expenses</h3>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Table2 className="mr-2 h-4 w-4" /> View Data Table
                      </Button>
                      <Button variant="outline" size="sm">
                        <Printer className="mr-2 h-4 w-4" /> Print Chart
                      </Button>
                    </div>
                  </div>
                  <div className="h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={revenueData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip formatter={(value) => `$${value}`} />
                        <Legend />
                        <Bar dataKey="revenue" name="Revenue" fill="#8884d8" />
                        <Bar dataKey="expenses" name="Expenses" fill="#82ca9d" />
                        <Bar dataKey="profit" name="Profit" fill="#ffc658" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Financial Metrics</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Revenue Growth</div>
                      <div className="text-2xl font-bold text-green-600 dark:text-green-400">+12.5%</div>
                      <div className="text-xs text-muted-foreground">vs previous period</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Profit Margin</div>
                      <div className="text-2xl font-bold">48.6%</div>
                      <div className="text-xs text-muted-foreground">+2.3% vs target</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Cost per Occupied Room</div>
                      <div className="text-2xl font-bold">$42.50</div>
                      <div className="text-xs text-muted-foreground">-$1.75 vs last year</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Revenue per Available Room</div>
                      <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">$148.34</div>
                      <div className="text-xs text-muted-foreground">+$12.45 vs target</div>
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Financial Summary Table</h3>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Month</TableHead>
                        <TableHead>Revenue</TableHead>
                        <TableHead>Expenses</TableHead>
                        <TableHead>Profit</TableHead>
                        <TableHead>Margin</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {revenueData.slice(-6).map((month) => (
                        <TableRow key={month.name}>
                          <TableCell className="font-medium">{month.name}</TableCell>
                          <TableCell>${month.revenue.toLocaleString()}</TableCell>
                          <TableCell>${month.expenses.toLocaleString()}</TableCell>
                          <TableCell>${month.profit.toLocaleString()}</TableCell>
                          <TableCell>{((month.profit / month.revenue) * 100).toFixed(1)}%</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </TabsContent>

            {/* Occupancy Reports Tab */}
            <TabsContent value="occupancy">
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Average Occupancy</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">78.3%</div>
                      <p className="text-xs text-muted-foreground">
                        <span className="text-green-500 inline-flex items-center">+5.2%</span> vs previous period
                      </p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Average Length of Stay</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">2.8 nights</div>
                      <p className="text-xs text-muted-foreground">
                        <span className="text-green-500 inline-flex items-center">+0.3</span> vs previous period
                      </p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Peak Occupancy Day</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">Saturday</div>
                      <p className="text-xs text-muted-foreground">92% average occupancy</p>
                    </CardContent>
                  </Card>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-medium">Occupancy Rate Trend</h3>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Table2 className="mr-2 h-4 w-4" /> View Data Table
                      </Button>
                      <Button variant="outline" size="sm">
                        <Printer className="mr-2 h-4 w-4" /> Print Chart
                      </Button>
                    </div>
                  </div>
                  <div className="h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={occupancyData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis domain={[0, 100]} />
                        <Tooltip formatter={(value) => `${value}%`} />
                        <Legend />
                        <Line
                          type="monotone"
                          dataKey="rate"
                          name="Occupancy Rate"
                          stroke="#8884d8"
                          activeDot={{ r: 8 }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Occupancy by Room Type</h3>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Room Type</TableHead>
                          <TableHead>Occupancy Rate</TableHead>
                          <TableHead>ADR</TableHead>
                          <TableHead>RevPAR</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        <TableRow>
                          <TableCell className="font-medium">Standard</TableCell>
                          <TableCell>82%</TableCell>
                          <TableCell>$99.99</TableCell>
                          <TableCell>$81.99</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">Deluxe</TableCell>
                          <TableCell>76%</TableCell>
                          <TableCell>$149.99</TableCell>
                          <TableCell>$113.99</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">Suite</TableCell>
                          <TableCell>68%</TableCell>
                          <TableCell>$249.99</TableCell>
                          <TableCell>$169.99</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">Executive</TableCell>
                          <TableCell>62%</TableCell>
                          <TableCell>$299.99</TableCell>
                          <TableCell>$185.99</TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Occupancy by Day of Week</h3>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={[
                            { name: "Mon", rate: 65 },
                            { name: "Tue", rate: 60 },
                            { name: "Wed", rate: 68 },
                            { name: "Thu", rate: 75 },
                            { name: "Fri", rate: 85 },
                            { name: "Sat", rate: 92 },
                            { name: "Sun", rate: 78 },
                          ]}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis domain={[0, 100]} />
                          <Tooltip formatter={(value) => `${value}%`} />
                          <Bar dataKey="rate" name="Occupancy Rate" fill="#8884d8" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Revenue Sources Tab */}
            <TabsContent value="revenue">
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">$209,200</div>
                      <p className="text-xs text-muted-foreground">Across all revenue streams</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Room Revenue</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">$135,980</div>
                      <p className="text-xs text-muted-foreground">65% of total revenue</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Ancillary Revenue</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">$73,220</div>
                      <p className="text-xs text-muted-foreground">35% of total revenue</p>
                    </CardContent>
                  </Card>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium">Revenue Breakdown</h3>
                    <div className="h-[400px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={revenueSourceData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={150}
                            fill="#8884d8"
                            dataKey="value"
                            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          >
                            {revenueSourceData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value) => `${value}%`} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Revenue Sources Detail</h3>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Revenue Source</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Percentage</TableHead>
                          <TableHead>YoY Change</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        <TableRow>
                          <TableCell className="font-medium">Room Bookings</TableCell>
                          <TableCell>$135,980</TableCell>
                          <TableCell>65%</TableCell>
                          <TableCell className="text-green-600">+12.5%</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">Restaurant</TableCell>
                          <TableCell>$31,380</TableCell>
                          <TableCell>15%</TableCell>
                          <TableCell className="text-green-600">+8.3%</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">Events</TableCell>
                          <TableCell>$20,920</TableCell>
                          <TableCell>10%</TableCell>
                          <TableCell className="text-green-600">+15.2%</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">Spa & Wellness</TableCell>
                          <TableCell>$14,644</TableCell>
                          <TableCell>7%</TableCell>
                          <TableCell className="text-green-600">+22.1%</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">Other</TableCell>
                          <TableCell>$6,276</TableCell>
                          <TableCell>3%</TableCell>
                          <TableCell className="text-red-600">-2.5%</TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Revenue Trends by Source</h3>
                  <div className="h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={[
                          { month: "Jan", rooms: 8125, restaurant: 1875, events: 1250, spa: 875, other: 375 },
                          { month: "Feb", rooms: 9230, restaurant: 2130, events: 1420, spa: 994, other: 426 },
                          { month: "Mar", rooms: 10270, restaurant: 2370, events: 1580, spa: 1106, other: 474 },
                          { month: "Apr", rooms: 10985, restaurant: 2535, events: 1690, spa: 1183, other: 507 },
                          { month: "May", rooms: 11830, restaurant: 2730, events: 1820, spa: 1274, other: 546 },
                          { month: "Jun", rooms: 12675, restaurant: 2925, events: 1950, spa: 1365, other: 585 },
                          { month: "Jul", rooms: 13650, restaurant: 3150, events: 2100, spa: 1470, other: 630 },
                          { month: "Aug", rooms: 14495, restaurant: 3345, events: 2230, spa: 1561, other: 669 },
                          { month: "Sep", rooms: 13065, restaurant: 3015, events: 2010, spa: 1407, other: 603 },
                          { month: "Oct", rooms: 12480, restaurant: 2880, events: 1920, spa: 1344, other: 576 },
                          { month: "Nov", rooms: 12025, restaurant: 2775, events: 1850, spa: 1295, other: 555 },
                          { month: "Dec", rooms: 15275, restaurant: 3525, events: 2350, spa: 1645, other: 705 },
                        ]}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip formatter={(value) => `$${value}`} />
                        <Legend />
                        <Line type="monotone" dataKey="rooms" name="Room Bookings" stroke="#0088FE" />
                        <Line type="monotone" dataKey="restaurant" name="Restaurant" stroke="#00C49F" />
                        <Line type="monotone" dataKey="events" name="Events" stroke="#FFBB28" />
                        <Line type="monotone" dataKey="spa" name="Spa & Wellness" stroke="#FF8042" />
                        <Line type="monotone" dataKey="other" name="Other" stroke="#8884D8" />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Booking Channels Tab */}
            <TabsContent value="booking">
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Total Bookings</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">2,350</div>
                      <p className="text-xs text-muted-foreground">
                        <span className="text-green-500 inline-flex items-center">+15.2%</span> vs previous period
                      </p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Direct Bookings</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">940</div>
                      <p className="text-xs text-muted-foreground">40% of total bookings</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">OTA Commission</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">$12,450</div>
                      <p className="text-xs text-muted-foreground">15% average commission rate</p>
                    </CardContent>
                  </Card>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium">Booking Channel Distribution</h3>
                    <div className="h-[400px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={bookingChannelData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={150}
                            fill="#8884d8"
                            dataKey="value"
                            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          >
                            {bookingChannelData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value) => `${value}%`} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Booking Channels Detail</h3>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Channel</TableHead>
                          <TableHead>Bookings</TableHead>
                          <TableHead>Percentage</TableHead>
                          <TableHead>Avg. Value</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        <TableRow>
                          <TableCell className="font-medium">Direct Website</TableCell>
                          <TableCell>940</TableCell>
                          <TableCell>40%</TableCell>
                          <TableCell>$325</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">Booking.com</TableCell>
                          <TableCell>588</TableCell>
                          <TableCell>25%</TableCell>
                          <TableCell>$295</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">Expedia</TableCell>
                          <TableCell>352</TableCell>
                          <TableCell>15%</TableCell>
                          <TableCell>$310</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">TripAdvisor</TableCell>
                          <TableCell>235</TableCell>
                          <TableCell>10%</TableCell>
                          <TableCell>$285</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">Phone/Walk-in</TableCell>
                          <TableCell>235</TableCell>
                          <TableCell>10%</TableCell>
                          <TableCell>$350</TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Booking Lead Time Analysis</h3>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={[
                          { range: "Same day", bookings: 235, percentage: 10 },
                          { range: "1-7 days", bookings: 470, percentage: 20 },
                          { range: "8-14 days", bookings: 588, percentage: 25 },
                          { range: "15-30 days", bookings: 470, percentage: 20 },
                          { range: "31-60 days", bookings: 352, percentage: 15 },
                          { range: "60+ days", bookings: 235, percentage: 10 },
                        ]}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="range" />
                        <YAxis yAxisId="left" orientation="left" />
                        <YAxis yAxisId="right" orientation="right" domain={[0, 100]} />
                        <Tooltip />
                        <Legend />
                        <Bar yAxisId="left" dataKey="bookings" name="Number of Bookings" fill="#8884d8" />
                        <Line yAxisId="right" type="monotone" dataKey="percentage" name="Percentage" stroke="#ff7300" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="flex justify-between">
          <div className="text-sm text-muted-foreground">
            Data last updated: {format(new Date(), "MMMM d, yyyy 'at' h:mm a")}
          </div>
          <Button variant="outline" size="sm">
            <RefreshCw className="mr-2 h-4 w-4" /> Refresh Data
          </Button>
        </CardFooter>
      </Card>

      <div className="mt-6">
        <BulkExport
          items={[
            {
              id: "1",
              name: "Financial Report - Q1",
              type: "Financial Report",
              lastUpdated: "2023-03-31",
              size: "1.2 MB",
            },
            {
              id: "2",
              name: "Occupancy Analysis - Q1",
              type: "Occupancy Report",
              lastUpdated: "2023-03-31",
              size: "0.8 MB",
            },
            {
              id: "3",
              name: "Revenue Breakdown - Q1",
              type: "Revenue Report",
              lastUpdated: "2023-03-31",
              size: "1.5 MB",
            },
            {
              id: "4",
              name: "Booking Channel Analysis - Q1",
              type: "Booking Report",
              lastUpdated: "2023-03-31",
              size: "1.1 MB",
            },
            {
              id: "5",
              name: "Financial Report - Q2",
              type: "Financial Report",
              lastUpdated: "2023-06-30",
              size: "1.3 MB",
            },
            {
              id: "6",
              name: "Occupancy Analysis - Q2",
              type: "Occupancy Report",
              lastUpdated: "2023-06-30",
              size: "0.9 MB",
            },
          ]}
          onExport={(selectedItems, format) => {
            console.log("Bulk exporting:", { selectedItems, format })
            // Here you would implement the actual export functionality
          }}
        />
      </div>
    </div>
  )
}

