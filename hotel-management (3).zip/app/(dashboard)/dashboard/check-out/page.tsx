"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CreditCard, DollarSign, FileText, LogOut, Printer, Search, RefreshCw } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { Checkbox } from "@/components/ui/checkbox"
import { toast } from "@/components/ui/use-toast"
import { DocumentExport } from "@/components/document-export"

// Sample check-out data
const checkOutsData = [
  {
    id: 1,
    bookingId: "B-1001",
    guest: "John Smith",
    email: "john.smith@example.com",
    phone: "+233 20 123 4567",
    room: "101",
    roomType: "Standard",
    checkIn: "2023-03-19",
    checkOut: "2023-03-22",
    status: "checked-in",
    adults: 2,
    children: 0,
    totalAmount: 299.97,
    paymentStatus: "paid",
    additionalCharges: 45.5,
    additionalChargesDescription: "Room service, mini bar",
  },
  {
    id: 2,
    bookingId: "B-1002",
    guest: "Sarah Johnson",
    email: "sarah.johnson@example.com",
    phone: "+233 24 987 6543",
    room: "202",
    roomType: "Deluxe",
    checkIn: "2023-03-17",
    checkOut: "2023-03-22",
    status: "checked-in",
    adults: 2,
    children: 1,
    totalAmount: 599.96,
    paymentStatus: "paid",
    additionalCharges: 120.75,
    additionalChargesDescription: "Restaurant, spa services",
  },
  {
    id: 3,
    bookingId: "B-1003",
    guest: "Michael Brown",
    email: "michael.brown@example.com",
    phone: "+233 27 456 7890",
    room: "301",
    roomType: "Suite",
    checkIn: "2023-03-18",
    checkOut: "2023-03-22",
    status: "checked-in",
    adults: 2,
    children: 0,
    totalAmount: 499.98,
    paymentStatus: "pending",
    additionalCharges: 0,
    additionalChargesDescription: "",
  },
]

// Sample recent check-outs
const recentCheckOutsData = [
  {
    id: 101,
    bookingId: "B-0995",
    guest: "Jennifer Lee",
    room: "201",
    roomType: "Deluxe",
    checkOutTime: "2023-03-21 10:30:45",
    totalPaid: 450.25,
  },
  {
    id: 102,
    bookingId: "B-0996",
    guest: "David Miller",
    room: "401",
    roomType: "Executive",
    checkOutTime: "2023-03-21 11:45:22",
    totalPaid: 780.5,
  },
  {
    id: 103,
    bookingId: "B-0997",
    guest: "Lisa Chen",
    room: "402",
    roomType: "Executive",
    checkOutTime: "2023-03-21 12:20:10",
    totalPaid: 825.75,
  },
]

export default function CheckOutPage() {
  const [checkOuts, setCheckOuts] = useState(checkOutsData)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCheckOut, setSelectedCheckOut] = useState<any>(null)
  const [isCheckOutDialogOpen, setIsCheckOutDialogOpen] = useState(false)
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [checkOutRequirements, setCheckOutRequirements] = useState({
    roomInspection: false,
    keyCardReturned: false,
    paymentSettled: false,
    feedbackCollected: false,
  })
  const [additionalCharges, setAdditionalCharges] = useState("")
  const [additionalChargesAmount, setAdditionalChargesAmount] = useState("")

  // Filter check-outs based on search term
  const filteredCheckOuts = checkOuts.filter((checkOut) => {
    return (
      checkOut.guest.toLowerCase().includes(searchTerm.toLowerCase()) ||
      checkOut.bookingId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      checkOut.room.toLowerCase().includes(searchTerm.toLowerCase())
    )
  })

  // Get user initials for avatar
  const getUserInitials = (name: string) => {
    return name
      .split(" ")
      .map((part) => part.charAt(0))
      .join("")
      .toUpperCase()
  }

  // Handle check-out process
  const handleCheckOut = (checkOut: any) => {
    setSelectedCheckOut(checkOut)

    // Pre-fill payment settled if already paid
    setCheckOutRequirements({
      ...checkOutRequirements,
      paymentSettled: checkOut.paymentStatus === "paid" && checkOut.additionalCharges === 0,
    })

    setIsCheckOutDialogOpen(true)
  }

  // Handle payment collection
  const handlePayment = (checkOut: any) => {
    setSelectedCheckOut(checkOut)
    setIsPaymentDialogOpen(true)
  }

  // Complete check-out process
  const completeCheckOut = () => {
    // Validate required fields
    if (
      !checkOutRequirements.roomInspection ||
      !checkOutRequirements.keyCardReturned ||
      !checkOutRequirements.paymentSettled
    ) {
      toast({
        title: "Missing Requirements",
        description: "Please complete all required check-out steps",
        variant: "destructive",
      })
      return
    }

    // Update the check-out in our state
    const updatedCheckOuts = checkOuts.filter((item) => item.id !== selectedCheckOut.id)

    // Update the state
    setCheckOuts(updatedCheckOuts)

    // Add to recent check-outs (in a real app)
    // setRecentCheckOuts([...recentCheckOuts, {...}])

    toast({
      title: "Check-out Completed",
      description: `${selectedCheckOut.guest} has been checked out from Room ${selectedCheckOut.room}`,
    })

    setIsCheckOutDialogOpen(false)

    // Reset form state
    setCheckOutRequirements({
      roomInspection: false,
      keyCardReturned: false,
      paymentSettled: false,
      feedbackCollected: false,
    })
    setAdditionalCharges("")
    setAdditionalChargesAmount("")
  }

  // Process payment
  const processPayment = () => {
    // Update the check-out in our state
    const updatedCheckOuts = checkOuts.map((checkOut) => {
      if (checkOut.id === selectedCheckOut.id) {
        return {
          ...checkOut,
          paymentStatus: "paid",
          additionalCharges: additionalChargesAmount
            ? Number.parseFloat(additionalChargesAmount)
            : checkOut.additionalCharges,
          additionalChargesDescription: additionalCharges || checkOut.additionalChargesDescription,
        }
      }
      return checkOut
    })

    // Update the state
    setCheckOuts(updatedCheckOuts)

    const totalAmount =
      selectedCheckOut.totalAmount +
      (additionalChargesAmount ? Number.parseFloat(additionalChargesAmount) : selectedCheckOut.additionalCharges)

    toast({
      title: "Payment Processed",
      description: `Payment of $${totalAmount.toFixed(2)} has been processed successfully`,
    })

    setIsPaymentDialogOpen(false)
  }

  // Simulate refreshing data
  const refreshData = () => {
    setIsRefreshing(true)

    // Simulate API call
    setTimeout(() => {
      setIsRefreshing(false)

      toast({
        title: "Data Refreshed",
        description: "Check-out data has been updated",
      })
    }, 1500)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search check-outs..."
            className="w-full pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Button variant="outline" size="sm" onClick={refreshData} disabled={isRefreshing}>
            <RefreshCw className={`mr-2 h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
            {isRefreshing ? "Refreshing..." : "Refresh Status"}
          </Button>
        </div>
      </div>

      <div className="mb-6">
        <Card>
          <CardHeader className="pb-3">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <div>
                <CardTitle>Today's Check-out Overview</CardTitle>
                <CardDescription>Status of expected departures</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">{checkOuts.length}</div>
                <div className="text-sm text-blue-700 dark:text-blue-500">Expected Departures</div>
              </div>
              <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border border-green-200 dark:border-green-800">
                <div className="text-2xl font-bold text-green-600 dark:text-green-400">2</div>
                <div className="text-sm text-green-700 dark:text-green-500">Checked Out</div>
              </div>
              <div className="bg-amber-50 dark:bg-amber-900/20 p-4 rounded-lg border border-amber-200 dark:border-amber-800">
                <div className="text-2xl font-bold text-amber-600 dark:text-amber-400">
                  {checkOuts.filter((checkOut) => checkOut.paymentStatus === "pending").length}
                </div>
                <div className="text-sm text-amber-700 dark:text-amber-500">Pending Payment</div>
              </div>
              <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-lg border border-purple-200 dark:border-purple-800">
                <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">1</div>
                <div className="text-sm text-purple-700 dark:text-purple-500">Late Check-outs</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="pending" className="space-y-4">
        <TabsList>
          <TabsTrigger value="pending">Pending Check-outs</TabsTrigger>
          <TabsTrigger value="recent">Recent Check-outs</TabsTrigger>
        </TabsList>

        <TabsContent value="pending">
          <Card>
            <CardHeader>
              <CardTitle>Today's Expected Check-outs</CardTitle>
              <CardDescription>
                Guests expected to check out today. Process their check-out and collect any pending payments.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Guest</TableHead>
                    <TableHead>Booking</TableHead>
                    <TableHead>Room</TableHead>
                    <TableHead>Stay Period</TableHead>
                    <TableHead>Payment</TableHead>
                    <TableHead>Additional Charges</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredCheckOuts.length > 0 ? (
                    filteredCheckOuts.map((checkOut) => (
                      <TableRow key={checkOut.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <Avatar>
                              <AvatarImage src={`/placeholder.svg?height=32&width=32`} alt={checkOut.guest} />
                              <AvatarFallback>{getUserInitials(checkOut.guest)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium">{checkOut.guest}</div>
                              <div className="text-xs text-muted-foreground">{checkOut.phone}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="font-medium">{checkOut.bookingId}</div>
                          <div className="text-xs text-muted-foreground">
                            {checkOut.adults} {checkOut.adults === 1 ? "Adult" : "Adults"}
                            {checkOut.children > 0 &&
                              `, ${checkOut.children} ${checkOut.children === 1 ? "Child" : "Children"}`}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div>{checkOut.room}</div>
                          <div className="text-xs text-muted-foreground">{checkOut.roomType}</div>
                        </TableCell>
                        <TableCell>
                          <div>{checkOut.checkIn}</div>
                          <div className="text-xs text-muted-foreground">to {checkOut.checkOut}</div>
                        </TableCell>
                        <TableCell>
                          {checkOut.paymentStatus === "paid" ? (
                            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                              Paid
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                              Pending
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          {checkOut.additionalCharges > 0 ? (
                            <div>
                              <div>${checkOut.additionalCharges.toFixed(2)}</div>
                              <div className="text-xs text-muted-foreground truncate max-w-[150px]">
                                {checkOut.additionalChargesDescription}
                              </div>
                            </div>
                          ) : (
                            <span className="text-muted-foreground">None</span>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            {(checkOut.paymentStatus === "pending" || checkOut.additionalCharges > 0) && (
                              <Button variant="outline" size="sm" onClick={() => handlePayment(checkOut)}>
                                <DollarSign className="h-4 w-4" />
                                <span className="sr-only">Collect Payment</span>
                              </Button>
                            )}
                            <Button variant="default" size="sm" onClick={() => handleCheckOut(checkOut)}>
                              <LogOut className="h-4 w-4" />
                              <span className="sr-only">Check Out</span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={7} className="h-24 text-center">
                        No pending check-outs found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recent">
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                <div>
                  <CardTitle>Recently Checked-out Guests</CardTitle>
                  <CardDescription>Guests who have checked out recently.</CardDescription>
                </div>
                <DocumentExport
                  documentId="recent-checkouts"
                  documentName="Recent Check-outs Report"
                  documentType="report"
                  onExport={(format) => {
                    toast({
                      title: "Report Exported",
                      description: `Recent check-outs exported as ${format.toUpperCase()}`,
                    })
                  }}
                />
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Guest</TableHead>
                    <TableHead>Booking</TableHead>
                    <TableHead>Room</TableHead>
                    <TableHead>Check-out Time</TableHead>
                    <TableHead>Total Paid</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentCheckOutsData.map((checkOut) => (
                    <TableRow key={checkOut.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarImage src={`/placeholder.svg?height=32&width=32`} alt={checkOut.guest} />
                            <AvatarFallback>{getUserInitials(checkOut.guest)}</AvatarFallback>
                          </Avatar>
                          <div className="font-medium">{checkOut.guest}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">{checkOut.bookingId}</div>
                      </TableCell>
                      <TableCell>
                        <div>{checkOut.room}</div>
                        <div className="text-xs text-muted-foreground">{checkOut.roomType}</div>
                      </TableCell>
                      <TableCell>{checkOut.checkOutTime}</TableCell>
                      <TableCell>${checkOut.totalPaid.toFixed(2)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              toast({
                                title: "Receipt Printed",
                                description: `Receipt for ${checkOut.guest} sent to printer`,
                              })
                            }}
                          >
                            <Printer className="h-4 w-4" />
                            <span className="sr-only">Print Receipt</span>
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              toast({
                                title: "Details Viewed",
                                description: `Viewing details for ${checkOut.guest}`,
                              })
                            }}
                          >
                            <FileText className="h-4 w-4" />
                            <span className="sr-only">View Details</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Check-out Dialog */}
      {selectedCheckOut && (
        <Dialog open={isCheckOutDialogOpen} onOpenChange={setIsCheckOutDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Guest Check-out</DialogTitle>
              <DialogDescription>Complete the check-out process for {selectedCheckOut.guest}.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium mb-2">Guest Information</h3>
                  <div className="text-sm space-y-1">
                    <p>
                      <span className="font-medium">Name:</span> {selectedCheckOut.guest}
                    </p>
                    <p>
                      <span className="font-medium">Email:</span> {selectedCheckOut.email}
                    </p>
                    <p>
                      <span className="font-medium">Phone:</span> {selectedCheckOut.phone}
                    </p>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium mb-2">Booking Details</h3>
                  <div className="text-sm space-y-1">
                    <p>
                      <span className="font-medium">Booking ID:</span> {selectedCheckOut.bookingId}
                    </p>
                    <p>
                      <span className="font-medium">Room:</span> {selectedCheckOut.room} ({selectedCheckOut.roomType})
                    </p>
                    <p>
                      <span className="font-medium">Stay:</span> {selectedCheckOut.checkIn} to{" "}
                      {selectedCheckOut.checkOut}
                    </p>
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="text-sm font-medium mb-2">Check-out Requirements</h3>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="room-inspection"
                      checked={checkOutRequirements.roomInspection}
                      onCheckedChange={(checked) =>
                        setCheckOutRequirements({ ...checkOutRequirements, roomInspection: checked === true })
                      }
                    />
                    <Label htmlFor="room-inspection">Room Inspection Completed</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="key-card-returned"
                      checked={checkOutRequirements.keyCardReturned}
                      onCheckedChange={(checked) =>
                        setCheckOutRequirements({ ...checkOutRequirements, keyCardReturned: checked === true })
                      }
                    />
                    <Label htmlFor="key-card-returned">Key Card Returned</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="payment-settled"
                      checked={checkOutRequirements.paymentSettled || selectedCheckOut.paymentStatus === "paid"}
                      disabled={selectedCheckOut.paymentStatus === "paid" && selectedCheckOut.additionalCharges === 0}
                      onCheckedChange={(checked) =>
                        setCheckOutRequirements({ ...checkOutRequirements, paymentSettled: checked === true })
                      }
                    />
                    <Label htmlFor="payment-settled">Payment Settled</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="feedback-collected"
                      checked={checkOutRequirements.feedbackCollected}
                      onCheckedChange={(checked) =>
                        setCheckOutRequirements({ ...checkOutRequirements, feedbackCollected: checked === true })
                      }
                    />
                    <Label htmlFor="feedback-collected">Feedback Collected</Label>
                  </div>
                </div>
              </div>

              {selectedCheckOut.additionalCharges > 0 && (
                <div>
                  <h3 className="text-sm font-medium mb-2">Additional Charges</h3>
                  <div className="text-sm p-3 bg-muted rounded-md">
                    <div className="flex justify-between mb-1">
                      <span>Amount:</span>
                      <span>${selectedCheckOut.additionalCharges.toFixed(2)}</span>
                    </div>
                    <div>
                      <span className="font-medium">Description:</span> {selectedCheckOut.additionalChargesDescription}
                    </div>
                  </div>
                </div>
              )}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCheckOutDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" onClick={completeCheckOut}>
                <LogOut className="mr-2 h-4 w-4" />
                Complete Check-out
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Payment Dialog */}
      {selectedCheckOut && (
        <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Collect Payment</DialogTitle>
              <DialogDescription>Process payment for booking {selectedCheckOut.bookingId}.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="bg-muted p-4 rounded-md">
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium">Room Charge:</span>
                  <span>${selectedCheckOut.totalAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium">Additional Charges:</span>
                  <span>${selectedCheckOut.additionalCharges.toFixed(2)}</span>
                </div>
                <Separator className="my-2" />
                <div className="flex justify-between font-bold">
                  <span>Total Amount:</span>
                  <span>${(selectedCheckOut.totalAmount + selectedCheckOut.additionalCharges).toFixed(2)}</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="additional-charges">Additional Charges Description</Label>
                <Input
                  id="additional-charges"
                  placeholder="e.g. Room service, mini bar, etc."
                  value={additionalCharges}
                  onChange={(e) => setAdditionalCharges(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="additional-charges-amount">Additional Charges Amount ($)</Label>
                <Input
                  id="additional-charges-amount"
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  value={additionalChargesAmount}
                  onChange={(e) => setAdditionalChargesAmount(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="payment-method">Payment Method</Label>
                <Select>
                  <SelectTrigger id="payment-method">
                    <SelectValue placeholder="Select payment method" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="credit">Credit Card</SelectItem>
                    <SelectItem value="mobile">Mobile Money (MTN GH)</SelectItem>
                    <SelectItem value="cash">Cash</SelectItem>
                    <SelectItem value="bank">Bank Transfer</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="transaction-reference">Transaction Reference</Label>
                <Input id="transaction-reference" placeholder="Enter transaction reference" />
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox id="send-receipt" />
                <Label htmlFor="send-receipt">Send receipt to guest email</Label>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsPaymentDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" onClick={processPayment}>
                <CreditCard className="mr-2 h-4 w-4" />
                Process Payment
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}

