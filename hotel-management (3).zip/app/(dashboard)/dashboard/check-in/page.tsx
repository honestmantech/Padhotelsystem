"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  CreditCard,
  DollarSign,
  FileText,
  Key,
  Printer,
  Search,
  User,
  RefreshCw,
  CheckCircle,
  AlertCircle,
} from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { Checkbox } from "@/components/ui/checkbox"
import { toast } from "@/components/ui/use-toast"
import { DocumentExport } from "@/components/document-export"

// Sample recent check-ins
const recentCheckInsData = [
  {
    id: 101,
    bookingId: "B-0995",
    guest: "Jennifer Lee",
    room: "201",
    roomType: "Deluxe",
    checkInTime: "2023-03-21 14:30:45",
    checkOut: "2023-03-23",
    adults: 2,
    children: 1,
  },
  {
    id: 102,
    bookingId: "B-0996",
    guest: "David Miller",
    room: "401",
    roomType: "Executive",
    checkInTime: "2023-03-21 15:45:22",
    checkOut: "2023-03-26",
    adults: 2,
    children: 0,
  },
  {
    id: 103,
    bookingId: "B-0997",
    guest: "Lisa Chen",
    room: "402",
    roomType: "Executive",
    checkInTime: "2023-03-21 16:20:10",
    checkOut: "2023-03-24",
    adults: 2,
    children: 0,
  },
]

// Add this function to handle printing safely
const handlePrint = () => {
  if (typeof window !== "undefined") {
    // In a real app, you might want to generate a printable version first
    // For now, we'll just show a toast
    toast({
      title: "Printing Arrival List",
      description: "The arrival list has been sent to the printer",
    })

    // Actual printing would be something like:
    // window.print()
    // Or a more sophisticated approach using a print-specific CSS and window.open()
  }
}

// Add this function to handle form submissions and update the UI
const handleFormSubmit = (formData: any, successMessage: string) => {
  // In a real app, this would send data to an API
  // For now, we'll just show a success message

  // Simulate API call
  setTimeout(() => {
    toast({
      title: "Success",
      description: successMessage,
    })

    // In a real app, you would update the state with the new data
    // For example:
    // setCheckInsData([...checkInsData, newCheckIn])

    // For now, we'll just refresh the data to simulate an update
    refreshData()
  }, 500)
}

export default function CheckInPage() {
  const [checkInsData, setCheckInsData] = useState([
    {
      id: 1,
      bookingId: "B-1001",
      guest: "John Smith",
      email: "john.smith@example.com",
      phone: "+233 20 123 4567",
      room: "101",
      roomType: "Standard",
      checkIn: "2023-03-22",
      checkOut: "2023-03-25",
      status: "pending",
      adults: 2,
      children: 0,
      totalAmount: 299.97,
      paymentStatus: "paid",
      specialRequests: "Early check-in if possible",
      roomStatus: "ready",
    },
    {
      id: 2,
      bookingId: "B-1002",
      guest: "Sarah Johnson",
      email: "sarah.johnson@example.com",
      phone: "+233 24 987 6543",
      room: "202",
      roomType: "Deluxe",
      checkIn: "2023-03-22",
      checkOut: "2023-03-27",
      status: "pending",
      adults: 2,
      children: 1,
      totalAmount: 599.96,
      paymentStatus: "paid",
      specialRequests: "High floor room with view",
      roomStatus: "ready",
    },
    {
      id: 3,
      bookingId: "B-1003",
      guest: "Michael Brown",
      email: "michael.brown@example.com",
      phone: "+233 27 456 7890",
      room: "301",
      roomType: "Suite",
      checkIn: "2023-03-22",
      checkOut: "2023-03-26",
      status: "pending",
      adults: 2,
      children: 0,
      totalAmount: 499.98,
      paymentStatus: "pending",
      specialRequests: "Extra pillows",
      roomStatus: "cleaning",
    },
    {
      id: 4,
      bookingId: "B-1004",
      guest: "Emily Davis",
      email: "emily.davis@example.com",
      phone: "+233 23 345 6789",
      room: "102",
      roomType: "Standard",
      checkIn: "2023-03-22",
      checkOut: "2023-03-28",
      status: "pending",
      adults: 1,
      children: 0,
      totalAmount: 299.97,
      paymentStatus: "paid",
      specialRequests: "",
      roomStatus: "ready",
    },
    {
      id: 5,
      bookingId: "B-1005",
      guest: "Robert Wilson",
      email: "robert.wilson@example.com",
      phone: "+233 26 789 0123",
      room: "302",
      roomType: "Suite",
      checkIn: "2023-03-22",
      checkOut: "2023-03-30",
      status: "pending",
      adults: 2,
      children: 2,
      totalAmount: 999.96,
      paymentStatus: "pending",
      specialRequests: "Connecting rooms if possible",
      roomStatus: "maintenance",
    },
  ])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedBooking, setSelectedBooking] = useState<any>(null)
  const [isCheckInDialogOpen, setIsCheckInDialogOpen] = useState(false)
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false)
  const [isWalkInDialogOpen, setIsWalkInDialogOpen] = useState(false)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [checkInRequirements, setCheckInRequirements] = useState({
    idVerification: false,
    paymentConfirmation: false,
    registrationForm: false,
    keyCard: false,
  })
  const [additionalServices, setAdditionalServices] = useState({
    wifiAccess: false,
    breakfast: false,
    parking: false,
  })
  const [checkInNotes, setCheckInNotes] = useState("")

  // Filter check-ins based on search term
  const filteredCheckIns = checkInsData.filter((checkIn) => {
    return (
      checkIn.guest.toLowerCase().includes(searchTerm.toLowerCase()) ||
      checkIn.bookingId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      checkIn.room.toLowerCase().includes(searchTerm.toLowerCase())
    )
  })

  // Get user initials for avatar
  const getUserInitials = (name: string) => {
    return name
      .split(" ")
      .map((part) => part.charAt(0))
      .join("")
      .toUpperCase()
  }

  // Handle check-in process
  const handleCheckIn = (booking: any) => {
    setSelectedBooking(booking)

    // Pre-fill payment confirmation if already paid
    setCheckInRequirements({
      ...checkInRequirements,
      paymentConfirmation: booking.paymentStatus === "paid",
    })

    setIsCheckInDialogOpen(true)
  }

  // Handle payment collection
  const handlePayment = (booking: any) => {
    setSelectedBooking(booking)
    setIsPaymentDialogOpen(true)
  }

  // Complete check-in process
  const completeCheckIn = () => {
    // Validate required fields
    if (
      !checkInRequirements.idVerification ||
      !checkInRequirements.paymentConfirmation ||
      !checkInRequirements.registrationForm ||
      !checkInRequirements.keyCard
    ) {
      toast({
        title: "Missing Requirements",
        description: "Please complete all required check-in steps",
        variant: "destructive",
      })
      return
    }

    // Update the booking in our state
    const updatedCheckIns = checkInsData.map((checkIn) => {
      if (checkIn.id === selectedBooking.id) {
        return {
          ...checkIn,
          status: "checked-in",
          paymentStatus: "paid",
          notes: checkInNotes || checkIn.notes,
        }
      }
      return checkIn
    })

    // Update the state
    setCheckInsData(updatedCheckIns)

    toast({
      title: "Check-in Completed",
      description: `${selectedBooking.guest} has been checked in to Room ${selectedBooking.room}`,
    })

    setIsCheckInDialogOpen(false)

    // Reset form state
    setCheckInRequirements({
      idVerification: false,
      paymentConfirmation: false,
      registrationForm: false,
      keyCard: false,
    })
    setAdditionalServices({
      wifiAccess: false,
      breakfast: false,
      parking: false,
    })
    setCheckInNotes("")
  }

  // Process payment
  const processPayment = () => {
    // Update the booking in our state
    const updatedCheckIns = checkInsData.map((checkIn) => {
      if (checkIn.id === selectedBooking.id) {
        return {
          ...checkIn,
          paymentStatus: "paid",
        }
      }
      return checkIn
    })

    // Update the state
    setCheckInsData(updatedCheckIns)

    toast({
      title: "Payment Processed",
      description: `Payment of $${selectedBooking.totalAmount.toFixed(2)} has been processed successfully`,
    })

    setIsPaymentDialogOpen(false)
  }

  // Simulate refreshing data with actual state updates
  const refreshData = () => {
    setIsRefreshing(true)

    // Simulate API call
    setTimeout(() => {
      // In a real app, this would fetch fresh data from the API
      // For now, we'll just update the UI state to simulate changes

      // Create a copy of the data with updated statuses to simulate changes
      const updatedCheckIns = checkInsData.map((checkIn) => {
        // Simulate some random changes to the data
        if (checkIn.id === selectedBooking?.id && selectedBooking) {
          // If we were processing a specific booking, update its status
          return {
            ...checkIn,
            status: "checked-in",
            paymentStatus: "paid",
          }
        }
        return checkIn
      })

      // Update the state with the new data
      setCheckInsData(updatedCheckIns)
      setIsRefreshing(false)

      toast({
        title: "Data Refreshed",
        description: "Check-in data has been updated",
      })
    }, 1500)
  }

  // Print arrival list
  const printArrivalList = () => {
    handlePrint()
  }

  // Get room status badge
  const getRoomStatusBadge = (status: string) => {
    switch (status) {
      case "ready":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            <CheckCircle className="mr-1 h-3 w-3" /> Ready
          </Badge>
        )
      case "cleaning":
        return (
          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
            <RefreshCw className="mr-1 h-3 w-3" /> Cleaning
          </Badge>
        )
      case "maintenance":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            <AlertCircle className="mr-1 h-3 w-3" /> Maintenance
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search check-ins..."
            className="w-full pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Dialog open={isWalkInDialogOpen} onOpenChange={setIsWalkInDialogOpen}>
            <DialogTrigger asChild>
              <Button className="w-full sm:w-auto">
                <User className="mr-2 h-4 w-4" /> Walk-in Check-in
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Walk-in Guest Check-in</DialogTitle>
                <DialogDescription>Register a new walk-in guest and assign a room.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="guest-name">Guest Name</Label>
                    <Input id="guest-name" placeholder="Full name" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="guest-email">Email</Label>
                    <Input id="guest-email" type="email" placeholder="Email address" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="guest-phone">Phone</Label>
                    <Input id="guest-phone" placeholder="Phone number" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="id-number">ID Number</Label>
                    <Input id="id-number" placeholder="Passport/ID number" />
                  </div>
                </div>
                <Separator />
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="room-type">Room Type</Label>
                    <Select>
                      <SelectTrigger id="room-type">
                        <SelectValue placeholder="Select room type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="standard">Standard</SelectItem>
                        <SelectItem value="deluxe">Deluxe</SelectItem>
                        <SelectItem value="suite">Suite</SelectItem>
                        <SelectItem value="executive">Executive</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="room-number">Room Number</Label>
                    <Select>
                      <SelectTrigger id="room-number">
                        <SelectValue placeholder="Select room" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="101">101 - Standard</SelectItem>
                        <SelectItem value="102">102 - Standard</SelectItem>
                        <SelectItem value="201">201 - Deluxe</SelectItem>
                        <SelectItem value="202">202 - Deluxe</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="check-in-date">Check-in Date</Label>
                    <Input id="check-in-date" type="date" defaultValue={new Date().toISOString().split("T")[0]} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="check-out-date">Check-out Date</Label>
                    <Input id="check-out-date" type="date" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="adults">Adults</Label>
                    <Input id="adults" type="number" min="1" defaultValue="1" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="children">Children</Label>
                    <Input id="children" type="number" min="0" defaultValue="0" />
                  </div>
                </div>
                <Separator />
                <div className="space-y-2">
                  <Label htmlFor="room-rate">Room Rate (per night)</Label>
                  <Input id="room-rate" type="number" step="0.01" placeholder="0.00" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="payment-method">Payment Method</Label>
                  <Select>
                    <SelectTrigger id="payment-method">
                      <SelectValue placeholder="Select payment method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="credit">Credit Card</SelectItem>
                      <SelectItem value="mobile">Mobile Money (MTN GH)</SelectItem>
                      <SelectItem value="cash">Cash</SelectItem>
                      <SelectItem value="bank">Bank Transfer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="special-requests">Special Requests</Label>
                  <Input id="special-requests" placeholder="Any special requests" />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsWalkInDialogOpen(false)}>
                  Cancel
                </Button>
                <Button
                  type="submit"
                  onClick={() => {
                    setIsWalkInDialogOpen(false)
                    toast({
                      title: "Walk-in Check-in Completed",
                      description: "The guest has been checked in successfully",
                    })
                  }}
                >
                  Complete Check-in
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="mb-6">
        <Card>
          <CardHeader className="pb-3">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <div>
                <CardTitle>Today's Check-in Overview</CardTitle>
                <CardDescription>Status of expected arrivals and room readiness</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={printArrivalList}>
                  <Printer className="mr-2 h-4 w-4" /> Print Arrival List
                </Button>
                <Button variant="outline" size="sm" onClick={refreshData} disabled={isRefreshing}>
                  <RefreshCw className={`mr-2 h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
                  {isRefreshing ? "Refreshing..." : "Refresh Status"}
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">{checkInsData.length}</div>
                <div className="text-sm text-blue-700 dark:text-blue-500">Expected Arrivals</div>
              </div>
              <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border border-green-200 dark:border-green-800">
                <div className="text-2xl font-bold text-green-600 dark:text-green-400">3</div>
                <div className="text-sm text-green-700 dark:text-green-500">Checked In</div>
              </div>
              <div className="bg-amber-50 dark:bg-amber-900/20 p-4 rounded-lg border border-amber-200 dark:border-amber-800">
                <div className="text-2xl font-bold text-amber-600 dark:text-amber-400">
                  {checkInsData.filter((checkIn) => checkIn.paymentStatus === "pending").length}
                </div>
                <div className="text-sm text-amber-700 dark:text-amber-500">Pending Payment</div>
              </div>
              <div className="bg-red-50 dark:bg-red-900/20 p-4 rounded-lg border border-red-200 dark:border-red-800">
                <div className="text-2xl font-bold text-red-600 dark:text-red-400">1</div>
                <div className="text-sm text-red-700 dark:text-red-500">No-Shows (Yesterday)</div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="text-sm font-medium">Room Readiness Status</div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="border rounded-md p-4">
                  <div className="flex justify-between items-center mb-3">
                    <div className="font-medium">Rooms Ready for Check-in</div>
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      12 Rooms
                    </Badge>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Standard Rooms</span>
                      <span>5/5 Ready</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="bg-green-500 h-full rounded-full" style={{ width: "100%" }}></div>
                    </div>

                    <div className="flex justify-between text-sm">
                      <span>Deluxe Rooms</span>
                      <span>4/4 Ready</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="bg-green-500 h-full rounded-full" style={{ width: "100%" }}></div>
                    </div>

                    <div className="flex justify-between text-sm">
                      <span>Suites</span>
                      <span>3/3 Ready</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="bg-green-500 h-full rounded-full" style={{ width: "100%" }}></div>
                    </div>
                  </div>
                </div>

                <div className="border rounded-md p-4">
                  <div className="flex justify-between items-center mb-3">
                    <div className="font-medium">Housekeeping Status</div>
                    <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                      In Progress
                    </Badge>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Rooms Cleaned</span>
                      <span>12/15</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="bg-green-500 h-full rounded-full" style={{ width: "80%" }}></div>
                    </div>

                    <div className="flex justify-between text-sm">
                      <span>Rooms Inspected</span>
                      <span>10/15</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="bg-green-500 h-full rounded-full" style={{ width: "67%" }}></div>
                    </div>

                    <div className="flex justify-between text-sm">
                      <span>Maintenance Issues</span>
                      <span>1 Pending</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="bg-red-500 h-full rounded-full" style={{ width: "10%" }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="pending" className="space-y-4">
        <TabsList>
          <TabsTrigger value="pending">Pending Check-ins</TabsTrigger>
          <TabsTrigger value="recent">Recent Check-ins</TabsTrigger>
        </TabsList>

        <TabsContent value="pending">
          <Card>
            <CardHeader>
              <CardTitle>Today's Expected Check-ins</CardTitle>
              <CardDescription>
                Guests expected to check in today. Process their check-in and collect any pending payments.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Guest</TableHead>
                    <TableHead>Booking</TableHead>
                    <TableHead>Room</TableHead>
                    <TableHead>Stay Period</TableHead>
                    <TableHead>Payment</TableHead>
                    <TableHead>Room Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredCheckIns.length > 0 ? (
                    filteredCheckIns.map((checkIn) => (
                      <TableRow key={checkIn.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <Avatar>
                              <AvatarImage src={`/placeholder.svg?height=32&width=32`} alt={checkIn.guest} />
                              <AvatarFallback>{getUserInitials(checkIn.guest)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium">{checkIn.guest}</div>
                              <div className="text-xs text-muted-foreground">{checkIn.phone}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="font-medium">{checkIn.bookingId}</div>
                          <div className="text-xs text-muted-foreground">
                            {checkIn.adults} {checkIn.adults === 1 ? "Adult" : "Adults"}
                            {checkIn.children > 0 &&
                              `, ${checkIn.children} ${checkIn.children === 1 ? "Child" : "Children"}`}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div>{checkIn.room}</div>
                          <div className="text-xs text-muted-foreground">{checkIn.roomType}</div>
                        </TableCell>
                        <TableCell>
                          <div>{checkIn.checkIn}</div>
                          <div className="text-xs text-muted-foreground">to {checkIn.checkOut}</div>
                        </TableCell>
                        <TableCell>
                          {checkIn.paymentStatus === "paid" ? (
                            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                              Paid
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                              Pending
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>{getRoomStatusBadge(checkIn.roomStatus)}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            {checkIn.paymentStatus === "pending" && (
                              <Button variant="outline" size="sm" onClick={() => handlePayment(checkIn)}>
                                <DollarSign className="h-4 w-4" />
                                <span className="sr-only">Collect Payment</span>
                              </Button>
                            )}
                            <Button
                              variant="default"
                              size="sm"
                              onClick={() => handleCheckIn(checkIn)}
                              disabled={checkIn.roomStatus !== "ready"}
                            >
                              <Key className="h-4 w-4" />
                              <span className="sr-only">Check In</span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={7} className="h-24 text-center">
                        No pending check-ins found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recent">
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                <div>
                  <CardTitle>Recently Checked-in Guests</CardTitle>
                  <CardDescription>Guests who have checked in recently.</CardDescription>
                </div>
                <DocumentExport
                  documentId="recent-checkins"
                  documentName="Recent Check-ins Report"
                  documentType="report"
                  onExport={(format) => {
                    toast({
                      title: "Report Exported",
                      description: `Recent check-ins exported as ${format.toUpperCase()}`,
                    })
                  }}
                />
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Guest</TableHead>
                    <TableHead>Booking</TableHead>
                    <TableHead>Room</TableHead>
                    <TableHead>Check-in Time</TableHead>
                    <TableHead>Check-out Date</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentCheckInsData.map((checkIn) => (
                    <TableRow key={checkIn.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarImage src={`/placeholder.svg?height=32&width=32`} alt={checkIn.guest} />
                            <AvatarFallback>{getUserInitials(checkIn.guest)}</AvatarFallback>
                          </Avatar>
                          <div className="font-medium">{checkIn.guest}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">{checkIn.bookingId}</div>
                        <div className="text-xs text-muted-foreground">
                          {checkIn.adults} {checkIn.adults === 1 ? "Adult" : "Adults"}
                          {checkIn.children > 0 &&
                            `, ${checkIn.children} ${checkIn.children === 1 ? "Child" : "Children"}`}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>{checkIn.room}</div>
                        <div className="text-xs text-muted-foreground">{checkIn.roomType}</div>
                      </TableCell>
                      <TableCell>{checkIn.checkInTime}</TableCell>
                      <TableCell>{checkIn.checkOut}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              toast({
                                title: "Details Viewed",
                                description: `Viewing details for ${checkIn.guest}`,
                              })
                            }}
                          >
                            <FileText className="h-4 w-4" />
                            <span className="sr-only">View Details</span>
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              toast({
                                title: "Receipt Printed",
                                description: `Receipt for ${checkIn.guest} sent to printer`,
                              })
                            }}
                          >
                            <Printer className="h-4 w-4" />
                            <span className="sr-only">Print Receipt</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Check-in Dialog */}
      {selectedBooking && (
        <Dialog open={isCheckInDialogOpen} onOpenChange={setIsCheckInDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Guest Check-in</DialogTitle>
              <DialogDescription>Complete the check-in process for {selectedBooking.guest}.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium mb-2">Guest Information</h3>
                  <div className="text-sm space-y-1">
                    <p>
                      <span className="font-medium">Name:</span> {selectedBooking.guest}
                    </p>
                    <p>
                      <span className="font-medium">Email:</span> {selectedBooking.email}
                    </p>
                    <p>
                      <span className="font-medium">Phone:</span> {selectedBooking.phone}
                    </p>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium mb-2">Booking Details</h3>
                  <div className="text-sm space-y-1">
                    <p>
                      <span className="font-medium">Booking ID:</span> {selectedBooking.bookingId}
                    </p>
                    <p>
                      <span className="font-medium">Room:</span> {selectedBooking.room} ({selectedBooking.roomType})
                    </p>
                    <p>
                      <span className="font-medium">Stay:</span> {selectedBooking.checkIn} to {selectedBooking.checkOut}
                    </p>
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="text-sm font-medium mb-2">Check-in Requirements</h3>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="id-verification"
                      checked={checkInRequirements.idVerification}
                      onCheckedChange={(checked) =>
                        setCheckInRequirements({ ...checkInRequirements, idVerification: checked === true })
                      }
                    />
                    <Label htmlFor="id-verification">ID Verification</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="payment-confirmation"
                      checked={checkInRequirements.paymentConfirmation || selectedBooking.paymentStatus === "paid"}
                      disabled={selectedBooking.paymentStatus === "paid"}
                      onCheckedChange={(checked) =>
                        setCheckInRequirements({ ...checkInRequirements, paymentConfirmation: checked === true })
                      }
                    />
                    <Label htmlFor="payment-confirmation">Payment Confirmation</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="registration-form"
                      checked={checkInRequirements.registrationForm}
                      onCheckedChange={(checked) =>
                        setCheckInRequirements({ ...checkInRequirements, registrationForm: checked === true })
                      }
                    />
                    <Label htmlFor="registration-form">Registration Form Completed</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="key-card"
                      checked={checkInRequirements.keyCard}
                      onCheckedChange={(checked) =>
                        setCheckInRequirements({ ...checkInRequirements, keyCard: checked === true })
                      }
                    />
                    <Label htmlFor="key-card">Key Card Issued</Label>
                  </div>
                </div>
              </div>

              {selectedBooking.specialRequests && (
                <div>
                  <h3 className="text-sm font-medium mb-2">Special Requests</h3>
                  <div className="text-sm p-3 bg-muted rounded-md">{selectedBooking.specialRequests}</div>
                </div>
              )}

              <div>
                <h3 className="text-sm font-medium mb-2">Additional Services</h3>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="wifi-access"
                      checked={additionalServices.wifiAccess}
                      onCheckedChange={(checked) =>
                        setAdditionalServices({ ...additionalServices, wifiAccess: checked === true })
                      }
                    />
                    <Label htmlFor="wifi-access">WiFi Access</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="breakfast"
                      checked={additionalServices.breakfast}
                      onCheckedChange={(checked) =>
                        setAdditionalServices({ ...additionalServices, breakfast: checked === true })
                      }
                    />
                    <Label htmlFor="breakfast">Breakfast Package</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="parking"
                      checked={additionalServices.parking}
                      onCheckedChange={(checked) =>
                        setAdditionalServices({ ...additionalServices, parking: checked === true })
                      }
                    />
                    <Label htmlFor="parking">Parking Space</Label>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="check-in-notes">Check-in Notes</Label>
                <Input
                  id="check-in-notes"
                  placeholder="Add any notes about this check-in"
                  value={checkInNotes}
                  onChange={(e) => setCheckInNotes(e.target.value)}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCheckInDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" onClick={completeCheckIn}>
                <Key className="mr-2 h-4 w-4" />
                Complete Check-in
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Payment Dialog */}
      {selectedBooking && (
        <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Collect Payment</DialogTitle>
              <DialogDescription>Process payment for booking {selectedBooking.bookingId}.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="bg-muted p-4 rounded-md">
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium">Room Charge:</span>
                  <span>${selectedBooking.totalAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium">Tax (10%):</span>
                  <span>${(selectedBooking.totalAmount * 0.1).toFixed(2)}</span>
                </div>
                <Separator className="my-2" />
                <div className="flex justify-between font-bold">
                  <span>Total Amount:</span>
                  <span>${(selectedBooking.totalAmount * 1.1).toFixed(2)}</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="payment-method">Payment Method</Label>
                <Select>
                  <SelectTrigger id="payment-method">
                    <SelectValue placeholder="Select payment method" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="credit">Credit Card</SelectItem>
                    <SelectItem value="mobile">Mobile Money (MTN GH)</SelectItem>
                    <SelectItem value="cash">Cash</SelectItem>
                    <SelectItem value="bank">Bank Transfer</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="transaction-reference">Transaction Reference</Label>
                <Input id="transaction-reference" placeholder="Enter transaction reference" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="payment-notes">Payment Notes</Label>
                <Input id="payment-notes" placeholder="Add any notes about this payment" />
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox id="send-receipt" />
                <Label htmlFor="send-receipt">Send receipt to guest email</Label>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsPaymentDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" onClick={processPayment}>
                <CreditCard className="mr-2 h-4 w-4" />
                Process Payment
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}

