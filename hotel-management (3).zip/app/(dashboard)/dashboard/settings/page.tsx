"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import {
  AlertCircle,
  Bell,
  Building,
  Check,
  CreditCard,
  Database,
  FileText,
  Globe,
  HelpCircle,
  Info,
  Key,
  Mail,
  MessageSquare,
  Palette,
  Percent,
  Save,
  Shield,
  Smartphone,
  Upload,
  Users,
  Wrench,
  Plus,
  Trash,
  Calendar,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { TooltipProvider } from "@/components/ui/tooltip"

// First, import the FileUpload component
import { FileUpload } from "@/components/file-upload"

// Sample roles data
const rolesData = [
  {
    id: 1,
    name: "Administrator",
    description: "Full access to all system features",
    userCount: 3,
    permissions: [
      "dashboard.view",
      "rooms.manage",
      "bookings.manage",
      "users.manage",
      "staff.manage",
      "payments.manage",
      "settings.manage",
      "reports.view",
    ],
  },
  {
    id: 2,
    name: "Receptionist",
    description: "Front desk operations",
    userCount: 5,
    permissions: [
      "dashboard.view",
      "rooms.view",
      "bookings.manage",
      "users.view",
      "check-in.manage",
      "check-out.manage",
      "payments.collect",
    ],
  },
  {
    id: 3,
    name: "Accountant",
    description: "Financial management",
    userCount: 2,
    permissions: [
      "dashboard.view",
      "financial-overview.view",
      "invoices.manage",
      "expenses.manage",
      "reports.view",
      "payments.view",
    ],
  },
  {
    id: 4,
    name: "Guest",
    description: "Limited access for hotel guests",
    userCount: 120,
    permissions: ["my-bookings.view", "book-room.manage", "support.access", "profile.manage"],
  },
  {
    id: 5,
    name: "Housekeeper",
    description: "Room maintenance staff",
    userCount: 8,
    permissions: ["dashboard.view", "rooms.view", "room-status.update"],
  },
]

// Sample payment gateways
const paymentGateways = [
  { id: 1, name: "Stripe", enabled: true, fees: "2.9% + $0.30", supportedCurrencies: ["USD", "EUR", "GBP", "GHS"] },
  { id: 2, name: "PayPal", enabled: true, fees: "3.9% + $0.30", supportedCurrencies: ["USD", "EUR", "GBP"] },
  { id: 3, name: "MTN Mobile Money", enabled: true, fees: "1.5%", supportedCurrencies: ["GHS"] },
  { id: 4, name: "Bank Transfer", enabled: true, fees: "0%", supportedCurrencies: ["USD", "EUR", "GBP", "GHS"] },
  { id: 5, name: "Square", enabled: false, fees: "2.6% + $0.10", supportedCurrencies: ["USD"] },
]

// Sample email templates
const emailTemplates = [
  { id: 1, name: "Booking Confirmation", subject: "Your booking at Paddy's View Hotel", lastEdited: "2023-02-15" },
  { id: 2, name: "Check-in Reminder", subject: "Your stay begins tomorrow", lastEdited: "2023-02-20" },
  { id: 3, name: "Check-out Information", subject: "Thank you for staying with us", lastEdited: "2023-03-05" },
  { id: 4, name: "Payment Receipt", subject: "Receipt for your payment", lastEdited: "2023-03-10" },
  { id: 5, name: "Password Reset", subject: "Reset your password", lastEdited: "2023-01-25" },
]

// Sample tax rates
const taxRates = [
  { id: 1, name: "Standard VAT", rate: 12.5, applies: "All bookings", enabled: true },
  { id: 2, name: "Tourism Levy", rate: 1, applies: "All bookings", enabled: true },
  { id: 3, name: "Service Charge", rate: 5, applies: "All bookings", enabled: true },
  { id: 4, name: "Corporate Discount", rate: -10, applies: "Corporate bookings", enabled: true },
]

export default function SettingsPage() {
  const { toast } = useToast()
  const [isEditRoleOpen, setIsEditRoleOpen] = useState(false)
  const [selectedRole, setSelectedRole] = useState<any>(null)
  const [isEditTemplateOpen, setIsEditTemplateOpen] = useState(false)
  const [selectedTemplate, setSelectedTemplate] = useState<any>(null)
  const [isAddTaxOpen, setIsAddTaxOpen] = useState(false)

  // Save settings handler
  const handleSaveSettings = () => {
    toast({
      title: "Settings saved",
      description: "Your changes have been successfully saved.",
    })
  }

  // Edit role handler
  const handleEditRole = (role: any) => {
    setSelectedRole(role)
    setIsEditRoleOpen(true)
  }

  // Edit email template handler
  const handleEditTemplate = (template: any) => {
    setSelectedTemplate(template)
    setIsEditTemplateOpen(true)
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold tracking-tight">Settings</h2>
        <Button onClick={handleSaveSettings}>
          <Save className="mr-2 h-4 w-4" /> Save Changes
        </Button>
      </div>

      <Tabs defaultValue="general" className="space-y-4">
        <TabsList className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-2">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="users">Users & Roles</TabsTrigger>
          <TabsTrigger value="appearance">Appearance</TabsTrigger>
          <TabsTrigger value="payments">Payments</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="business">Business Rules</TabsTrigger>
          <TabsTrigger value="integrations">Integrations</TabsTrigger>
          <TabsTrigger value="system">System</TabsTrigger>
        </TabsList>

        {/* General Settings */}
        <TabsContent value="general">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Building className="mr-2 h-5 w-5" />
                  Hotel Information
                </CardTitle>
                <CardDescription>Basic information about your hotel</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="hotel-name">Hotel Name</Label>
                    <Input id="hotel-name" defaultValue="Paddy's View Hotel" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="legal-name">Legal Business Name</Label>
                    <Input id="legal-name" defaultValue="Paddy's View Hospitality Ltd." />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="hotel-address">Address</Label>
                  <Textarea id="hotel-address" defaultValue="123 Hotel Street, Accra, Ghana" />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="hotel-phone">Phone Number</Label>
                    <Input id="hotel-phone" defaultValue="+233 20 123 4567" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="hotel-email">Email</Label>
                    <Input id="hotel-email" type="email" defaultValue="info@paddysviewhotel.com" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="hotel-website">Website</Label>
                    <Input id="hotel-website" defaultValue="https://paddysviewhotel.com" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="hotel-description">Description</Label>
                  <Textarea
                    id="hotel-description"
                    defaultValue="Paddy's View Hotel is a premier destination offering exceptional service and luxurious accommodations."
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Hotel Logo</Label>
                  <div className="flex items-center gap-4">
                    <div className="h-20 w-20 rounded-md border flex items-center justify-center bg-muted">
                      <Upload className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <Button variant="outline">Upload New Logo</Button>
                  </div>
                  <p className="text-sm text-muted-foreground">Recommended size: 200x200px. Max file size: 2MB.</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Globe className="mr-2 h-5 w-5" />
                  Regional Settings
                </CardTitle>
                <CardDescription>Configure timezone, currency, and language preferences</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="timezone">Timezone</Label>
                    <Select defaultValue="Africa/Accra">
                      <SelectTrigger id="timezone">
                        <SelectValue placeholder="Select timezone" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Africa/Accra">Africa/Accra (GMT+0)</SelectItem>
                        <SelectItem value="Europe/London">Europe/London (GMT+0/+1)</SelectItem>
                        <SelectItem value="America/New_York">America/New_York (GMT-5/-4)</SelectItem>
                        <SelectItem value="Asia/Dubai">Asia/Dubai (GMT+4)</SelectItem>
                        <SelectItem value="Asia/Tokyo">Asia/Tokyo (GMT+9)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="currency">Default Currency</Label>
                    <Select defaultValue="GHS">
                      <SelectTrigger id="currency">
                        <SelectValue placeholder="Select currency" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="GHS">Ghanaian Cedi (GHS)</SelectItem>
                        <SelectItem value="USD">US Dollar (USD)</SelectItem>
                        <SelectItem value="EUR">Euro (EUR)</SelectItem>
                        <SelectItem value="GBP">British Pound (GBP)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="language">Default Language</Label>
                    <Select defaultValue="en">
                      <SelectTrigger id="language">
                        <SelectValue placeholder="Select language" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="en">English</SelectItem>
                        <SelectItem value="fr">French</SelectItem>
                        <SelectItem value="es">Spanish</SelectItem>
                        <SelectItem value="de">German</SelectItem>
                        <SelectItem value="zh">Chinese</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="date-format">Date Format</Label>
                    <Select defaultValue="MM/DD/YYYY">
                      <SelectTrigger id="date-format">
                        <SelectValue placeholder="Select date format" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                        <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                        <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="time-format">Time Format</Label>
                    <Select defaultValue="12h">
                      <SelectTrigger id="time-format">
                        <SelectValue placeholder="Select time format" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="12h">12-hour (AM/PM)</SelectItem>
                        <SelectItem value="24h">24-hour</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="multi-currency">Enable Multi-Currency Support</Label>
                    <Switch id="multi-currency" defaultChecked />
                  </div>
                  <p className="text-sm text-muted-foreground">Allow guests to view and pay in different currencies</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="multi-language">Enable Multi-Language Support</Label>
                    <Switch id="multi-language" defaultChecked />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Allow guests to view the system in different languages
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Key className="mr-2 h-5 w-5" />
                  API Access
                </CardTitle>
                <CardDescription>Manage API keys and access for third-party integrations</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="enable-api">Enable API Access</Label>
                    <Switch id="enable-api" defaultChecked />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Allow external applications to connect to your system via API
                  </p>
                </div>

                <div className="space-y-2">
                  <Label>API Keys</Label>
                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Production API Key</h4>
                        <p className="text-sm text-muted-foreground">Created on Jan 15, 2023</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="outline" size="sm">
                          Reveal
                        </Button>
                        <Button variant="outline" size="sm">
                          Regenerate
                        </Button>
                      </div>
                    </div>
                  </div>
                  <div className="rounded-md border p-4 mt-2">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Test API Key</h4>
                        <p className="text-sm text-muted-foreground">Created on Feb 20, 2023</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="outline" size="sm">
                          Reveal
                        </Button>
                        <Button variant="outline" size="sm">
                          Regenerate
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Webhook Endpoints</Label>
                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Booking Notifications</h4>
                        <p className="text-sm text-muted-foreground">https://example.com/webhooks/bookings</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="outline" size="sm">
                          Edit
                        </Button>
                        <Button variant="outline" size="sm" className="text-red-500">
                          Delete
                        </Button>
                      </div>
                    </div>
                  </div>
                  <Button variant="outline" className="mt-2">
                    <Plus className="mr-2 h-4 w-4" /> Add Webhook Endpoint
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Users & Roles Settings */}
        <TabsContent value="users">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="mr-2 h-5 w-5" />
                  User Roles & Permissions
                </CardTitle>
                <CardDescription>Manage user roles and their permissions</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Role Name</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Users</TableHead>
                      <TableHead>Permissions</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {rolesData.map((role) => (
                      <TableRow key={role.id}>
                        <TableCell className="font-medium">{role.name}</TableCell>
                        <TableCell>{role.description}</TableCell>
                        <TableCell>{role.userCount}</TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            <Badge variant="outline" className="text-xs">
                              {role.permissions.length} permissions
                            </Badge>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm" onClick={() => handleEditRole(role)}>
                            Edit
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                <div className="mt-4">
                  <Button>
                    <Plus className="mr-2 h-4 w-4" /> Add New Role
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Shield className="mr-2 h-5 w-5" />
                  Security Settings
                </CardTitle>
                <CardDescription>Configure password policies and security features</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Password Requirements</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="min-length" defaultChecked />
                      <Label htmlFor="min-length">Minimum 8 characters</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="uppercase" defaultChecked />
                      <Label htmlFor="uppercase">Require uppercase letters</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="lowercase" defaultChecked />
                      <Label htmlFor="lowercase">Require lowercase letters</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="numbers" defaultChecked />
                      <Label htmlFor="numbers">Require numbers</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="special-chars" defaultChecked />
                      <Label htmlFor="special-chars">Require special characters</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="prevent-reuse" defaultChecked />
                      <Label htmlFor="prevent-reuse">Prevent password reuse</Label>
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label>Account Security</Label>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Two-Factor Authentication (2FA)</h4>
                        <p className="text-sm text-muted-foreground">
                          Require staff to use 2FA for additional security
                        </p>
                      </div>
                      <Switch id="require-2fa" defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Account Lockout</h4>
                        <p className="text-sm text-muted-foreground">Lock accounts after 5 failed login attempts</p>
                      </div>
                      <Switch id="account-lockout" defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Password Expiry</h4>
                        <p className="text-sm text-muted-foreground">Require password change every 90 days</p>
                      </div>
                      <Switch id="password-expiry" defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Session Timeout</h4>
                        <p className="text-sm text-muted-foreground">
                          Automatically log out inactive users after 30 minutes
                        </p>
                      </div>
                      <Switch id="session-timeout" defaultChecked />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Appearance Settings */}
        <TabsContent value="appearance">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Palette className="mr-2 h-5 w-5" />
                  Theme Settings
                </CardTitle>
                <CardDescription>Customize the look and feel of your hotel management system</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Color Theme</Label>
                  <div className="grid grid-cols-3 md:grid-cols-6 gap-4">
                    <div className="space-y-2">
                      <div className="h-12 w-full rounded-md bg-blue-600 cursor-pointer ring-2 ring-offset-2 ring-blue-600"></div>
                      <p className="text-xs text-center">Blue</p>
                    </div>
                    <div className="space-y-2">
                      <div className="h-12 w-full rounded-md bg-green-600 cursor-pointer"></div>
                      <p className="text-xs text-center">Green</p>
                    </div>
                    <div className="space-y-2">
                      <div className="h-12 w-full rounded-md bg-purple-600 cursor-pointer"></div>
                      <p className="text-xs text-center">Purple</p>
                    </div>
                    <div className="space-y-2">
                      <div className="h-12 w-full rounded-md bg-red-600 cursor-pointer"></div>
                      <p className="text-xs text-center">Red</p>
                    </div>
                    <div className="space-y-2">
                      <div className="h-12 w-full rounded-md bg-orange-600 cursor-pointer"></div>
                      <p className="text-xs text-center">Orange</p>
                    </div>
                    <div className="space-y-2">
                      <div className="h-12 w-full rounded-md bg-gray-600 cursor-pointer"></div>
                      <p className="text-xs text-center">Gray</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Theme Mode</Label>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <div className="h-20 w-full rounded-md bg-white border cursor-pointer ring-2 ring-offset-2 ring-primary">
                        <div className="h-4 w-full bg-gray-200 rounded-t-md"></div>
                        <div className="p-2">
                          <div className="h-2 w-3/4 bg-gray-200 rounded-full mb-1"></div>
                          <div className="h-2 w-1/2 bg-gray-200 rounded-full"></div>
                        </div>
                      </div>
                      <p className="text-xs text-center">Light</p>
                    </div>
                    <div className="space-y-2">
                      <div className="h-20 w-full rounded-md bg-gray-900 border border-gray-700 cursor-pointer">
                        <div className="h-4 w-full bg-gray-800 rounded-t-md"></div>
                        <div className="p-2">
                          <div className="h-2 w-3/4 bg-gray-700 rounded-full mb-1"></div>
                          <div className="h-2 w-1/2 bg-gray-700 rounded-full"></div>
                        </div>
                      </div>
                      <p className="text-xs text-center">Dark</p>
                    </div>
                    <div className="space-y-2">
                      <div className="h-20 w-full rounded-md bg-gradient-to-r from-white to-gray-900 border cursor-pointer">
                        <div className="h-4 w-full bg-gradient-to-r from-gray-200 to-gray-800 rounded-t-md"></div>
                        <div className="p-2 flex justify-between">
                          <div className="w-1/2">
                            <div className="h-2 w-3/4 bg-gray-200 rounded-full mb-1"></div>
                            <div className="h-2 w-1/2 bg-gray-200 rounded-full"></div>
                          </div>
                          <div className="w-1/2 flex justify-end">
                            <div className="w-3/4">
                              <div className="h-2 w-3/4 bg-gray-700 rounded-full mb-1"></div>
                              <div className="h-2 w-1/2 bg-gray-700 rounded-full"></div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <p className="text-xs text-center">System</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Layout Options</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="compact-sidebar" />
                      <Label htmlFor="compact-sidebar">Compact Sidebar</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="fixed-header" defaultChecked />
                      <Label htmlFor="fixed-header">Fixed Header</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="boxed-layout" />
                      <Label htmlFor="boxed-layout">Boxed Layout</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="fluid-layout" defaultChecked />
                      <Label htmlFor="fluid-layout">Fluid Layout</Label>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Custom CSS</Label>
                  <Textarea placeholder="Enter custom CSS rules here..." className="font-mono text-sm" rows={5} />
                  <p className="text-sm text-muted-foreground">Advanced: Add custom CSS to override default styles</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Building className="mr-2 h-5 w-5" />
                  Branding
                </CardTitle>
                <CardDescription>Customize branding elements across the system</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Replace the logo upload sections in the Branding card with our new component */}
                {/* Find the section with "Logo (Light Mode)" and "Logo (Dark Mode)" and replace with: */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FileUpload
                    id="logo-light"
                    label="Logo (Light Mode)"
                    description="Upload your hotel logo for light mode. Recommended size: 200x60px."
                    accept="image/png,image/jpeg,image/svg+xml"
                    maxSize={1}
                    defaultPreview="/placeholder.svg?height=60&width=200"
                  />

                  <FileUpload
                    id="logo-dark"
                    label="Logo (Dark Mode)"
                    description="Upload your hotel logo for dark mode. Recommended size: 200x60px."
                    accept="image/png,image/jpeg,image/svg+xml"
                    maxSize={1}
                    defaultPreview="/placeholder.svg?height=60&width=200"
                  />
                </div>

                <div className="space-y-2 mt-4">
                  <FileUpload
                    id="favicon"
                    label="Favicon"
                    description="Upload your website favicon. Recommended size: 32x32px or 64x64px."
                    accept="image/png,image/x-icon,image/svg+xml"
                    maxSize={0.5}
                    defaultPreview="/placeholder.svg?height=32&width=32"
                  />
                </div>

                {/* Also replace the login background image upload section with: */}
                <div className="space-y-2 mt-4">
                  <FileUpload
                    id="login-background"
                    label="Login Page Background"
                    description="Upload a background image for the login page. Recommended size: 1920x1080px."
                    accept="image/png,image/jpeg"
                    maxSize={5}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email-footer">Email Footer Text</Label>
                  <Textarea id="email-footer" defaultValue="© 2023 Paddy's View Hotel. All rights reserved." rows={2} />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Payments Settings */}
        <TabsContent value="payments">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <CreditCard className="mr-2 h-5 w-5" />
                  Payment Gateways
                </CardTitle>
                <CardDescription>Configure payment methods and gateways</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Gateway</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Fees</TableHead>
                      <TableHead>Supported Currencies</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paymentGateways.map((gateway) => (
                      <TableRow key={gateway.id}>
                        <TableCell className="font-medium">{gateway.name}</TableCell>
                        <TableCell>
                          {gateway.enabled ? (
                            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                              Enabled
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
                              Disabled
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>{gateway.fees}</TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {gateway.supportedCurrencies.map((currency) => (
                              <Badge key={currency} variant="secondary" className="text-xs">
                                {currency}
                              </Badge>
                            ))}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">
                            Configure
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                <div className="mt-4">
                  <Button>
                    <Plus className="mr-2 h-4 w-4" /> Add Payment Gateway
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Percent className="mr-2 h-5 w-5" />
                  Tax Settings
                </CardTitle>
                <CardDescription>Configure tax rates and rules</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Rate (%)</TableHead>
                      <TableHead>Applies To</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {taxRates.map((tax) => (
                      <TableRow key={tax.id}>
                        <TableCell className="font-medium">{tax.name}</TableCell>
                        <TableCell>{tax.rate}%</TableCell>
                        <TableCell>{tax.applies}</TableCell>
                        <TableCell>
                          {tax.enabled ? (
                            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                              Enabled
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
                              Disabled
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">
                            Edit
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                <div className="mt-4">
                  <Button onClick={() => setIsAddTaxOpen(true)}>
                    <Plus className="mr-2 h-4 w-4" /> Add Tax Rate
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FileText className="mr-2 h-5 w-5" />
                  Invoice Settings
                </CardTitle>
                <CardDescription>Configure invoice numbering and appearance</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="invoice-prefix">Invoice Number Prefix</Label>
                    <Input id="invoice-prefix" defaultValue="INV-" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="next-invoice-number">Next Invoice Number</Label>
                    <Input id="next-invoice-number" defaultValue="1009" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="invoice-notes">Default Invoice Notes</Label>
                  <Textarea
                    id="invoice-notes"
                    defaultValue="Thank you for choosing Paddy's View Hotel. Payment is due upon receipt of this invoice."
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="invoice-due-days">Default Payment Terms</Label>
                  <Select defaultValue="0">
                    <SelectTrigger id="invoice-due-days">
                      <SelectValue placeholder="Select payment terms" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0">Due on receipt</SelectItem>
                      <SelectItem value="7">Net 7 days</SelectItem>
                      <SelectItem value="14">Net 14 days</SelectItem>
                      <SelectItem value="30">Net 30 days</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="auto-send-invoices">Automatically Send Invoices</Label>
                    <Switch id="auto-send-invoices" defaultChecked />
                  </div>
                  <p className="text-sm text-muted-foreground">Automatically email invoices to guests when created</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="invoice-reminders">Send Payment Reminders</Label>
                    <Switch id="invoice-reminders" defaultChecked />
                  </div>
                  <p className="text-sm text-muted-foreground">Send automatic reminders for overdue invoices</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Notifications Settings */}
        <TabsContent value="notifications">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Mail className="mr-2 h-5 w-5" />
                  Email Settings
                </CardTitle>
                <CardDescription>Configure email notifications and templates</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="email-from">From Email Address</Label>
                    <Input id="email-from" defaultValue="reservations@paddysviewhotel.com" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email-name">From Name</Label>
                    <Input id="email-name" defaultValue="Paddy's View Hotel" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Email Provider</Label>
                  <Select defaultValue="smtp">
                    <SelectTrigger>
                      <SelectValue placeholder="Select email provider" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="smtp">SMTP Server</SelectItem>
                      <SelectItem value="sendgrid">SendGrid</SelectItem>
                      <SelectItem value="mailchimp">Mailchimp</SelectItem>
                      <SelectItem value="ses">Amazon SES</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>SMTP Configuration</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="smtp-host">SMTP Host</Label>
                      <Input id="smtp-host" defaultValue="smtp.example.com" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="smtp-port">SMTP Port</Label>
                      <Input id="smtp-port" defaultValue="587" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="smtp-username">SMTP Username</Label>
                      <Input id="smtp-username" defaultValue="user@example.com" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="smtp-password">SMTP Password</Label>
                      <Input id="smtp-password" type="password" defaultValue="••••••••••••" />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Email Templates</Label>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Template Name</TableHead>
                        <TableHead>Subject</TableHead>
                        <TableHead>Last Edited</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {emailTemplates.map((template) => (
                        <TableRow key={template.id}>
                          <TableCell className="font-medium">{template.name}</TableCell>
                          <TableCell>{template.subject}</TableCell>
                          <TableCell>{template.lastEdited}</TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm" onClick={() => handleEditTemplate(template)}>
                              Edit
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="test-email">Send Test Email</Label>
                    <div className="flex items-center gap-2">
                      <Input id="test-email" placeholder="Enter email address" className="w-64" />
                      <Button>Send Test</Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Bell className="mr-2 h-5 w-5" />
                  System Notifications
                </CardTitle>
                <CardDescription>Configure in-app notifications and alerts</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Staff Notifications</Label>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">New Booking Notifications</h4>
                        <p className="text-sm text-muted-foreground">Notify staff when a new booking is created</p>
                      </div>
                      <Switch id="new-booking-notify" defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Check-in Reminders</h4>
                        <p className="text-sm text-muted-foreground">Notify staff about upcoming check-ins</p>
                      </div>
                      <Switch id="checkin-notify" defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Payment Notifications</h4>
                        <p className="text-sm text-muted-foreground">Notify staff when payments are received</p>
                      </div>
                      <Switch id="payment-notify" defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Low Inventory Alerts</h4>
                        <p className="text-sm text-muted-foreground">
                          Notify staff when inventory items are running low
                        </p>
                      </div>
                      <Switch id="inventory-notify" defaultChecked />
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label>Guest Notifications</Label>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Booking Confirmation</h4>
                        <p className="text-sm text-muted-foreground">Send confirmation email when booking is created</p>
                      </div>
                      <Switch id="booking-confirm" defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Check-in Reminder</h4>
                        <p className="text-sm text-muted-foreground">Send reminder email before guest's arrival</p>
                      </div>
                      <Switch id="checkin-remind" defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Payment Receipt</h4>
                        <p className="text-sm text-muted-foreground">Send receipt email when payment is processed</p>
                      </div>
                      <Switch id="payment-receipt" defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Post-Stay Survey</h4>
                        <p className="text-sm text-muted-foreground">Send feedback request after guest's stay</p>
                      </div>
                      <Switch id="post-stay" defaultChecked />
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label>SMS Notifications</Label>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Enable SMS Notifications</h4>
                        <p className="text-sm text-muted-foreground">Send notifications via SMS to guests</p>
                      </div>
                      <Switch id="enable-sms" />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="sms-provider">SMS Provider</Label>
                        <Select defaultValue="twilio">
                          <SelectTrigger id="sms-provider">
                            <SelectValue placeholder="Select SMS provider" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="twilio">Twilio</SelectItem>
                            <SelectItem value="vonage">Vonage</SelectItem>
                            <SelectItem value="africastalking">Africa's Talking</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="sms-from">Sender ID</Label>
                        <Input id="sms-from" defaultValue="PaddysView" />
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Business Rules Settings */}
        <TabsContent value="business">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="mr-2 h-5 w-5" />
                  Booking Policies
                </CardTitle>
                <CardDescription>Configure booking rules and policies</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="min-stay">Minimum Stay (Nights)</Label>
                    <Input id="min-stay" type="number" defaultValue="1" min="1" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="max-stay">Maximum Stay (Nights)</Label>
                    <Input id="max-stay" type="number" defaultValue="30" min="1" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="advance-booking">Maximum Advance Booking (Days)</Label>
                    <Input id="advance-booking" type="number" defaultValue="365" min="1" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="checkin-time">Default Check-in Time</Label>
                    <Input id="checkin-time" type="time" defaultValue="14:00" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="checkout-time">Default Check-out Time</Label>
                    <Input id="checkout-time" type="time" defaultValue="12:00" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cutoff-time">Booking Cutoff Time</Label>
                    <Input id="cutoff-time" type="time" defaultValue="18:00" />
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label>Cancellation Policy</Label>
                  <Select defaultValue="24h">
                    <SelectTrigger>
                      <SelectValue placeholder="Select cancellation policy" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="flexible">Flexible (Same day)</SelectItem>
                      <SelectItem value="24h">Moderate (24 hours)</SelectItem>
                      <SelectItem value="48h">Strict (48 hours)</SelectItem>
                      <SelectItem value="7d">Super Strict (7 days)</SelectItem>
                      <SelectItem value="non-refundable">Non-refundable</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="cancellation-fee">Cancellation Fee (%)</Label>
                  <Input id="cancellation-fee" type="number" defaultValue="0" min="0" max="100" />
                  <p className="text-sm text-muted-foreground">
                    Percentage of booking total to charge for late cancellations
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="no-show-charge">Charge for No-Shows</Label>
                    <Switch id="no-show-charge" defaultChecked />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Charge the first night's rate for guests who don't arrive
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="require-deposit">Require Deposit</Label>
                    <Switch id="require-deposit" defaultChecked />
                  </div>
                  <p className="text-sm text-muted-foreground">Require a deposit to confirm bookings</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="deposit-amount">Deposit Amount (%)</Label>
                  <Input id="deposit-amount" type="number" defaultValue="20" min="0" max="100" />
                  <p className="text-sm text-muted-foreground">Percentage of booking total required as deposit</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Percent className="mr-2 h-5 w-5" />
                  Pricing Rules
                </CardTitle>
                <CardDescription>Configure pricing strategies and discounts</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="seasonal-pricing">Enable Seasonal Pricing</Label>
                    <Switch id="seasonal-pricing" defaultChecked />
                  </div>
                  <p className="text-sm text-muted-foreground">Adjust room rates based on seasons and demand</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="weekend-rates">Different Weekend Rates</Label>
                    <Switch id="weekend-rates" defaultChecked />
                  </div>
                  <p className="text-sm text-muted-foreground">Apply different rates for weekend stays</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="weekend-markup">Weekend Rate Adjustment (%)</Label>
                  <Input id="weekend-markup" type="number" defaultValue="15" min="-100" />
                  <p className="text-sm text-muted-foreground">
                    Percentage to adjust rates on weekends (positive for increase, negative for discount)
                  </p>
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label>Automatic Discounts</Label>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Long Stay Discount</h4>
                        <p className="text-sm text-muted-foreground">Apply discount for stays longer than 7 nights</p>
                      </div>
                      <Switch id="long-stay-discount" defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Early Bird Discount</h4>
                        <p className="text-sm text-muted-foreground">
                          Apply discount for bookings made 30+ days in advance
                        </p>
                      </div>
                      <Switch id="early-bird-discount" defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Last Minute Discount</h4>
                        <p className="text-sm text-muted-foreground">
                          Apply discount for bookings made within 48 hours of arrival
                        </p>
                      </div>
                      <Switch id="last-minute-discount" />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Corporate Rate</h4>
                        <p className="text-sm text-muted-foreground">Apply special rates for corporate clients</p>
                      </div>
                      <Switch id="corporate-rate" defaultChecked />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Discount Amounts</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="long-stay-amount">Long Stay Discount (%)</Label>
                      <Input id="long-stay-amount" type="number" defaultValue="10" min="0" max="100" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="early-bird-amount">Early Bird Discount (%)</Label>
                      <Input id="early-bird-amount" type="number" defaultValue="15" min="0" max="100" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="last-minute-amount">Last Minute Discount (%)</Label>
                      <Input id="last-minute-amount" type="number" defaultValue="20" min="0" max="100" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="corporate-amount">Corporate Discount (%)</Label>
                      <Input id="corporate-amount" type="number" defaultValue="15" min="0" max="100" />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Promotional Codes</Label>
                  <Button variant="outline">
                    <Plus className="mr-2 h-4 w-4" /> Add Promo Code
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="mr-2 h-5 w-5" />
                  Guest Policies
                </CardTitle>
                <CardDescription>Configure policies for guests</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="max-adults">Maximum Adults per Room</Label>
                    <Input id="max-adults" type="number" defaultValue="4" min="1" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="max-children">Maximum Children per Room</Label>
                    <Input id="max-children" type="number" defaultValue="3" min="0" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="max-pets">Maximum Pets per Room</Label>
                    <Input id="max-pets" type="number" defaultValue="2" min="0" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="extra-person-fee">Extra Person Fee</Label>
                    <Input id="extra-person-fee" type="number" defaultValue="25" min="0" />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="allow-pets">Allow Pets</Label>
                    <Switch id="allow-pets" defaultChecked />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Allow guests to bring pets (additional fees may apply)
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="pet-fee">Pet Fee</Label>
                  <Input id="pet-fee" type="number" defaultValue="30" min="0" />
                  <p className="text-sm text-muted-foreground">Fee per pet per stay</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="smoking-allowed">Smoking Allowed</Label>
                    <Switch id="smoking-allowed" />
                  </div>
                  <p className="text-sm text-muted-foreground">Allow smoking in designated rooms</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="id-requirements">ID Requirements</Label>
                  <Select defaultValue="passport">
                    <SelectTrigger id="id-requirements">
                      <SelectValue placeholder="Select ID requirements" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="any">Any valid ID</SelectItem>
                      <SelectItem value="passport">Passport required for international guests</SelectItem>
                      <SelectItem value="government">Government-issued ID only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="guest-terms">Guest Terms & Conditions</Label>
                  <Textarea
                    id="guest-terms"
                    rows={5}
                    defaultValue="By making a reservation, guests agree to abide by all hotel policies. Check-in time is 2:00 PM and check-out time is 12:00 PM. Early check-in and late check-out may be available for an additional fee, subject to availability."
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Integrations Settings */}
        <TabsContent value="integrations">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Globe className="mr-2 h-5 w-5" />
                  Channel Manager
                </CardTitle>
                <CardDescription>Connect to online travel agencies and booking platforms</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="enable-channel-manager">Enable Channel Manager</Label>
                    <Switch id="enable-channel-manager" defaultChecked />
                  </div>
                  <p className="text-sm text-muted-foreground">Sync inventory and rates with online booking channels</p>
                </div>

                <div className="space-y-2">
                  <Label>Connected Channels</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center justify-between rounded-lg border p-4">
                      <div className="flex items-center space-x-4">
                        <div className="h-10 w-10 rounded-md bg-blue-100 flex items-center justify-center">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="24"
                            height="24"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="h-6 w-6 text-blue-600"
                          >
                            <path d="M2 20h20"></path>
                            <path d="M5 4h14a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1Z"></path>
                          </svg>
                        </div>
                        <div>
                          <h4 className="font-medium">Booking.com</h4>
                          <p className="text-sm text-muted-foreground">Connected on Jan 15, 2023</p>
                        </div>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <div className="flex items-center justify-between rounded-lg border p-4">
                      <div className="flex items-center space-x-4">
                        <div className="h-10 w-10 rounded-md bg-yellow-100 flex items-center justify-center">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="24"
                            height="24"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="h-6 w-6 text-yellow-600"
                          >
                            <path d="M12 2H2v10h10V2Z"></path>
                            <path d="M22 12h-10v10h10V12Z"></path>
                            <path d="M12 12H2v10h10V12Z"></path>
                            <path d="M22 2h-10v10h10V2Z"></path>
                          </svg>
                        </div>
                        <div>
                          <h4 className="font-medium">Expedia</h4>
                          <p className="text-sm text-muted-foreground">Connected on Feb 10, 2023</p>
                        </div>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <div className="flex items-center justify-between rounded-lg border p-4">
                      <div className="flex items-center space-x-4">
                        <div className="h-10 w-10 rounded-md bg-red-100 flex items-center justify-center">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="24"
                            height="24"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="h-6 w-6 text-red-600"
                          >
                            <path d="M12 2a10 10 0 1 0 10 10 10 10 0 0 0-10-10Z"></path>
                            <path d="m4.9 4.9 14.2 14.2"></path>
                          </svg>
                        </div>
                        <div>
                          <h4 className="font-medium">Airbnb</h4>
                          <p className="text-sm text-muted-foreground">Not connected</p>
                        </div>
                      </div>
                      <Switch />
                    </div>

                    <div className="flex items-center justify-between rounded-lg border p-4">
                      <div className="flex items-center space-x-4">
                        <div className="h-10 w-10 rounded-md bg-green-100 flex items-center justify-center">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="24"
                            height="24"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="h-6 w-6 text-green-600"
                          >
                            <path d="M12 2a10 10 0 1 0 10 10 10 10 0 0 0-10-10Z"></path>
                            <path d="M12 8v8"></path>
                            <path d="M8 12h8"></path>
                          </svg>
                        </div>
                        <div>
                          <h4 className="font-medium">TripAdvisor</h4>
                          <p className="text-sm text-muted-foreground">Connected on Mar 5, 2023</p>
                        </div>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </div>
                  <Button variant="outline" className="mt-2">
                    <Plus className="mr-2 h-4 w-4" /> Connect New Channel
                  </Button>
                </div>

                <div className="space-y-2">
                  <Label>Rate Parity Settings</Label>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Enforce Rate Parity</h4>
                        <p className="text-sm text-muted-foreground">Maintain the same rates across all channels</p>
                      </div>
                      <Switch id="rate-parity" defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Channel-Specific Pricing</h4>
                        <p className="text-sm text-muted-foreground">Allow different rates for specific channels</p>
                      </div>
                      <Switch id="channel-pricing" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MessageSquare className="mr-2 h-5 w-5" />
                  Communication Services
                </CardTitle>
                <CardDescription>Configure SMS, WhatsApp, and other communication services</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>SMS Provider</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="sms-provider">Provider</Label>
                      <Select defaultValue="twilio">
                        <SelectTrigger id="sms-provider">
                          <SelectValue placeholder="Select SMS provider" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="twilio">Twilio</SelectItem>
                          <SelectItem value="vonage">Vonage</SelectItem>
                          <SelectItem value="africastalking">Africa's Talking</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="sms-sender">Sender ID</Label>
                      <Input id="sms-sender" defaultValue="PaddysView" />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="sms-api-key">API Key</Label>
                      <Input id="sms-api-key" type="password" defaultValue="••••••••••••••••" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="sms-api-secret">API Secret</Label>
                      <Input id="sms-api-secret" type="password" defaultValue="••••••••••••••••" />
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="enable-whatsapp">Enable WhatsApp Integration</Label>
                    <Switch id="enable-whatsapp" />
                  </div>
                  <p className="text-sm text-muted-foreground">Send booking confirmations and updates via WhatsApp</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="enable-live-chat">Enable Live Chat</Label>
                    <Switch id="enable-live-chat" defaultChecked />
                  </div>
                  <p className="text-sm text-muted-foreground">Provide live chat support for website visitors</p>
                </div>

                <div className="space-y-2">
                  <Label>Live Chat Provider</Label>
                  <Select defaultValue="intercom">
                    <SelectTrigger>
                      <SelectValue placeholder="Select live chat provider" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="intercom">Intercom</SelectItem>
                      <SelectItem value="zendesk">Zendesk Chat</SelectItem>
                      <SelectItem value="tawk">Tawk.to</SelectItem>
                      <SelectItem value="crisp">Crisp</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Smartphone className="mr-2 h-5 w-5" />
                  Mobile App Settings
                </CardTitle>
                <CardDescription>Configure settings for the hotel mobile app</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="enable-mobile-app">Enable Mobile App</Label>
                    <Switch id="enable-mobile-app" defaultChecked />
                  </div>
                  <p className="text-sm text-muted-foreground">Allow guests to use the hotel mobile app</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="mobile-check-in">Enable Mobile Check-in</Label>
                    <Switch id="mobile-check-in" defaultChecked />
                  </div>
                  <p className="text-sm text-muted-foreground">Allow guests to check in via the mobile app</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="digital-key">Enable Digital Room Key</Label>
                    <Switch id="digital-key" />
                  </div>
                  <p className="text-sm text-muted-foreground">Allow guests to use their phone as a room key</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="push-notifications">Enable Push Notifications</Label>
                    <Switch id="push-notifications" defaultChecked />
                  </div>
                  <p className="text-sm text-muted-foreground">Send push notifications to guests via the mobile app</p>
                </div>

                <div className="space-y-2">
                  <Label>Mobile App Features</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="feature-booking" defaultChecked />
                      <Label htmlFor="feature-booking">Booking Management</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="feature-chat" defaultChecked />
                      <Label htmlFor="feature-chat">Live Chat Support</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="feature-services" defaultChecked />
                      <Label htmlFor="feature-services">Room Service Orders</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="feature-feedback" defaultChecked />
                      <Label htmlFor="feature-feedback">Feedback & Reviews</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="feature-local" defaultChecked />
                      <Label htmlFor="feature-local">Local Attractions</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="feature-loyalty" defaultChecked />
                      <Label htmlFor="feature-loyalty">Loyalty Program</Label>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* System Settings */}
        <TabsContent value="system">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Database className="mr-2 h-5 w-5" />
                  Database & Backup
                </CardTitle>
                <CardDescription>Configure database settings and backup options</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Database Information</Label>
                  <div className="rounded-md border p-4 bg-muted/50">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm font-medium">Database Type</p>
                        <p className="text-sm text-muted-foreground">PostgreSQL</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium">Version</p>
                        <p className="text-sm text-muted-foreground">14.5</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium">Size</p>
                        <p className="text-sm text-muted-foreground">1.2 GB</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium">Last Backup</p>
                        <p className="text-sm text-muted-foreground">Today, 03:00 AM</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Automatic Backups</Label>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Enable Automatic Backups</h4>
                        <p className="text-sm text-muted-foreground">Automatically backup the database on a schedule</p>
                      </div>
                      <Switch id="auto-backup" defaultChecked />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="backup-frequency">Backup Frequency</Label>
                        <Select defaultValue="daily">
                          <SelectTrigger id="backup-frequency">
                            <SelectValue placeholder="Select frequency" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="hourly">Hourly</SelectItem>
                            <SelectItem value="daily">Daily</SelectItem>
                            <SelectItem value="weekly">Weekly</SelectItem>
                            <SelectItem value="monthly">Monthly</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="backup-time">Backup Time</Label>
                        <Input id="backup-time" type="time" defaultValue="03:00" />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="backup-retention">Backup Retention (Days)</Label>
                      <Input id="backup-retention" type="number" defaultValue="30" min="1" />
                      <p className="text-sm text-muted-foreground">
                        Number of days to keep backups before automatic deletion
                      </p>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Manual Backup</Label>
                  <Button>
                    <Database className="mr-2 h-4 w-4" /> Create Backup Now
                  </Button>
                </div>

                <div className="space-y-2">
                  <Label>Recent Backups</Label>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date & Time</TableHead>
                        <TableHead>Size</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <TableRow>
                        <TableCell>2023-03-22 03:00 AM</TableCell>
                        <TableCell>1.2 GB</TableCell>
                        <TableCell>Automatic</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">
                            Download
                          </Button>
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>2023-03-21 03:00 AM</TableCell>
                        <TableCell>1.2 GB</TableCell>
                        <TableCell>Automatic</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">
                            Download
                          </Button>
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>2023-03-20 03:00 AM</TableCell>
                        <TableCell>1.1 GB</TableCell>
                        <TableCell>Automatic</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">
                            Download
                          </Button>
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Wrench className="mr-2 h-5 w-5" />
                  Maintenance
                </CardTitle>
                <CardDescription>System maintenance and optimization settings</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="maintenance-mode">Maintenance Mode</Label>
                    <Switch id="maintenance-mode" />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Put the system in maintenance mode (only administrators can access)
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="maintenance-message">Maintenance Message</Label>
                  <Textarea
                    id="maintenance-message"
                    defaultValue="Our system is currently undergoing scheduled maintenance. We'll be back shortly. Thank you for your patience."
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label>System Cleanup</Label>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Automatic Log Cleanup</h4>
                        <p className="text-sm text-muted-foreground">Automatically clean up old system logs</p>
                      </div>
                      <Switch id="log-cleanup" defaultChecked />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="log-retention">Log Retention (Days)</Label>
                      <Input id="log-retention" type="number" defaultValue="90" min="1" />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Automatic Cache Cleanup</h4>
                        <p className="text-sm text-muted-foreground">Automatically clear system cache periodically</p>
                      </div>
                      <Switch id="cache-cleanup" defaultChecked />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Manual Cleanup</Label>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <Button variant="outline">Clear Cache</Button>
                    <Button variant="outline">Clear Logs</Button>
                    <Button variant="outline">Optimize Database</Button>
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label>System Information</Label>
                  <div className="rounded-md border p-4 bg-muted/50">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm font-medium">System Version</p>
                        <p className="text-sm text-muted-foreground">v2.5.3</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium">Last Updated</p>
                        <p className="text-sm text-muted-foreground">2023-03-15</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium">PHP Version</p>
                        <p className="text-sm text-muted-foreground">8.1.12</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium">Server</p>
                        <p className="text-sm text-muted-foreground">Nginx 1.21.6</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>System Updates</Label>
                  <div className="rounded-md border p-4 bg-green-50 dark:bg-green-950 text-green-700 dark:text-green-300">
                    <div className="flex items-center">
                      <Check className="h-5 w-5 mr-2" />
                      <p className="text-sm font-medium">Your system is up to date</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FileText className="mr-2 h-5 w-5" />
                  System Logs
                </CardTitle>
                <CardDescription>View and manage system logs</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Log Level</Label>
                  <Select defaultValue="error">
                    <SelectTrigger>
                      <SelectValue placeholder="Select log level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="debug">Debug (All Messages)</SelectItem>
                      <SelectItem value="info">Info (Informational Messages)</SelectItem>
                      <SelectItem value="warning">Warning (Warning Messages)</SelectItem>
                      <SelectItem value="error">Error (Error Messages Only)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Recent Logs</Label>
                  <div className="rounded-md border bg-muted p-4 font-mono text-sm h-60 overflow-auto">
                    <p className="text-red-500">
                      [2023-03-22 10:15:30] ERROR: Failed login attempt for user admin@paddysview.com from IP
                      192.168.1.105
                    </p>
                    <p className="text-amber-500">
                      [2023-03-22 09:45:12] WARNING: High server load detected (CPU: 85%)
                    </p>
                    <p className="text-green-500">[2023-03-22 09:30:45] INFO: Backup completed successfully</p>
                    <p className="text-blue-500">[2023-03-22 09:00:00] DEBUG: Scheduled tasks started</p>
                    <p className="text-red-500">[2023-03-21 22:10:18] ERROR: Database connection timeout</p>
                    <p className="text-amber-500">[2023-03-21 18:22:05] WARNING: Low disk space (15% remaining)</p>
                    <p className="text-green-500">
                      [2023-03-21 15:45:30] INFO: User john.doe@example.com updated profile
                    </p>
                    <p className="text-blue-500">[2023-03-21 14:30:22] DEBUG: Cache cleared automatically</p>
                    <p className="text-green-500">[2023-03-21 12:15:10] INFO: New booking created (ID: B-1009)</p>
                    <p className="text-green-500">
                      [2023-03-21 10:05:45] INFO: Payment processed successfully (ID: P-2345)
                    </p>
                  </div>
                </div>

                <div className="flex justify-between">
                  <Button variant="outline">
                    <FileText className="mr-2 h-4 w-4" /> Download Logs
                  </Button>
                  <Button variant="outline" className="text-red-500">
                    <Trash className="mr-2 h-4 w-4" /> Clear Logs
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <HelpCircle className="mr-2 h-5 w-5" />
                  Support & Troubleshooting
                </CardTitle>
                <CardDescription>Access support resources and troubleshooting tools</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>System Diagnostics</Label>
                  <Button variant="outline" className="w-full sm:w-auto">
                    Run System Diagnostics
                  </Button>
                  <p className="text-sm text-muted-foreground">
                    Run a comprehensive check of your system to identify potential issues
                  </p>
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label>Support Resources</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="rounded-md border p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <FileText className="h-5 w-5 text-primary" />
                        <h4 className="font-medium">Documentation</h4>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">Access comprehensive system documentation</p>
                      <Button variant="outline" size="sm">
                        View Documentation
                      </Button>
                    </div>

                    <div className="rounded-md border p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <MessageSquare className="h-5 w-5 text-primary" />
                        <h4 className="font-medium">Contact Support</h4>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">Get help from our support team</p>
                      <Button variant="outline" size="sm">
                        Contact Support
                      </Button>
                    </div>

                    <div className="rounded-md border p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Info className="h-5 w-5 text-primary" />
                        <h4 className="font-medium">Knowledge Base</h4>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">Browse articles and tutorials</p>
                      <Button variant="outline" size="sm">
                        View Articles
                      </Button>
                    </div>

                    <div className="rounded-md border p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <AlertCircle className="h-5 w-5 text-primary" />
                        <h4 className="font-medium">Report an Issue</h4>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">Submit a bug report or feature request</p>
                      <Button variant="outline" size="sm">
                        Report Issue
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Edit Role Dialog */}
      {selectedRole && (
        <Dialog open={isEditRoleOpen} onOpenChange={setIsEditRoleOpen}>
          <DialogContent className="sm:max-w-[700px]">
            <DialogHeader>
              <DialogTitle>Edit Role: {selectedRole.name}</DialogTitle>
              <DialogDescription>Modify role details and permissions</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="role-name">Role Name</Label>
                  <Input id="role-name" defaultValue={selectedRole.name} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="role-description">Description</Label>
                  <Input id="role-description" defaultValue={selectedRole.description} />
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Permissions</Label>
                <TooltipProvider>
                  <Accordion type="multiple" defaultValue={["dashboard", "rooms", "bookings", "users", "payments"]}>
                    <AccordionItem value="dashboard">
                      <AccordionTrigger>Dashboard</AccordionTrigger>
                      <AccordionContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="perm-dashboard-view"
                              defaultChecked={selectedRole.permissions.includes("dashboard.view")}
                            />
                            <Label htmlFor="perm-dashboard-view">View Dashboard</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="perm-dashboard-analytics"
                              defaultChecked={selectedRole.permissions.includes("dashboard.analytics")}
                            />
                            <Label htmlFor="perm-dashboard-analytics">View Analytics</Label>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="rooms">
                      <AccordionTrigger>Rooms</AccordionTrigger>
                      <AccordionContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="perm-rooms-view"
                              defaultChecked={selectedRole.permissions.includes("rooms.view")}
                            />
                            <Label htmlFor="perm-rooms-view">View Rooms</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="perm-rooms-manage"
                              defaultChecked={selectedRole.permissions.includes("rooms.manage")}
                            />
                            <Label htmlFor="perm-rooms-manage">Manage Rooms</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="perm-rooms-types"
                              defaultChecked={selectedRole.permissions.includes("rooms.types")}
                            />
                            <Label htmlFor="perm-rooms-types">Manage Room Types</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="perm-rooms-pricing"
                              defaultChecked={selectedRole.permissions.includes("rooms.pricing")}
                            />
                            <Label htmlFor="perm-rooms-pricing">Manage Room Pricing</Label>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="bookings">
                      <AccordionTrigger>Bookings</AccordionTrigger>
                      <AccordionContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="perm-bookings-view"
                              defaultChecked={selectedRole.permissions.includes("bookings.view")}
                            />
                            <Label htmlFor="perm-bookings-view">View Bookings</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="perm-bookings-manage"
                              defaultChecked={selectedRole.permissions.includes("bookings.manage")}
                            />
                            <Label htmlFor="perm-bookings-manage">Manage Bookings</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="perm-bookings-create"
                              defaultChecked={selectedRole.permissions.includes("bookings.create")}
                            />
                            <Label htmlFor="perm-bookings-create">Create Bookings</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="perm-bookings-cancel"
                              defaultChecked={selectedRole.permissions.includes("bookings.cancel")}
                            />
                            <Label htmlFor="perm-bookings-cancel">Cancel Bookings</Label>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="users">
                      <AccordionTrigger>Users</AccordionTrigger>
                      <AccordionContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="perm-users-view"
                              defaultChecked={selectedRole.permissions.includes("users.view")}
                            />
                            <Label htmlFor="perm-users-view">View Users</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="perm-users-manage"
                              defaultChecked={selectedRole.permissions.includes("users.manage")}
                            />
                            <Label htmlFor="perm-users-manage">Manage Users</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="perm-users-create"
                              defaultChecked={selectedRole.permissions.includes("users.create")}
                            />
                            <Label htmlFor="perm-users-create">Create Users</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="perm-users-delete"
                              defaultChecked={selectedRole.permissions.includes("users.delete")}
                            />
                            <Label htmlFor="perm-users-delete">Delete Users</Label>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="payments">
                      <AccordionTrigger>Payments</AccordionTrigger>
                      <AccordionContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="perm-payments-view"
                              defaultChecked={selectedRole.permissions.includes("payments.view")}
                            />
                            <Label htmlFor="perm-payments-view">View Payments</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="perm-payments-manage"
                              defaultChecked={selectedRole.permissions.includes("payments.manage")}
                            />
                            <Label htmlFor="perm-payments-manage">Manage Payments</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="perm-payments-collect"
                              defaultChecked={selectedRole.permissions.includes("payments.collect")}
                            />
                            <Label htmlFor="perm-payments-collect">Collect Payments</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="perm-payments-refund"
                              defaultChecked={selectedRole.permissions.includes("payments.refund")}
                            />
                            <Label htmlFor="perm-payments-refund">Process Refunds</Label>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="settings">
                      <AccordionTrigger>Settings</AccordionTrigger>
                      <AccordionContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="perm-settings-view"
                              defaultChecked={selectedRole.permissions.includes("settings.view")}
                            />
                            <Label htmlFor="perm-settings-view">View Settings</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="perm-settings-manage"
                              defaultChecked={selectedRole.permissions.includes("settings.manage")}
                            />
                            <Label htmlFor="perm-settings-manage">Manage Settings</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="perm-settings-system"
                              defaultChecked={selectedRole.permissions.includes("settings.system")}
                            />
                            <Label htmlFor="perm-settings-system">System Settings</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="perm-settings-roles"
                              defaultChecked={selectedRole.permissions.includes("settings.roles")}
                            />
                            <Label htmlFor="perm-settings-roles">Manage Roles</Label>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </TooltipProvider>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditRoleOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" onClick={() => setIsEditRoleOpen(false)}>
                Save Changes
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Edit Email Template Dialog */}
      {selectedTemplate && (
        <Dialog open={isEditTemplateOpen} onOpenChange={setIsEditTemplateOpen}>
          <DialogContent className="sm:max-w-[700px]">
            <DialogHeader>
              <DialogTitle>Edit Email Template: {selectedTemplate.name}</DialogTitle>
              <DialogDescription>Customize the email template content and settings</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="template-name">Template Name</Label>
                  <Input id="template-name" defaultValue={selectedTemplate.name} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="template-subject">Email Subject</Label>
                  <Input id="template-subject" defaultValue={selectedTemplate.subject} />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="template-content">Email Content</Label>
                <Textarea
                  id="template-content"
                  rows={12}
                  defaultValue={`Dear {guest_name},

Thank you for choosing Paddy's View Hotel for your upcoming stay.

Your booking details:
- Booking ID: {booking_id}
- Check-in: {check_in_date}
- Check-out: {check_out_date}
- Room Type: {room_type}
- Guests: {adults} Adults, {children} Children

If you have any questions or special requests, please don't hesitate to contact us.

We look forward to welcoming you!

Best regards,
The Paddy's View Hotel Team
{hotel_phone}
{hotel_email}`}
                />
                <p className="text-sm text-muted-foreground">
                  Use placeholders like {"{guest_name}"} to insert dynamic content
                </p>
              </div>

              <div className="space-y-2">
                <Label>Available Placeholders</Label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  <Badge variant="outline" className="justify-start">
                    {"{ guest_name }"}
                  </Badge>
                  <Badge variant="outline" className="justify-start">
                    {"{ booking_id }"}
                  </Badge>
                  <Badge variant="outline" className="justify-start">
                    {"{ check_in_date }"}
                  </Badge>
                  <Badge variant="outline" className="justify-start">
                    {"{ check_out_date }"}
                  </Badge>
                  <Badge variant="outline" className="justify-start">
                    {"{ room_type }"}
                  </Badge>
                  <Badge variant="outline" className="justify-start">
                    {"{ room_number }"}
                  </Badge>
                  <Badge variant="outline" className="justify-start">
                    {"{ adults }"}
                  </Badge>
                  <Badge variant="outline" className="justify-start">
                    {"{ children }"}
                  </Badge>
                  <Badge variant="outline" className="justify-start">
                    {"{ total_amount }"}
                  </Badge>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="template-active">Active</Label>
                  <Switch id="template-active" defaultChecked />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditTemplateOpen(false)}>
                Cancel
              </Button>
              <Button variant="outline">Send Test Email</Button>
              <Button type="submit" onClick={() => setIsEditTemplateOpen(false)}>
                Save Template
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Add Tax Dialog */}
      <Dialog open={isAddTaxOpen} onOpenChange={setIsAddTaxOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Add Tax Rate</DialogTitle>
            <DialogDescription>Create a new tax rate or discount</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="tax-name" className="text-right">
                Name
              </Label>
              <Input id="tax-name" placeholder="e.g. City Tax" className="col-span-3" />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="tax-rate" className="text-right">
                Rate (%)
              </Label>
              <Input id="tax-rate" type="number" step="0.01" placeholder="e.g. 5.5" className="col-span-3" />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="tax-applies" className="text-right">
                Applies To
              </Label>
              <Select>
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select what this applies to" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Bookings</SelectItem>
                  <SelectItem value="standard">Standard Rooms</SelectItem>
                  <SelectItem value="deluxe">Deluxe Rooms</SelectItem>
                  <SelectItem value="suite">Suites</SelectItem>
                  <SelectItem value="corporate">Corporate Bookings</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="tax-status" className="text-right">
                Status
              </Label>
              <div className="col-span-3 flex items-center space-x-2">
                <Switch id="tax-status" defaultChecked />
                <Label htmlFor="tax-status">Enabled</Label>
              </div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="tax-description" className="text-right">
                Description
              </Label>
              <Input id="tax-description" placeholder="Brief description" className="col-span-3" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddTaxOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" onClick={() => setIsAddTaxOpen(false)}>
              Add Tax Rate
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

