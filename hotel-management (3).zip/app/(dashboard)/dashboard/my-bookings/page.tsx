"use client"

import { Checkbox } from "@/components/ui/checkbox"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CreditCard, Download, Eye, FileText, MoreHorizontal, Search, X, Calendar, Check } from "lucide-react"
import { Separator } from "@/components/ui/separator"

// Sample booking data for a guest
const myBookingsData = [
  {
    id: "B-1001",
    room: "101",
    roomType: "Standard",
    checkIn: "2023-03-22",
    checkOut: "2023-03-25",
    status: "confirmed",
    totalAmount: 329.97,
    paymentStatus: "paid",
    paymentMethod: "Credit Card",
    adults: 2,
    children: 0,
    createdAt: "2023-03-10",
    invoiceId: "INV-1001",
  },
  {
    id: "B-1009",
    room: "202",
    roomType: "Deluxe",
    checkIn: "2023-04-15",
    checkOut: "2023-04-18",
    status: "confirmed",
    totalAmount: 479.97,
    paymentStatus: "paid",
    paymentMethod: "Mobile Money",
    adults: 2,
    children: 1,
    createdAt: "2023-03-20",
    invoiceId: "INV-1009",
  },
  {
    id: "B-1015",
    room: "301",
    roomType: "Suite",
    checkIn: "2023-05-10",
    checkOut: "2023-05-12",
    status: "pending",
    totalAmount: 549.98,
    paymentStatus: "pending",
    paymentMethod: "Pending",
    adults: 2,
    children: 0,
    createdAt: "2023-03-25",
    invoiceId: "INV-1015",
  },
]

// Sample payment history
const paymentHistoryData = [
  {
    id: "P-1001",
    bookingId: "B-1001",
    date: "2023-03-10 14:30:45",
    amount: 329.97,
    method: "Credit Card",
    status: "completed",
    reference: "TXN-45678",
    description: "Payment for booking B-1001",
  },
  {
    id: "P-1002",
    bookingId: "B-1009",
    date: "2023-03-20 10:15:22",
    amount: 479.97,
    method: "Mobile Money",
    status: "completed",
    reference: "MTN-78945",
    description: "Payment for booking B-1009",
  },
]

export default function MyBookingsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedBooking, setSelectedBooking] = useState<any>(null)
  const [isViewBookingOpen, setIsViewBookingOpen] = useState(false)
  const [isViewInvoiceOpen, setIsViewInvoiceOpen] = useState(false)
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false)

  // Filter bookings based on search term
  const filteredBookings = myBookingsData.filter((booking) => {
    return (
      booking.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      booking.room.toLowerCase().includes(searchTerm.toLowerCase()) ||
      booking.roomType.toLowerCase().includes(searchTerm.toLowerCase())
    )
  })

  // Status badge color mapping
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "confirmed":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Confirmed
          </Badge>
        )
      case "pending":
        return (
          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
            Pending
          </Badge>
        )
      case "cancelled":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            Cancelled
          </Badge>
        )
      case "completed":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Completed
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  // Payment status badge color mapping
  const getPaymentBadge = (status: string) => {
    switch (status) {
      case "paid":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Paid
          </Badge>
        )
      case "pending":
        return (
          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
            Pending
          </Badge>
        )
      case "refunded":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Refunded
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  // View booking details
  const handleViewBooking = (booking: any) => {
    setSelectedBooking(booking)
    setIsViewBookingOpen(true)
  }

  // View invoice
  const handleViewInvoice = (booking: any) => {
    setSelectedBooking(booking)
    setIsViewInvoiceOpen(true)
  }

  // Make payment
  const handleMakePayment = (booking: any) => {
    setSelectedBooking(booking)
    setIsPaymentDialogOpen(true)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search bookings..."
            className="w-full pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="mb-6">
        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Upcoming Stay</CardTitle>
              <CardDescription>Your next reservation at Paddy's View Hotel</CardDescription>
            </CardHeader>
            <CardContent>
              {myBookingsData.filter((booking) => new Date(booking.checkIn) > new Date()).length > 0 ? (
                <div className="space-y-4">
                  {(() => {
                    const nextBooking = myBookingsData
                      .filter((booking) => new Date(booking.checkIn) > new Date())
                      .sort((a, b) => new Date(a.checkIn).getTime() - new Date(b.checkIn).getTime())[0]

                    return (
                      <>
                        <div className="flex justify-between items-center">
                          <div>
                            <div className="text-lg font-bold">
                              Room {nextBooking.room} - {nextBooking.roomType}
                            </div>
                            <div className="text-sm text-muted-foreground">Booking #{nextBooking.id}</div>
                          </div>
                          {getStatusBadge(nextBooking.status)}
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-1">
                            <div className="text-sm text-muted-foreground">Check-in</div>
                            <div className="font-medium">{nextBooking.checkIn}</div>
                            <div className="text-xs text-muted-foreground">From 2:00 PM</div>
                          </div>
                          <div className="space-y-1">
                            <div className="text-sm text-muted-foreground">Check-out</div>
                            <div className="font-medium">{nextBooking.checkOut}</div>
                            <div className="text-xs text-muted-foreground">Until 12:00 PM</div>
                          </div>
                        </div>

                        <Separator />

                        <div className="space-y-2">
                          <div className="text-sm font-medium">Booking Details</div>
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <div>Guests:</div>
                            <div>
                              {nextBooking.adults} Adults
                              {nextBooking.children > 0 ? `, ${nextBooking.children} Children` : ""}
                            </div>

                            <div>Total Amount:</div>
                            <div>${nextBooking.totalAmount.toFixed(2)}</div>

                            <div>Payment Status:</div>
                            <div>{getPaymentBadge(nextBooking.paymentStatus)}</div>
                          </div>
                        </div>

                        <div className="flex gap-2 pt-2">
                          <Button variant="outline" size="sm" className="w-full">
                            <Eye className="mr-2 h-4 w-4" /> View Details
                          </Button>
                          {nextBooking.paymentStatus === "pending" && (
                            <Button size="sm" className="w-full">
                              <CreditCard className="mr-2 h-4 w-4" /> Make Payment
                            </Button>
                          )}
                        </div>
                      </>
                    )
                  })()}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Calendar className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
                  <h3 className="text-lg font-medium mb-1">No Upcoming Bookings</h3>
                  <p className="text-sm text-muted-foreground mb-4">You don't have any upcoming stays with us.</p>
                  <Button>Book a Room</Button>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Loyalty Program</CardTitle>
              <CardDescription>Your rewards and membership benefits</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div>
                    <div className="text-lg font-bold">Gold Member</div>
                    <div className="text-sm text-muted-foreground">Member since Jan 2023</div>
                  </div>
                  <Badge className="bg-amber-500">Gold</Badge>
                </div>

                <div className="space-y-2">
                  <div className="text-sm font-medium">Points Balance</div>
                  <div className="text-3xl font-bold">2,450</div>
                  <div className="text-sm text-muted-foreground">
                    <span className="text-green-600 dark:text-green-400">+350 points</span> from your last stay
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="text-sm font-medium">Progress to Platinum</div>
                  <div className="flex justify-between text-sm">
                    <span>2,450 / 5,000 points</span>
                    <span>49%</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div className="bg-amber-500 h-full rounded-full" style={{ width: "49%" }}></div>
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <div className="text-sm font-medium">Available Benefits</div>
                  <div className="space-y-1 text-sm">
                    <div className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-600" />
                      <span>Early check-in when available</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-600" />
                      <span>10% discount at hotel restaurant</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-600" />
                      <span>Complimentary room upgrade (subject to availability)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-600" />
                      <span>Welcome drink on arrival</span>
                    </div>
                  </div>
                </div>

                <Button variant="outline" className="w-full">
                  View Rewards Catalog
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Tabs defaultValue="bookings" className="space-y-4">
        <TabsList>
          <TabsTrigger value="bookings">My Bookings</TabsTrigger>
          <TabsTrigger value="payments">Payment History</TabsTrigger>
        </TabsList>

        <TabsContent value="bookings">
          <Card>
            <CardHeader>
              <CardTitle>My Bookings</CardTitle>
              <CardDescription>View and manage your hotel bookings.</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Booking ID</TableHead>
                    <TableHead>Room</TableHead>
                    <TableHead>Check-in</TableHead>
                    <TableHead>Check-out</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Payment</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredBookings.length > 0 ? (
                    filteredBookings.map((booking) => (
                      <TableRow key={booking.id}>
                        <TableCell className="font-medium">{booking.id}</TableCell>
                        <TableCell>
                          <div>{booking.room}</div>
                          <div className="text-xs text-muted-foreground">{booking.roomType}</div>
                        </TableCell>
                        <TableCell>{booking.checkIn}</TableCell>
                        <TableCell>{booking.checkOut}</TableCell>
                        <TableCell>{getStatusBadge(booking.status)}</TableCell>
                        <TableCell>{getPaymentBadge(booking.paymentStatus)}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Open menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem onClick={() => handleViewBooking(booking)}>
                                <Eye className="mr-2 h-4 w-4" />
                                <span>View Details</span>
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleViewInvoice(booking)}>
                                <FileText className="mr-2 h-4 w-4" />
                                <span>View Invoice</span>
                              </DropdownMenuItem>
                              {booking.paymentStatus === "pending" && (
                                <DropdownMenuItem onClick={() => handleMakePayment(booking)}>
                                  <CreditCard className="mr-2 h-4 w-4" />
                                  <span>Make Payment</span>
                                </DropdownMenuItem>
                              )}
                              {booking.status === "confirmed" && booking.paymentStatus === "paid" && (
                                <DropdownMenuItem>
                                  <Download className="mr-2 h-4 w-4" />
                                  <span>Download Receipt</span>
                                </DropdownMenuItem>
                              )}
                              {booking.status === "pending" && <DropdownMenuSeparator />}
                              {booking.status === "pending" && (
                                <DropdownMenuItem className="text-red-600">
                                  <X className="mr-2 h-4 w-4" />
                                  <span>Cancel Booking</span>
                                </DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={7} className="h-24 text-center">
                        No bookings found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payments">
          <Card>
            <CardHeader>
              <CardTitle>Payment History</CardTitle>
              <CardDescription>View your payment history and download receipts.</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Payment ID</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Booking</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Method</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paymentHistoryData.length > 0 ? (
                    paymentHistoryData.map((payment) => (
                      <TableRow key={payment.id}>
                        <TableCell className="font-medium">{payment.id}</TableCell>
                        <TableCell>{payment.date}</TableCell>
                        <TableCell>{payment.bookingId}</TableCell>
                        <TableCell>${payment.amount.toFixed(2)}</TableCell>
                        <TableCell>{payment.method}</TableCell>
                        <TableCell>{getStatusBadge(payment.status)}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">
                            <Download className="h-4 w-4" />
                            <span className="sr-only">Download Receipt</span>
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={7} className="h-24 text-center">
                        No payment history found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* View Booking Dialog */}
      {selectedBooking && (
        <Dialog open={isViewBookingOpen} onOpenChange={setIsViewBookingOpen}>
          <DialogContent className="sm:max-w-[550px]">
            <DialogHeader>
              <DialogTitle>Booking Details</DialogTitle>
              <DialogDescription>Details for booking {selectedBooking.id}.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium mb-1">Booking Information</h3>
                  <div className="text-sm space-y-1">
                    <p>
                      <span className="font-medium">Booking ID:</span> {selectedBooking.id}
                    </p>
                    <p>
                      <span className="font-medium">Created:</span> {selectedBooking.createdAt}
                    </p>
                    <p>
                      <span className="font-medium">Status:</span> {getStatusBadge(selectedBooking.status)}
                    </p>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium mb-1">Room Information</h3>
                  <div className="text-sm space-y-1">
                    <p>
                      <span className="font-medium">Room:</span> {selectedBooking.room}
                    </p>
                    <p>
                      <span className="font-medium">Type:</span> {selectedBooking.roomType}
                    </p>
                    <p>
                      <span className="font-medium">Guests:</span> {selectedBooking.adults}{" "}
                      {selectedBooking.adults === 1 ? "Adult" : "Adults"}
                      {selectedBooking.children > 0 &&
                        `, ${selectedBooking.children} ${selectedBooking.children === 1 ? "Child" : "Children"}`}
                    </p>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium mb-1">Stay Period</h3>
                  <div className="text-sm space-y-1">
                    <p>
                      <span className="font-medium">Check-in:</span> {selectedBooking.checkIn}
                    </p>
                    <p>
                      <span className="font-medium">Check-out:</span> {selectedBooking.checkOut}
                    </p>
                    <p>
                      <span className="font-medium">Duration:</span> 3 Nights
                    </p>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium mb-1">Payment Information</h3>
                  <div className="text-sm space-y-1">
                    <p>
                      <span className="font-medium">Total Amount:</span> ${selectedBooking.totalAmount.toFixed(2)}
                    </p>
                    <p>
                      <span className="font-medium">Status:</span> {getPaymentBadge(selectedBooking.paymentStatus)}
                    </p>
                    <p>
                      <span className="font-medium">Method:</span> {selectedBooking.paymentMethod}
                    </p>
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="text-sm font-medium mb-1">Booking Policies</h3>
                <div className="text-sm space-y-1">
                  <p>
                    <span className="font-medium">Check-in Time:</span> 2:00 PM
                  </p>
                  <p>
                    <span className="font-medium">Check-out Time:</span> 12:00 PM
                  </p>
                  <p>
                    <span className="font-medium">Cancellation Policy:</span> Free cancellation up to 24 hours before
                    check-in.
                  </p>
                </div>
              </div>
            </div>
            <DialogFooter className="flex flex-col sm:flex-row gap-2">
              <Button variant="outline" onClick={() => setIsViewBookingOpen(false)}>
                Close
              </Button>
              <Button variant="outline">
                <Download className="mr-2 h-4 w-4" /> Download Details
              </Button>
              {selectedBooking.paymentStatus === "pending" && (
                <Button
                  onClick={() => {
                    setIsViewBookingOpen(false)
                    handleMakePayment(selectedBooking)
                  }}
                >
                  <CreditCard className="mr-2 h-4 w-4" /> Make Payment
                </Button>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* View Invoice Dialog */}
      {selectedBooking && (
        <Dialog open={isViewInvoiceOpen} onOpenChange={setIsViewInvoiceOpen}>
          <DialogContent className="sm:max-w-[700px]">
            <DialogHeader>
              <DialogTitle>Invoice {selectedBooking.invoiceId}</DialogTitle>
              <DialogDescription>Invoice for booking {selectedBooking.id}.</DialogDescription>
            </DialogHeader>
            <div className="space-y-6">
              <div className="flex justify-between">
                <div>
                  <h3 className="text-lg font-bold">Paddy's View Hotel</h3>
                  <p className="text-sm text-muted-foreground">123 Hotel Street, Accra, Ghana</p>
                  <p className="text-sm text-muted-foreground">info@paddysviewhotel.com</p>
                  <p className="text-sm text-muted-foreground">+233 20 123 4567</p>
                </div>
                <div className="text-right">
                  <h3 className="text-lg font-bold">Invoice</h3>
                  <p className="text-sm">{selectedBooking.invoiceId}</p>
                  <p className="text-sm">Issue Date: {selectedBooking.createdAt}</p>
                  <p className="text-sm">Due Date: {selectedBooking.createdAt}</p>
                </div>
              </div>

              <Separator />

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium mb-1">Bill To:</h4>
                  <p className="text-sm font-bold">John Doe</p>
                  <p className="text-sm">john.doe@example.com</p>
                  <p className="text-sm">Booking ID: {selectedBooking.id}</p>
                </div>
                <div className="text-right">
                  <h4 className="text-sm font-medium mb-1">Status:</h4>
                  <div>{getPaymentBadge(selectedBooking.paymentStatus)}</div>
                  {selectedBooking.paymentStatus === "paid" && (
                    <p className="text-sm mt-1">Paid via {selectedBooking.paymentMethod}</p>
                  )}
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium mb-2">Invoice Items:</h4>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Description</TableHead>
                      <TableHead className="text-right">Qty</TableHead>
                      <TableHead className="text-right">Unit Price</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell>
                        Room {selectedBooking.room} - {selectedBooking.roomType} (3 nights)
                      </TableCell>
                      <TableCell className="text-right">3</TableCell>
                      <TableCell className="text-right">${(selectedBooking.totalAmount / 3).toFixed(2)}</TableCell>
                      <TableCell className="text-right">${(selectedBooking.totalAmount * 0.9).toFixed(2)}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>Breakfast Package</TableCell>
                      <TableCell className="text-right">1</TableCell>
                      <TableCell className="text-right">${(selectedBooking.totalAmount * 0.1).toFixed(2)}</TableCell>
                      <TableCell className="text-right">${(selectedBooking.totalAmount * 0.1).toFixed(2)}</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>

              <div className="flex flex-col items-end space-y-2">
                <div className="flex w-[200px] justify-between">
                  <span className="font-medium">Subtotal:</span>
                  <span>${selectedBooking.totalAmount.toFixed(2)}</span>
                </div>
                <div className="flex w-[200px] justify-between">
                  <span className="font-medium">Tax (0%):</span>
                  <span>$0.00</span>
                </div>
                <div className="flex w-[200px] justify-between text-lg font-bold">
                  <span>Total:</span>
                  <span>${selectedBooking.totalAmount.toFixed(2)}</span>
                </div>
              </div>

              <Separator />

              <div className="text-sm text-muted-foreground">
                <p className="font-medium">Payment Terms:</p>
                <p>Payment is due immediately upon receipt of this invoice.</p>
                <p className="mt-2">Thank you for choosing Paddy's View Hotel!</p>
              </div>
            </div>
            <DialogFooter className="flex flex-col sm:flex-row gap-2">
              <Button variant="outline" onClick={() => setIsViewInvoiceOpen(false)}>
                Close
              </Button>
              <Button variant="outline">
                <Download className="mr-2 h-4 w-4" /> Download PDF
              </Button>
              {selectedBooking.paymentStatus === "pending" && (
                <Button
                  onClick={() => {
                    setIsViewInvoiceOpen(false)
                    handleMakePayment(selectedBooking)
                  }}
                >
                  <CreditCard className="mr-2 h-4 w-4" /> Make Payment
                </Button>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Payment Dialog */}
      {selectedBooking && (
        <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Make Payment</DialogTitle>
              <DialogDescription>Complete payment for booking {selectedBooking.id}.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="bg-muted p-4 rounded-md">
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium">Room Charge:</span>
                  <span>${(selectedBooking.totalAmount * 0.9).toFixed(2)}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium">Additional Services:</span>
                  <span>${(selectedBooking.totalAmount * 0.1).toFixed(2)}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium">Tax (0%):</span>
                  <span>$0.00</span>
                </div>
                <Separator className="my-2" />
                <div className="flex justify-between font-bold">
                  <span>Total Amount:</span>
                  <span>${selectedBooking.totalAmount.toFixed(2)}</span>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Select Payment Method</h3>
                <div className="grid grid-cols-2 gap-2">
                  <Button variant="outline" className="justify-start">
                    <CreditCard className="mr-2 h-4 w-4" /> Credit Card
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="mr-2 h-4 w-4"
                    >
                      <path d="M5 4h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Z" />
                      <path d="M12 9v6" />
                      <path d="M9 12h6" />
                    </svg>
                    Mobile Money
                  </Button>
                </div>
              </div>

              <div className="space-y-4 border p-4 rounded-md">
                <h3 className="text-sm font-medium">Credit Card Details</h3>
                <div className="space-y-2">
                  <div>
                    <label htmlFor="card-number" className="text-sm font-medium">
                      Card Number
                    </label>
                    <Input id="card-number" placeholder="1234 5678 9012 3456" />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label htmlFor="expiry-date" className="text-sm font-medium">
                        Expiry Date
                      </label>
                      <Input id="expiry-date" placeholder="MM/YY" />
                    </div>
                    <div>
                      <label htmlFor="cvv" className="text-sm font-medium">
                        CVV
                      </label>
                      <Input id="cvv" placeholder="123" />
                    </div>
                  </div>
                  <div>
                    <label htmlFor="card-name" className="text-sm font-medium">
                      Name on Card
                    </label>
                    <Input id="card-name" placeholder="John Doe" />
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox id="save-card" />
                <label htmlFor="save-card" className="text-sm">
                  Save card for future payments
                </label>
              </div>

              <div className="text-sm text-muted-foreground">
                <p>Your payment information is secure and encrypted.</p>
                <p>You will receive a receipt via email after your payment is processed.</p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsPaymentDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" onClick={() => setIsPaymentDialogOpen(false)}>
                Pay ${selectedBooking.totalAmount.toFixed(2)}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}

