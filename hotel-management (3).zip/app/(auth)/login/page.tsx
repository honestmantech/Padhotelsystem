"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { BedDouble, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { toast } from "@/components/ui/use-toast"
import { authenticateUser, getRoleDashboardPath } from "@/lib/auth-utils"
import { useAppContext } from "@/contexts/app-context"

export default function LoginPage() {
  const router = useRouter()
  const { setUser } = useAppContext()
  const [isLoading, setIsLoading] = useState(false)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Simple validation
      if (!email || !password) {
        throw new Error("Please enter both email and password")
      }

      // Authenticate user
      const user = await authenticateUser(email, password)

      if (user) {
        // Set user in context
        setUser(user)

        toast({
          title: "Login Successful",
          description: `Welcome back, ${user.name}!`,
        })

        // Redirect to appropriate dashboard based on role
        router.push(getRoleDashboardPath(user.role))
      } else {
        throw new Error("Invalid email or password")
      }
    } catch (error) {
      toast({
        title: "Login Failed",
        description: error instanceof Error ? error.message : "An error occurred during login",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-muted/40 p-4">
      <div className="w-full max-w-md space-y-6">
        <div className="flex flex-col items-center space-y-2 text-center">
          <BedDouble className="h-12 w-12" />
          <h1 className="text-3xl font-bold">Paddy's View Hotel</h1>
          <p className="text-muted-foreground">Hotel Management System</p>
        </div>

        <Tabs defaultValue="login" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="login">Login</TabsTrigger>
            <TabsTrigger value="demo">Demo Access</TabsTrigger>
          </TabsList>

          <TabsContent value="login">
            <Card>
              <form onSubmit={handleLogin}>
                <CardHeader>
                  <CardTitle>Account Login</CardTitle>
                  <CardDescription>Enter your credentials to access the system</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your.email@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="password">Password</Label>
                      <Link href="/forgot-password" className="text-xs text-muted-foreground hover:text-primary">
                        Forgot password?
                      </Link>
                    </div>
                    <Input
                      id="password"
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Logging in...
                      </>
                    ) : (
                      "Login"
                    )}
                  </Button>
                </CardFooter>
              </form>
            </Card>
          </TabsContent>

          <TabsContent value="demo">
            <Card>
              <CardHeader>
                <CardTitle>Demo Access</CardTitle>
                <CardDescription>Use these credentials to explore different roles</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="rounded-lg border p-3">
                  <div className="font-medium">Admin</div>
                  <div className="text-sm text-muted-foreground mt-1">
                    <div>Email: admin@paddysview.com</div>
                    <div>Password: admin123</div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-2 w-full"
                    onClick={() => {
                      setEmail("admin@paddysview.com")
                      setPassword("admin123")
                    }}
                  >
                    Use Admin Credentials
                  </Button>
                </div>

                <div className="rounded-lg border p-3">
                  <div className="font-medium">Receptionist</div>
                  <div className="text-sm text-muted-foreground mt-1">
                    <div>Email: receptionist@paddysview.com</div>
                    <div>Password: reception123</div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-2 w-full"
                    onClick={() => {
                      setEmail("receptionist@paddysview.com")
                      setPassword("reception123")
                    }}
                  >
                    Use Receptionist Credentials
                  </Button>
                </div>

                <div className="rounded-lg border p-3">
                  <div className="font-medium">Accountant</div>
                  <div className="text-sm text-muted-foreground mt-1">
                    <div>Email: accountant@paddysview.com</div>
                    <div>Password: account123</div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-2 w-full"
                    onClick={() => {
                      setEmail("accountant@paddysview.com")
                      setPassword("account123")
                    }}
                  >
                    Use Accountant Credentials
                  </Button>
                </div>

                <div className="rounded-lg border p-3">
                  <div className="font-medium">Guest</div>
                  <div className="text-sm text-muted-foreground mt-1">
                    <div>Email: guest@example.com</div>
                    <div>Password: guest123</div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-2 w-full"
                    onClick={() => {
                      setEmail("guest@example.com")
                      setPassword("guest123")
                    }}
                  >
                    Use Guest Credentials
                  </Button>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full" onClick={handleLogin} disabled={isLoading || !email || !password}>
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Logging in...
                    </>
                  ) : (
                    "Login with Selected Credentials"
                  )}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

