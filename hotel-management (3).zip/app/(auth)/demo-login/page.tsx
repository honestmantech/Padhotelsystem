"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { BedDouble, Building2, CreditCard, Shield, User, UserRound } from "lucide-react"
import { Separator } from "@/components/ui/separator"

// Demo credentials for different roles
const demoCredentials = {
  admin: {
    email: "admin@paddysview.com",
    password: "admin123",
    role: "Administrator",
    redirectPath: "/dashboard",
  },
  receptionist: {
    email: "receptionist@paddysview.com",
    password: "recept123",
    role: "Receptionist",
    redirectPath: "/dashboard/check-in",
  },
  accountant: {
    email: "accountant@paddysview.com",
    password: "account123",
    role: "Accountant",
    redirectPath: "/dashboard/financial-overview",
  },
  guest: {
    email: "guest@example.com",
    password: "guest123",
    role: "Guest",
    redirectPath: "/dashboard/my-bookings",
  },
}

export default function DemoLoginPage() {
  const router = useRouter()
  const [selectedRole, setSelectedRole] = useState("admin")
  const [isLoading, setIsLoading] = useState(false)

  // Simple login handler
  const handleLogin = () => {
    setIsLoading(true)

    try {
      // Store user role and email in localStorage
      localStorage.setItem("userRole", selectedRole)
      localStorage.setItem("userEmail", currentRole.email)

      // Simulate login process
      setTimeout(() => {
        // Redirect to the appropriate dashboard based on role
        router.push(currentRole.redirectPath)
      }, 1500)
    } catch (error) {
      console.error("Login error:", error)
      setIsLoading(false)
    }
  }

  // Get current role data
  const currentRole = demoCredentials[selectedRole as keyof typeof demoCredentials] || demoCredentials.admin

  // Render role features based on selected role
  const renderRoleFeatures = () => {
    switch (selectedRole) {
      case "admin":
        return (
          <div className="bg-muted p-4 rounded-md">
            <h3 className="font-medium mb-2">Administrator Features</h3>
            <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
              <li>Complete system configuration</li>
              <li>User and role management</li>
              <li>Financial reports and analytics</li>
            </ul>
          </div>
        )
      case "receptionist":
        return (
          <div className="bg-muted p-4 rounded-md">
            <h3 className="font-medium mb-2">Receptionist Features</h3>
            <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
              <li>Booking management</li>
              <li>Check-in and check-out process</li>
              <li>Room assignment and status management</li>
            </ul>
          </div>
        )
      case "accountant":
        return (
          <div className="bg-muted p-4 rounded-md">
            <h3 className="font-medium mb-2">Accountant Features</h3>
            <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
              <li>Financial overview</li>
              <li>Invoice management</li>
              <li>Payment processing</li>
            </ul>
          </div>
        )
      case "guest":
        return (
          <div className="bg-muted p-4 rounded-md">
            <h3 className="font-medium mb-2">Guest Features</h3>
            <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
              <li>View and manage bookings</li>
              <li>Payment history</li>
              <li>Loyalty program status</li>
            </ul>
          </div>
        )
      default:
        return null
    }
  }

  // Render role icon based on selected role
  const renderRoleIcon = () => {
    switch (selectedRole) {
      case "admin":
        return <Shield className="h-5 w-5 mr-2 text-primary" />
      case "receptionist":
        return <BedDouble className="h-5 w-5 mr-2 text-primary" />
      case "accountant":
        return <CreditCard className="h-5 w-5 mr-2 text-primary" />
      case "guest":
        return <User className="h-5 w-5 mr-2 text-primary" />
      default:
        return <Shield className="h-5 w-5 mr-2 text-primary" />
    }
  }

  return (
    <div className="container relative flex-col items-center justify-center min-h-screen grid lg:max-w-none lg:grid-cols-2 lg:px-0">
      {/* Left side - image */}
      <div className="relative hidden h-full flex-col bg-muted p-10 text-white lg:flex dark:border-r">
        <div className="absolute inset-0 bg-zinc-900">
          <img
            src="/placeholder.svg?height=1080&width=1920"
            alt="Hotel Reception"
            className="h-full w-full object-cover opacity-50"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-zinc-900/80 to-zinc-900/30" />
        </div>
        <div className="relative z-20 flex items-center text-lg font-medium">
          <Building2 className="mr-2 h-6 w-6" />
          Paddy's View Hotel
        </div>
        <div className="relative z-20 mt-auto">
          <blockquote className="space-y-2">
            <p className="text-lg">
              "This hotel management system has revolutionized our operations, streamlining processes and enhancing
              guest experiences."
            </p>
            <footer className="text-sm">Michael Johnson, Hotel Manager</footer>
          </blockquote>
        </div>
      </div>

      {/* Right side - login form */}
      <div className="lg:p-8">
        <div className="mx-auto flex w-full flex-col justify-center space-y-6 sm:w-[450px]">
          <div className="flex flex-col space-y-2 text-center">
            <h1 className="text-2xl font-semibold tracking-tight">Demo Account Login</h1>
            <p className="text-sm text-muted-foreground">Choose a role to explore the hotel management system</p>
          </div>

          {/* Role selection buttons with interactivity */}
          <div className="flex flex-wrap gap-2">
            <Button
              variant={selectedRole === "admin" ? "default" : "outline"}
              onClick={() => setSelectedRole("admin")}
              className="flex-1"
            >
              <Shield className="h-4 w-4 mr-2" />
              Admin
            </Button>
            <Button
              variant={selectedRole === "receptionist" ? "default" : "outline"}
              onClick={() => setSelectedRole("receptionist")}
              className="flex-1"
            >
              <BedDouble className="h-4 w-4 mr-2" />
              Receptionist
            </Button>
            <Button
              variant={selectedRole === "accountant" ? "default" : "outline"}
              onClick={() => setSelectedRole("accountant")}
              className="flex-1"
            >
              <CreditCard className="h-4 w-4 mr-2" />
              Accountant
            </Button>
            <Button
              variant={selectedRole === "guest" ? "default" : "outline"}
              onClick={() => setSelectedRole("guest")}
              className="flex-1"
            >
              <User className="h-4 w-4 mr-2" />
              Guest
            </Button>
          </div>

          {/* Login card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                {renderRoleIcon()}
                {currentRole.role} Demo Account
              </CardTitle>
              <CardDescription>
                Login with the demo credentials to access the {currentRole.role.toLowerCase()} dashboard
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="email">Email</Label>
                  <div className="text-xs text-muted-foreground">Demo Email</div>
                </div>
                <Input id="email" type="email" value={currentRole.email} readOnly className="bg-muted/50" />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Password</Label>
                  <div className="text-xs text-muted-foreground">Demo Password</div>
                </div>
                <Input id="password" type="text" value={currentRole.password} readOnly className="bg-muted/50" />
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full" onClick={handleLogin} disabled={isLoading}>
                {isLoading ? (
                  <span className="flex items-center">
                    <svg
                      className="animate-spin -ml-1 mr-3 h-4 w-4 text-white"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      ></circle>
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      ></path>
                    </svg>
                    Logging in...
                  </span>
                ) : (
                  <span className="flex items-center">
                    <UserRound className="mr-2 h-4 w-4" />
                    Login as {currentRole.role}
                  </span>
                )}
              </Button>
            </CardFooter>
          </Card>

          {/* Role features */}
          {renderRoleFeatures()}

          <div className="px-8 text-center text-sm text-muted-foreground">
            <div className="flex items-center justify-center gap-1">
              This is a demo system for Paddy's View Hotel Management
            </div>
            <Separator className="my-4" />
            <div className="flex justify-center gap-4 text-xs">
              <Link href="/" className="underline underline-offset-4 hover:text-primary">
                Back to Homepage
              </Link>
              <Link href="/login" className="underline underline-offset-4 hover:text-primary">
                Regular Login
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

